# apileague.Model.SearchDrinksAPI200ResponseDrinksInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Image** | **string** |  | [optional] 
**NameClean** | **string** |  | [optional] 
**Amount** | **int** |  | [optional] 
**Unit** | **string** |  | [optional] 
**Measures** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.md) |  | [optional] 
**Original** | **string** |  | [optional] 
**Meta** | **List&lt;string&gt;** |  | [optional] 
**OriginalName** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Aisle** | **string** |  | [optional] 
**Consistency** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

