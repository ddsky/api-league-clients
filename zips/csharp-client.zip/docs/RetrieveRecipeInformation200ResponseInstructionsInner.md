# apileague.Model.RetrieveRecipeInformation200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Steps** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

