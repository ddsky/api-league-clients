# apileague.Model.SearchRestaurantsAPI200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Zipcode** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Latitude** | **decimal** |  | [optional] 
**Lon** | **decimal** |  | [optional] 
**StreetAddr2** | **string** |  | [optional] 
**State** | **string** |  | [optional] 
**StreetAddr** | **string** |  | [optional] 
**Lat** | **decimal** |  | [optional] 
**Longitude** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

