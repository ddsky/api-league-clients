# apileague.Model.ExtractEntitiesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entities** | [**List&lt;ExtractEntitiesAPI200ResponseEntitiesInner&gt;**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

