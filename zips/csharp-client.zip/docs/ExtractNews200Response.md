# apileague.Model.ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | [optional] 
**Text** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Images** | [**List&lt;ExtractNews200ResponseImagesInner&gt;**](ExtractNews200ResponseImagesInner.md) |  | [optional] 
**Videos** | [**List&lt;ExtractNews200ResponseVideosInner&gt;**](ExtractNews200ResponseVideosInner.md) |  | [optional] 
**PublishDate** | **string** |  | [optional] 
**Authors** | **List&lt;string&gt;** |  | [optional] 
**Language** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

