# apileague.Model.TopNews200ResponseTopNewsInnerNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Summary** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Text** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**PublishDate** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Authors** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

