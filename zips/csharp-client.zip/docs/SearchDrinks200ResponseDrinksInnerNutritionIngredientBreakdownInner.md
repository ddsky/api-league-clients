# apileague.Model.SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Amount** | **int** |  | [optional] 
**Unit** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Nutrients** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

