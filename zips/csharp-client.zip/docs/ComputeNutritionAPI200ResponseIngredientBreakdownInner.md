# apileague.Model.ComputeNutritionAPI200ResponseIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Amount** | **int** |  | [optional] 
**Unit** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Nutrients** | [**List&lt;ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner&gt;**](ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

