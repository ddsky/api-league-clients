# apileague.Model.DetectSentiment200ResponseSentencesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Length** | **int** |  | [optional] 
**Sentiment** | **string** |  | [optional] 
**Offset** | **int** |  | [optional] 
**Confidence** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

