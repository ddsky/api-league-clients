# apileague.Model.RetrievePageRank200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PageRank** | **decimal** |  | [optional] 
**Position** | **int** |  | [optional] 
**Percentile** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

