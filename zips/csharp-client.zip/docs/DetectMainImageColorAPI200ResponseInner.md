# apileague.Model.DetectMainImageColorAPI200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SpecificColor** | **string** |  | [optional] 
**MainColor** | **string** |  | [optional] 
**HexCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

