# apileague.Model.ScoreText200ResponseStyle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**ScoreText200ResponseReadabilityMainscores**](ScoreText200ResponseReadabilityMainscores.md) |  | [optional] 
**Subscores** | [**ScoreText200ResponseStyleSubscores**](ScoreText200ResponseStyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

