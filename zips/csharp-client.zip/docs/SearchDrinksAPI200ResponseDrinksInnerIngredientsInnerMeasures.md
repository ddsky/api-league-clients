# apileague.Model.SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**Us** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

