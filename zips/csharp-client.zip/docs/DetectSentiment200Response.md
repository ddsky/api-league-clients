# apileague.Model.DetectSentiment200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Document** | [**DetectSentiment200ResponseDocument**](DetectSentiment200ResponseDocument.md) |  | [optional] 
**Sentences** | [**List&lt;DetectSentiment200ResponseSentencesInner&gt;**](DetectSentiment200ResponseSentencesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

