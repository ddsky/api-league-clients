# apileague.Model.SearchRestaurants200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Operational** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**Delivery** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**Pickup** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**DineIn** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

