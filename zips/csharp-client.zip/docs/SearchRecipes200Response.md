# apileague.Model.SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Recipes** | [**List&lt;SearchRecipes200ResponseRecipesInner&gt;**](SearchRecipes200ResponseRecipesInner.md) |  | [optional] 
**TotalResults** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

