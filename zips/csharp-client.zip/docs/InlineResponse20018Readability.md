# Org.OpenAPITools.Model.InlineResponse20018Readability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**InlineResponse20018ReadabilityMainscores**](InlineResponse20018ReadabilityMainscores.md) |  | [optional] 
**Subscores** | [**InlineResponse20018ReadabilitySubscores**](InlineResponse20018ReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

