# apileague.Model.SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sunday** | **string** |  | [optional] 
**Saturday** | **string** |  | [optional] 
**Tuesday** | **string** |  | [optional] 
**Thursday** | **string** |  | [optional] 
**Friday** | **string** |  | [optional] 
**Wednesday** | **string** |  | [optional] 
**Monday** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

