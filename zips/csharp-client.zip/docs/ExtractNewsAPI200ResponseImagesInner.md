# apileague.Model.ExtractNewsAPI200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Width** | **int** |  | [optional] 
**Title** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

