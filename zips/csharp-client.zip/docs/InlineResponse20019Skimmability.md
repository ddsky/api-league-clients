# Org.OpenAPITools.Model.InlineResponse20019Skimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**InlineResponse20019SkimmabilityMainscores**](InlineResponse20019SkimmabilityMainscores.md) |  | [optional] 
**Subscores** | [**InlineResponse20019SkimmabilitySubscores**](InlineResponse20019SkimmabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

