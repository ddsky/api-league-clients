# Org.OpenAPITools.Model.InlineResponse20021Dates

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartPosition** | **int?** |  | [optional] 
**Date** | **string** |  | [optional] 
**NormalizedDate** | **decimal?** |  | [optional] 
**Tag** | **string** |  | [optional] 
**EndPosition** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

