# apileague.Model.SearchDrinksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Drinks** | [**List&lt;SearchDrinksAPI200ResponseDrinksInner&gt;**](SearchDrinksAPI200ResponseDrinksInner.md) |  | [optional] 
**TotalResults** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

