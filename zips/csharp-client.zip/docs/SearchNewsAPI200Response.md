# apileague.Model.SearchNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Available** | **int** |  | [optional] 
**News** | [**List&lt;SearchNewsAPI200ResponseNewsInner&gt;**](SearchNewsAPI200ResponseNewsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

