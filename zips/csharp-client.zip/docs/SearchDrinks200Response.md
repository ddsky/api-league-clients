# apileague.Model.SearchDrinks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Drinks** | [**List&lt;SearchDrinks200ResponseDrinksInner&gt;**](SearchDrinks200ResponseDrinksInner.md) |  | [optional] 
**TotalResults** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

