# apileague.Model.ScoreTextAPI200ResponseStyleSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AbbreviationScore** | **List&lt;int&gt;** |  | [optional] 
**StyleScore** | **List&lt;int&gt;** |  | [optional] 
**SpellingScore** | **List&lt;int&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

