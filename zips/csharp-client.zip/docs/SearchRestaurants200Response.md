# apileague.Model.SearchRestaurants200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Restaurants** | [**List&lt;SearchRestaurants200ResponseRestaurantsInner&gt;**](SearchRestaurants200ResponseRestaurantsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

