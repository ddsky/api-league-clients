# Org.OpenAPITools.Model.InlineResponse20027Images

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Width** | **int?** |  | [optional] 
**License** | [**InlineResponse20027License**](InlineResponse20027License.md) |  | [optional] 
**Thumbnail** | **string** |  | [optional] 
**Id** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Height** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

