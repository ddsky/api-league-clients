# apileague.Model.SearchDrinksAPI200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flavors** | **List&lt;string&gt;** |  | [optional] 
**Instructions** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.md) |  | [optional] 
**Images** | **List&lt;string&gt;** |  | [optional] 
**Nutrition** | [**SearchDrinksAPI200ResponseDrinksInnerNutrition**](SearchDrinksAPI200ResponseDrinksInnerNutrition.md) |  | [optional] 
**GlassType** | **string** |  | [optional] 
**Credits** | [**SearchDrinksAPI200ResponseDrinksInnerCredits**](SearchDrinksAPI200ResponseDrinksInnerCredits.md) |  | [optional] 
**PricePerServing** | **decimal** |  | [optional] 
**Description** | **string** |  | [optional] 
**Ingredients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInner.md) |  | [optional] 
**Id** | **int** |  | [optional] 
**Title** | **string** |  | [optional] 
**Cuisines** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

