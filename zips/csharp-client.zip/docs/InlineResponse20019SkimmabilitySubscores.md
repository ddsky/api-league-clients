# Org.OpenAPITools.Model.InlineResponse20019SkimmabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BulletPointRatioScore** | **List<int?>** |  | [optional] 
**ImageScore** | **List<int?>** |  | [optional] 
**HighlightedWordRatioScore** | **List<int?>** |  | [optional] 
**VideoScore** | **List<int?>** |  | [optional] 
**ParagraphScore** | **List<int?>** |  | [optional] 
**ParagraphHeadlineRatioScore** | **List<int?>** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

