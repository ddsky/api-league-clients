# apileague.Model.ExtractContentFromAWebPage200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** |  | [optional] 
**MainText** | **string** |  | [optional] 
**MainHtml** | **string** |  | [optional] 
**Images** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

