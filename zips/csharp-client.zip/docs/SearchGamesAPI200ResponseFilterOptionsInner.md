# apileague.Model.SearchGamesAPI200ResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**FilterType** | **string** |  | [optional] 
**Key** | **string** |  | [optional] 
**Values** | [**List&lt;SearchGamesAPI200ResponseFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  | [optional] 
**FilterConnection** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

