# Org.OpenAPITools.Model.InlineResponse20018

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Document** | [**InlineResponse20018Document**](InlineResponse20018Document.md) |  | [optional] 
**Sentences** | [**List<InlineResponse20018Sentences>**](InlineResponse20018Sentences.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

