# apileague.Model.SearchGamesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sorting** | **Object** |  | [optional] 
**ActiveFilterOptions** | [**List&lt;SearchGamesAPI200ResponseActiveFilterOptionsInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInner.md) |  | [optional] 
**Query** | **string** |  | [optional] 
**TotalResults** | **int** |  | [optional] 
**Limit** | **int** |  | [optional] 
**Offset** | **int** |  | [optional] 
**Results** | [**List&lt;SearchGamesAPI200ResponseResultsInner&gt;**](SearchGamesAPI200ResponseResultsInner.md) |  | [optional] 
**FilterOptions** | [**List&lt;SearchGamesAPI200ResponseFilterOptionsInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInner.md) |  | [optional] 
**SortingOptions** | [**List&lt;SearchGamesAPI200ResponseSortingOptionsInner&gt;**](SearchGamesAPI200ResponseSortingOptionsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

