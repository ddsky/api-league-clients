# apileague.Model.FindSimilarGamesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Results** | [**List&lt;FindSimilarGamesAPI200ResponseResultsInner&gt;**](FindSimilarGamesAPI200ResponseResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

