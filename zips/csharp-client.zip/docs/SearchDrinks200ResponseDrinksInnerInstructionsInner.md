# apileague.Model.SearchDrinks200ResponseDrinksInnerInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Steps** | [**List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

