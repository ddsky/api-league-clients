# apileague.Model.RetrieveRecipeInformation200ResponseDietaryProperties

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LowFodmap** | **bool** |  | [optional] 
**Vegetarian** | **bool** |  | [optional] 
**Vegan** | **bool** |  | [optional] 
**GlutenFree** | **bool** |  | [optional] 
**DairyFree** | **bool** |  | [optional] 
**Gaps** | **string** |  | [optional] 
**Diets** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

