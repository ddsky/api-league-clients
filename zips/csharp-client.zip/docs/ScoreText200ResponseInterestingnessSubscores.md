# apileague.Model.ScoreText200ResponseInterestingnessSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TitleRatingScore** | **List&lt;int&gt;** |  | [optional] 
**QuoteScore** | **List&lt;int&gt;** |  | [optional] 
**LengthScore** | **List&lt;int&gt;** |  | [optional] 
**LinkScore** | **List&lt;int&gt;** |  | [optional] 
**GoogleHitsScore** | **List&lt;int&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

