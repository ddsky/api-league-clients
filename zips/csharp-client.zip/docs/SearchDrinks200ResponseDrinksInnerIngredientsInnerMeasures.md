# apileague.Model.SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**Us** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

