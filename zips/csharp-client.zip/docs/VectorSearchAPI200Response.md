# apileague.Model.VectorSearchAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Vectors** | [**List&lt;VectorSearchAPI200ResponseVectorsInner&gt;**](VectorSearchAPI200ResponseVectorsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

