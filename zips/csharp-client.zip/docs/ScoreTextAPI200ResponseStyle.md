# apileague.Model.ScoreTextAPI200ResponseStyle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**ScoreTextAPI200ResponseReadabilityMainscores**](ScoreTextAPI200ResponseReadabilityMainscores.md) |  | [optional] 
**Subscores** | [**ScoreTextAPI200ResponseStyleSubscores**](ScoreTextAPI200ResponseStyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

