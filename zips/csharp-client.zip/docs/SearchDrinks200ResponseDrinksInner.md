# apileague.Model.SearchDrinks200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flavors** | **List&lt;string&gt;** |  | [optional] 
**Instructions** | [**List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInner.md) |  | [optional] 
**Images** | **List&lt;string&gt;** |  | [optional] 
**Nutrition** | [**SearchDrinks200ResponseDrinksInnerNutrition**](SearchDrinks200ResponseDrinksInnerNutrition.md) |  | [optional] 
**GlassType** | **string** |  | [optional] 
**Credits** | [**SearchDrinks200ResponseDrinksInnerCredits**](SearchDrinks200ResponseDrinksInnerCredits.md) |  | [optional] 
**PricePerServing** | **decimal** |  | [optional] 
**Description** | **string** |  | [optional] 
**Ingredients** | [**List&lt;SearchDrinks200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerIngredientsInner.md) |  | [optional] 
**Id** | **int** |  | [optional] 
**Title** | **string** |  | [optional] 
**Cuisines** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

