# apileague.Model.SearchNewsAPI200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**Title** | **string** |  | [optional] 
**Text** | **string** |  | [optional] 
**Summary** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Video** | **string** |  | [optional] 
**PublishDate** | **string** |  | [optional] 
**Authors** | **List&lt;string&gt;** |  | [optional] 
**Category** | **string** |  | [optional] 
**Language** | **string** |  | [optional] 
**SourceCountry** | **string** |  | [optional] 
**Sentiment** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

