# apileague.Model.SearchGamesAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Image** | **string** |  | [optional] 
**ShortDescription** | **string** |  | [optional] 
**Year** | **int** |  | [optional] 
**Link** | **string** |  | [optional] 
**Rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  | [optional] 
**AdultOnly** | **bool** |  | [optional] 
**Screenshots** | **List&lt;string&gt;** |  | [optional] 
**Platforms** | [**List&lt;SearchGamesAPI200ResponseResultsInnerPlatformsInner&gt;**](SearchGamesAPI200ResponseResultsInnerPlatformsInner.md) |  | [optional] 
**MicroTrailer** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Genre** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Gameplay** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

