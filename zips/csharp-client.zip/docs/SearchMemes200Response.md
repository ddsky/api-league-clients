# apileague.Model.SearchMemes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Memes** | [**List&lt;SearchMemes200ResponseMemesInner&gt;**](SearchMemes200ResponseMemesInner.md) |  | [optional] 
**Available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

