# apileague.Model.RetrieveRecipeInformation200ResponseIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | [**RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 
**Us** | [**RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

