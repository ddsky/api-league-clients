# apileague.Model.ScoreTextAPI200ResponseInterestingness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**ScoreTextAPI200ResponseSkimmabilityMainscores**](ScoreTextAPI200ResponseSkimmabilityMainscores.md) |  | [optional] 
**Subscores** | [**ScoreTextAPI200ResponseInterestingnessSubscores**](ScoreTextAPI200ResponseInterestingnessSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

