# Org.OpenAPITools.Model.InlineResponse20018Interestingness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**InlineResponse20018SkimmabilityMainscores**](InlineResponse20018SkimmabilityMainscores.md) |  | [optional] 
**Subscores** | [**InlineResponse20018InterestingnessSubscores**](InlineResponse20018InterestingnessSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

