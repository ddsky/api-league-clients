# apileague.Model.ScoreText200ResponseInterestingness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**ScoreText200ResponseSkimmabilityMainscores**](ScoreText200ResponseSkimmabilityMainscores.md) |  | [optional] 
**Subscores** | [**ScoreText200ResponseInterestingnessSubscores**](ScoreText200ResponseInterestingnessSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

