# apileague.Model.SearchBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalResults** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Offset** | **int** |  | [optional] 
**Books** | **List&lt;List&lt;SearchBooks200ResponseBooksInnerInner&gt;&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

