# apileague.Model.ExtractEntitiesAPI200ResponseEntitiesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartPosition** | **int** |  | [optional] 
**Image** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Value** | **string** |  | [optional] 
**EndPosition** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

