# apileague.Model.DetectSentimentAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Document** | [**DetectSentimentAPI200ResponseDocument**](DetectSentimentAPI200ResponseDocument.md) |  | [optional] 
**Sentences** | [**List&lt;DetectSentimentAPI200ResponseSentencesInner&gt;**](DetectSentimentAPI200ResponseSentencesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

