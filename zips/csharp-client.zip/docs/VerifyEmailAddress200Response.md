# apileague.Model.VerifyEmailAddress200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** |  | [optional] 
**Domain** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**MiddleName** | **string** |  | [optional] 
**LastName** | **string** |  | [optional] 
**FullName** | **string** |  | [optional] 
**Username** | **string** |  | [optional] 
**Image** | **string** |  | [optional] 
**Result** | **string** |  | [optional] 
**Disposable** | **bool** |  | [optional] 
**AcceptAll** | **bool** |  | [optional] 
**FreeProvider** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

