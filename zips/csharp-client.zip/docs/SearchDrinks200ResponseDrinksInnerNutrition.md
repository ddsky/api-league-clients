# apileague.Model.SearchDrinks200ResponseDrinksInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**WeightPerServing** | [**SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional] 
**CaloricBreakdown** | [**SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional] 
**Flavonoids** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional] 
**IngredientBreakdown** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  | [optional] 
**Properties** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional] 
**Nutrients** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

