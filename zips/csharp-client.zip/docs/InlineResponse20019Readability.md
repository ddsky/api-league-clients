# Org.OpenAPITools.Model.InlineResponse20019Readability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**InlineResponse20019ReadabilityMainscores**](InlineResponse20019ReadabilityMainscores.md) |  | [optional] 
**Subscores** | [**InlineResponse20019ReadabilitySubscores**](InlineResponse20019ReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

