# apileague.Model.FindSimilarBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SimilarBooks** | [**List&lt;SearchBooks200ResponseBooksInnerInner&gt;**](SearchBooks200ResponseBooksInnerInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

