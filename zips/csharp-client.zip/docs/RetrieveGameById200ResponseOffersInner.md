# apileague.Model.RetrieveGameById200ResponseOffersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StoreName** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Price** | [**RetrieveGameById200ResponseOffersInnerPrice**](RetrieveGameById200ResponseOffersInnerPrice.md) |  | [optional] 
**Platform** | **string** |  | [optional] 
**Url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

