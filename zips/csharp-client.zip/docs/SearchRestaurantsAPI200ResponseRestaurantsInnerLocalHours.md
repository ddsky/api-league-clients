# apileague.Model.SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Operational** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**Delivery** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**Pickup** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**DineIn** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

