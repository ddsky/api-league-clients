# apileague.Model.ComputeNutrition200ResponseIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Amount** | **int** |  | [optional] 
**Unit** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Nutrients** | [**List&lt;ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner&gt;**](ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

