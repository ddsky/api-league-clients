# Org.OpenAPITools.Model.InlineResponse20019InterestingnessSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TitleRatingScore** | **List<int?>** |  | [optional] 
**QuoteScore** | **List<int?>** |  | [optional] 
**LengthScore** | **List<int?>** |  | [optional] 
**LinkScore** | **List<int?>** |  | [optional] 
**GoogleHitsScore** | **List<int?>** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

