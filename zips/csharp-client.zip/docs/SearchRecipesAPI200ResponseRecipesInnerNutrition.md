# apileague.Model.SearchRecipesAPI200ResponseRecipesInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nutrients** | [**List&lt;SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner&gt;**](SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

