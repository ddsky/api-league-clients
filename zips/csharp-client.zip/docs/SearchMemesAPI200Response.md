# apileague.Model.SearchMemesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Memes** | [**List&lt;SearchMemesAPI200ResponseMemesInner&gt;**](SearchMemesAPI200ResponseMemesInner.md) |  | [optional] 
**Available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

