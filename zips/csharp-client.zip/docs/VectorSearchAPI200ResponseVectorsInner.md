# apileague.Model.VectorSearchAPI200ResponseVectorsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**License** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Author** | **string** |  | [optional] 
**ImageUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

