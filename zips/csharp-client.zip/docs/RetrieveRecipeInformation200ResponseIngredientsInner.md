# apileague.Model.RetrieveRecipeInformation200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Image** | **string** |  | [optional] 
**NameClean** | **string** |  | [optional] 
**Amount** | **decimal** |  | [optional] 
**Unit** | **string** |  | [optional] 
**Measures** | [**RetrieveRecipeInformation200ResponseIngredientsInnerMeasures**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasures.md) |  | [optional] 
**Original** | **string** |  | [optional] 
**Meta** | **List&lt;string&gt;** |  | [optional] 
**OriginalName** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Id** | **int** |  | [optional] 
**Aisle** | **string** |  | [optional] 
**Consistency** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

