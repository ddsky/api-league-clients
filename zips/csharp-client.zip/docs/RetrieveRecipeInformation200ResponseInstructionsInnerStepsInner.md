# apileague.Model.RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **int** |  | [optional] 
**Ingredients** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**Equipment** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**Step** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

