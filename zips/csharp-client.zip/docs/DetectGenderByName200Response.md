# apileague.Model.DetectGenderByName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**ProbabilityMale** | **decimal** |  | [optional] 
**ProbabilityFemale** | **decimal** |  | [optional] 
**Popularity** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

