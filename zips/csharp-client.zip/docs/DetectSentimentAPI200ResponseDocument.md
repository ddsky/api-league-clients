# apileague.Model.DetectSentimentAPI200ResponseDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sentiment** | **string** |  | [optional] 
**Confidence** | **int** |  | [optional] 
**AverageConfidence** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

