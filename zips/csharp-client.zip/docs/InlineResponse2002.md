# Org.OpenAPITools.Model.InlineResponse2002

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int?** |  | [optional] 
**Number** | **int?** |  | [optional] 
**Available** | **int?** |  | [optional] 
**News** | [**List<InlineResponse2002News>**](InlineResponse2002News.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

