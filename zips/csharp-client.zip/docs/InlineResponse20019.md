# Org.OpenAPITools.Model.InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumberOfWords** | **int?** |  | [optional] 
**NumberOfSentences** | **int?** |  | [optional] 
**Readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  | [optional] 
**Skimmability** | [**InlineResponse20019Skimmability**](InlineResponse20019Skimmability.md) |  | [optional] 
**Interestingness** | [**InlineResponse20019Interestingness**](InlineResponse20019Interestingness.md) |  | [optional] 
**Style** | [**InlineResponse20019Style**](InlineResponse20019Style.md) |  | [optional] 
**TotalScore** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

