# apileague.Model.RetrieveGameById200ResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currency** | **string** |  | [optional] 
**DiscountPercent** | **int** |  | [optional] 
**Value** | **decimal** |  | [optional] 
**Initial** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

