# apileague.Model.RetrieveGameById200ResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Count** | **int** |  | [optional] 
**CountCritics** | **int** |  | [optional] 
**MeanPlayers** | **decimal** |  | [optional] 
**MeanCritics** | **decimal** |  | [optional] 
**Mean** | **decimal** |  | [optional] 
**CountPlayers** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

