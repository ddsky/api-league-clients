# apileague.Model.RetrieveRecipeInformationAPI200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Steps** | [**List&lt;RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

