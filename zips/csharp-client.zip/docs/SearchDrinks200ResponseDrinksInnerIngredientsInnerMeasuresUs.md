# apileague.Model.SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UnitShort** | **string** |  | [optional] 
**Amount** | **int** |  | [optional] 
**UnitLong** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

