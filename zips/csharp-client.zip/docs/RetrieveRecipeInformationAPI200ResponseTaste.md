# apileague.Model.RetrieveRecipeInformationAPI200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Fattiness** | **decimal** |  | [optional] 
**Spiciness** | **int** |  | [optional] 
**Saltiness** | **int** |  | [optional] 
**Bitterness** | **decimal** |  | [optional] 
**Savoriness** | **decimal** |  | [optional] 
**Sweetness** | **decimal** |  | [optional] 
**Sourness** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

