# apileague.Model.SearchRecipesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Offset** | **int** |  | [optional] 
**Number** | **int** |  | [optional] 
**Recipes** | [**List&lt;SearchRecipesAPI200ResponseRecipesInner&gt;**](SearchRecipesAPI200ResponseRecipesInner.md) |  | [optional] 
**TotalResults** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

