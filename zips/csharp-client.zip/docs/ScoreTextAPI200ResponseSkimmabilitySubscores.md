# apileague.Model.ScoreTextAPI200ResponseSkimmabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BulletPointRatioScore** | **List&lt;int&gt;** |  | [optional] 
**ImageScore** | **List&lt;int&gt;** |  | [optional] 
**HighlightedWordRatioScore** | **List&lt;int&gt;** |  | [optional] 
**VideoScore** | **List&lt;int&gt;** |  | [optional] 
**ParagraphScore** | **List&lt;int&gt;** |  | [optional] 
**ParagraphHeadlineRatioScore** | **List&lt;int&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

