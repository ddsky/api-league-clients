# Org.OpenAPITools.Model.InlineResponse20019StyleSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AbbreviationScore** | **List<int?>** |  | [optional] 
**StyleScore** | **List<int?>** |  | [optional] 
**SpellingScore** | **List<int?>** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

