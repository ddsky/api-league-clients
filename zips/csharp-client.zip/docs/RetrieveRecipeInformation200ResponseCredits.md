# apileague.Model.RetrieveRecipeInformation200ResponseCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**License** | **string** |  | [optional] 
**Text** | **string** |  | [optional] 
**SourceName** | **string** |  | [optional] 
**SourceUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

