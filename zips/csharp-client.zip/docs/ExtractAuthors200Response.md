# apileague.Model.ExtractAuthors200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Authors** | [**List&lt;ExtractAuthors200ResponseAuthorsInner&gt;**](ExtractAuthors200ResponseAuthorsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

