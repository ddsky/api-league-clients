# Org.OpenAPITools.Model.InlineResponse20018Style

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mainscores** | [**InlineResponse20018ReadabilityMainscores**](InlineResponse20018ReadabilityMainscores.md) |  | [optional] 
**Subscores** | [**InlineResponse20018StyleSubscores**](InlineResponse20018StyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

