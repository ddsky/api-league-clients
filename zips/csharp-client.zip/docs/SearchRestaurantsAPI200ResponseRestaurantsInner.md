# apileague.Model.SearchRestaurantsAPI200ResponseRestaurantsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OffersThirdPartyDelivery** | **bool** |  | [optional] 
**Address** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerAddress**](SearchRestaurantsAPI200ResponseRestaurantsInnerAddress.md) |  | [optional] 
**SupportsUpcCodes** | **bool** |  | [optional] 
**IsOpen** | **bool** |  | [optional] 
**Description** | **string** |  | [optional] 
**WeightedRatingValue** | **int** |  | [optional] 
**Type** | **string** |  | [optional] 
**OffersFirstPartyDelivery** | **bool** |  | [optional] 
**AggregatedRatingCount** | **int** |  | [optional] 
**PickupEnabled** | **bool** |  | [optional] 
**Cuisines** | **List&lt;string&gt;** |  | [optional] 
**Miles** | **decimal** |  | [optional] 
**DollarSigns** | **int** |  | [optional] 
**DeliveryEnabled** | **bool** |  | [optional] 
**Name** | **string** |  | [optional] 
**PhoneNumber** | **decimal** |  | [optional] 
**Id** | **string** |  | [optional] 
**LocalHours** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

