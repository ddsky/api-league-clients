# apileague.Model.FindSimilarGamesAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Image** | **string** |  | [optional] 
**ShortDescription** | **string** |  | [optional] 
**MicroTrailer** | **string** |  | [optional] 
**Year** | **int** |  | [optional] 
**Name** | **string** |  | [optional] 
**Genre** | **string** |  | [optional] 
**Link** | **string** |  | [optional] 
**Rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  | [optional] 
**Id** | **int** |  | [optional] 
**AdultOnly** | **bool** |  | [optional] 
**Screenshots** | **List&lt;string&gt;** |  | [optional] 
**Gameplay** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

