# apileague.Model.ScoreTextAPI200ResponseReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReadingTimeSeconds** | **int** |  | [optional] 
**Forcast** | **decimal** |  | [optional] 
**Flesch** | **decimal** |  | [optional] 
**Smog** | **decimal** |  | [optional] 
**Ari** | **decimal** |  | [optional] 
**Lix** | **decimal** |  | [optional] 
**ColemanLiau** | **decimal** |  | [optional] 
**Kincaid** | **decimal** |  | [optional] 
**Fog** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

