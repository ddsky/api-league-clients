# Org.OpenAPITools.Model.InlineResponse2004

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Jokes** | [**List<InlineResponse2004Jokes>**](InlineResponse2004Jokes.md) |  | [optional] 
**Available** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

