# apileague.Model.SearchRecipesAPI200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Images** | **List&lt;string&gt;** |  | [optional] 
**Nutrition** | [**SearchRecipesAPI200ResponseRecipesInnerNutrition**](SearchRecipesAPI200ResponseRecipesInnerNutrition.md) |  | [optional] 
**Id** | **int** |  | [optional] 
**Title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

