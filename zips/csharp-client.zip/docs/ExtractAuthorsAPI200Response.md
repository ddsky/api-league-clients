# apileague.Model.ExtractAuthorsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Authors** | [**List&lt;ExtractAuthorsAPI200ResponseAuthorsInner&gt;**](ExtractAuthorsAPI200ResponseAuthorsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

