# apileague.Model.SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PercentFat** | **decimal** |  | [optional] 
**PercentCarbs** | **decimal** |  | [optional] 
**PercentProtein** | **decimal** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

