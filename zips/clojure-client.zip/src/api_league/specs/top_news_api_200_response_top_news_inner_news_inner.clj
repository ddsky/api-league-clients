(ns api-league.specs.top-news-api-200-response-top-news-inner-news-inner
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def top-news-api-200-response-top-news-inner-news-inner-data
  {
   (ds/opt :id) int?
   (ds/opt :title) string?
   (ds/opt :text) string?
   (ds/opt :summary) string?
   (ds/opt :url) string?
   (ds/opt :image) string?
   (ds/opt :publish_date) string?
   (ds/opt :authors) (s/coll-of string?)
   })

(def top-news-api-200-response-top-news-inner-news-inner-spec
  (ds/spec
    {:name ::top-news-api-200-response-top-news-inner-news-inner
     :spec top-news-api-200-response-top-news-inner-news-inner-data}))
