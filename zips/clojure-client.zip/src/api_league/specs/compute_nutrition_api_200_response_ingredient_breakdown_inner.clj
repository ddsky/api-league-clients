(ns api-league.specs.compute-nutrition-api-200-response-ingredient-breakdown-inner
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            [api-league.specs.compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner :refer :all]
            )
  (:import (java.io File)))


(def compute-nutrition-api-200-response-ingredient-breakdown-inner-data
  {
   (ds/opt :id) int?
   (ds/opt :name) string?
   (ds/opt :amount) int?
   (ds/opt :unit) string?
   (ds/opt :nutrients) (s/coll-of compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner-spec)
   })

(def compute-nutrition-api-200-response-ingredient-breakdown-inner-spec
  (ds/spec
    {:name ::compute-nutrition-api-200-response-ingredient-breakdown-inner
     :spec compute-nutrition-api-200-response-ingredient-breakdown-inner-data}))
