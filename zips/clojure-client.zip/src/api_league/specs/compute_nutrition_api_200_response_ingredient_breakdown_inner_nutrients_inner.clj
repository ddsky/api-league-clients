(ns api-league.specs.compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner
  (:require [clojure.spec.alpha :as s]
            [spec-tools.data-spec :as ds]
            )
  (:import (java.io File)))


(def compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner-data
  {
   (ds/opt :name) string?
   (ds/opt :amount) int?
   (ds/opt :unit) string?
   (ds/opt :percent_of_daily_needs) int?
   })

(def compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner-spec
  (ds/spec
    {:name ::compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner
     :spec compute-nutrition-api-200-response-ingredient-breakdown-inner-nutrients-inner-data}))
