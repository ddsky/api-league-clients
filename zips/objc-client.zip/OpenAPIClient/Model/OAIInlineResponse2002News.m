#import "OAIInlineResponse2002News.h"

@implementation OAIInlineResponse2002News

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"summary": @"summary", @"image": @"image", @"sentiment": @"sentiment", @"sourceCountry": @"source_country", @"language": @"language", @"_id": @"id", @"text": @"text", @"title": @"title", @"publishDate": @"publish_date", @"url": @"url", @"authors": @"authors" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"summary", @"image", @"sentiment", @"sourceCountry", @"language", @"_id", @"text", @"title", @"publishDate", @"url", @"authors"];
  return [optionalProperties containsObject:propertyName];
}

@end
