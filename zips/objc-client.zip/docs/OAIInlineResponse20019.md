# OAIInlineResponse20019

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfWords** | **NSNumber*** |  | [optional] 
**numberOfSentences** | **NSNumber*** |  | [optional] 
**readability** | [**OAIInlineResponse20019Readability***](OAIInlineResponse20019Readability.md) |  | [optional] 
**skimmability** | [**OAIInlineResponse20019Skimmability***](OAIInlineResponse20019Skimmability.md) |  | [optional] 
**interestingness** | [**OAIInlineResponse20019Interestingness***](OAIInlineResponse20019Interestingness.md) |  | [optional] 
**style** | [**OAIInlineResponse20019Style***](OAIInlineResponse20019Style.md) |  | [optional] 
**totalScore** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


