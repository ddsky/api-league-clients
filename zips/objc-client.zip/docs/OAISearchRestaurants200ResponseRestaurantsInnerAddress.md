# OAISearchRestaurants200ResponseRestaurantsInnerAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **NSString*** |  | [optional] 
**country** | **NSString*** |  | [optional] 
**city** | **NSString*** |  | [optional] 
**latitude** | **NSNumber*** |  | [optional] 
**lon** | **NSNumber*** |  | [optional] 
**streetAddr2** | **NSString*** |  | [optional] 
**state** | **NSString*** |  | [optional] 
**streetAddr** | **NSString*** |  | [optional] 
**lat** | **NSNumber*** |  | [optional] 
**longitude** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


