# OAIRetrieveRecipeInformation200ResponseCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **NSString*** |  | [optional] 
**text** | **NSString*** |  | [optional] 
**sourceName** | **NSString*** |  | [optional] 
**sourceUrl** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


