# OAIInlineResponse20028

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**NSArray&lt;OAIInlineResponse20028Images&gt;***](OAIInlineResponse20028Images.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


