# OAIRetrieveRecipeInformation200ResponseInstructionsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | [optional] 
**steps** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseInstructionsInnerStepsInner&gt;***](OAIRetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


