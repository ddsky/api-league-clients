# OAISearchRoyaltyFreeImages200ResponseImagesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **NSNumber*** |  | [optional] 
**license** | [**OAISearchRoyaltyFreeImages200ResponseImagesInnerLicense***](OAISearchRoyaltyFreeImages200ResponseImagesInnerLicense.md) |  | [optional] 
**thumbnail** | **NSString*** |  | [optional] 
**_id** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**height** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


