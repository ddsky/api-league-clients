# OAIInlineResponse20019Skimmability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20019SkimmabilityMainscores***](OAIInlineResponse20019SkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20019SkimmabilitySubscores***](OAIInlineResponse20019SkimmabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


