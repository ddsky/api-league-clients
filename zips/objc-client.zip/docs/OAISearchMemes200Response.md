# OAISearchMemes200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**NSArray&lt;OAISearchMemes200ResponseMemesInner&gt;***](OAISearchMemes200ResponseMemesInner.md) |  | [optional] 
**available** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


