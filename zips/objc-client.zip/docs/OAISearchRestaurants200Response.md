# OAISearchRestaurants200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**NSArray&lt;OAISearchRestaurants200ResponseRestaurantsInner&gt;***](OAISearchRestaurants200ResponseRestaurantsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


