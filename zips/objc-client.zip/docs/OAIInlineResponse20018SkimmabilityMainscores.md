# OAIInlineResponse20018SkimmabilityMainscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **NSNumber*** |  | [optional] 
**total** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


