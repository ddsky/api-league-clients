# OAIExtractEntities200ResponseEntitiesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **NSNumber*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**type** | **NSString*** |  | [optional] 
**value** | **NSString*** |  | [optional] 
**endPosition** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


