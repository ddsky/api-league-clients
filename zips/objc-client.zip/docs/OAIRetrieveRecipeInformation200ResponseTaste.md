# OAIRetrieveRecipeInformation200ResponseTaste

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | **NSNumber*** |  | [optional] 
**spiciness** | **NSNumber*** |  | [optional] 
**saltiness** | **NSNumber*** |  | [optional] 
**bitterness** | **NSNumber*** |  | [optional] 
**savoriness** | **NSNumber*** |  | [optional] 
**sweetness** | **NSNumber*** |  | [optional] 
**sourness** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


