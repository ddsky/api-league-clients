# OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric***](OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric***](OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


