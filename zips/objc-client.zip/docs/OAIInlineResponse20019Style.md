# OAIInlineResponse20019Style

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20019ReadabilityMainscores***](OAIInlineResponse20019ReadabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20019StyleSubscores***](OAIInlineResponse20019StyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


