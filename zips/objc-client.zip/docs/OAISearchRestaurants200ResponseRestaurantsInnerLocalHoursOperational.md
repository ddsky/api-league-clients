# OAISearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **NSString*** |  | [optional] 
**saturday** | **NSString*** |  | [optional] 
**tuesday** | **NSString*** |  | [optional] 
**thursday** | **NSString*** |  | [optional] 
**friday** | **NSString*** |  | [optional] 
**wednesday** | **NSString*** |  | [optional] 
**monday** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


