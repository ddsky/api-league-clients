# OAIInlineResponse20019Interestingness

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20019SkimmabilityMainscores***](OAIInlineResponse20019SkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20019InterestingnessSubscores***](OAIInlineResponse20019InterestingnessSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


