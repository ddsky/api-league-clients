# OAIVerifyEmailAddress200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **NSString*** |  | [optional] 
**domain** | **NSString*** |  | [optional] 
**firstName** | **NSString*** |  | [optional] 
**middleName** | **NSString*** |  | [optional] 
**lastName** | **NSString*** |  | [optional] 
**fullName** | **NSString*** |  | [optional] 
**username** | **NSString*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**result** | **NSString*** |  | [optional] 
**disposable** | **NSNumber*** |  | [optional] 
**acceptAll** | **NSNumber*** |  | [optional] 
**freeProvider** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


