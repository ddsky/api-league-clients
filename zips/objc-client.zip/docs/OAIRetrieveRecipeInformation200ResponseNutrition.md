# OAIRetrieveRecipeInformation200ResponseNutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weightPerServing** | [**OAIRetrieveRecipeInformation200ResponseNutritionWeightPerServing***](OAIRetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  | [optional] 
**caloricBreakdown** | [**OAIRetrieveRecipeInformation200ResponseNutritionCaloricBreakdown***](OAIRetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  | [optional] 
**flavonoids** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionFlavonoidsInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  | [optional] 
**ingredientBreakdown** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner.md) |  | [optional] 
**properties** | [**NSArray&lt;OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;***](OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 
**nutrients** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


