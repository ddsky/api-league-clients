# OAIRetrieveRecipeInformation200ResponseNutritionCaloricBreakdown

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentFat** | **NSNumber*** |  | [optional] 
**percentCarbs** | **NSNumber*** |  | [optional] 
**percentProtein** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


