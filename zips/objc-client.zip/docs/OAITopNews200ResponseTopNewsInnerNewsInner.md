# OAITopNews200ResponseTopNewsInnerNewsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **NSString*** |  | [optional] 
**image** | **NSString*** |  | [optional] 
**author** | **NSString*** |  | [optional] 
**_id** | **NSNumber*** |  | [optional] 
**text** | **NSString*** |  | [optional] 
**title** | **NSString*** |  | [optional] 
**publishDate** | **NSString*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**authors** | **NSArray&lt;NSString*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


