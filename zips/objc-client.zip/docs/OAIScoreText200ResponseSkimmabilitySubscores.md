# OAIScoreText200ResponseSkimmabilitySubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulletPointRatioScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**imageScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**highlightedWordRatioScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**videoScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**paragraphScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**paragraphHeadlineRatioScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


