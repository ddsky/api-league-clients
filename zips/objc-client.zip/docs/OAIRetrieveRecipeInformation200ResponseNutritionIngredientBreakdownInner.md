# OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | [optional] 
**amount** | **NSNumber*** |  | [optional] 
**unit** | **NSString*** |  | [optional] 
**_id** | **NSNumber*** |  | [optional] 
**nutrients** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


