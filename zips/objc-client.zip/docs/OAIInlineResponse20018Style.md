# OAIInlineResponse20018Style

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20018ReadabilityMainscores***](OAIInlineResponse20018ReadabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20018StyleSubscores***](OAIInlineResponse20018StyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


