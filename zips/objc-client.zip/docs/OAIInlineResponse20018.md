# OAIInlineResponse20018

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**OAIInlineResponse20018Document***](OAIInlineResponse20018Document.md) |  | [optional] 
**sentences** | [**NSArray&lt;OAIInlineResponse20018Sentences&gt;***](OAIInlineResponse20018Sentences.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


