# OAIInlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**NSArray&lt;OAIInlineResponse2005Memes&gt;***](OAIInlineResponse2005Memes.md) |  | [optional] 
**available** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


