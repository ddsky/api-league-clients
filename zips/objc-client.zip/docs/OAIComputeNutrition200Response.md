# OAIComputeNutrition200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 
**properties** | [**NSArray&lt;OAIRetrieveRecipeInformation200ResponseNutritionFlavonoidsInner&gt;***](OAIRetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  | [optional] 
**flavonoids** | [**NSArray&lt;OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;***](OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 
**ingredientBreakdown** | [**NSArray&lt;OAIComputeNutrition200ResponseIngredientBreakdownInner&gt;***](OAIComputeNutrition200ResponseIngredientBreakdownInner.md) |  | [optional] 
**caloricBreakdown** | [**OAIRetrieveRecipeInformation200ResponseNutritionCaloricBreakdown***](OAIRetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  | [optional] 
**weightPerServing** | [**OAIRetrieveRecipeInformation200ResponseNutritionWeightPerServing***](OAIRetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


