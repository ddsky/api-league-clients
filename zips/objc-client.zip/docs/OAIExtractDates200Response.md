# OAIExtractDates200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**NSArray&lt;OAIExtractDates200ResponseDatesInner&gt;***](OAIExtractDates200ResponseDatesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


