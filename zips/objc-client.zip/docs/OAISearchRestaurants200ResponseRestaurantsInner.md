# OAISearchRestaurants200ResponseRestaurantsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offersThirdPartyDelivery** | **NSNumber*** |  | [optional] 
**address** | [**OAISearchRestaurants200ResponseRestaurantsInnerAddress***](OAISearchRestaurants200ResponseRestaurantsInnerAddress.md) |  | [optional] 
**supportsUpcCodes** | **NSNumber*** |  | [optional] 
**isOpen** | **NSNumber*** |  | [optional] 
**_description** | **NSString*** |  | [optional] 
**weightedRatingValue** | **NSNumber*** |  | [optional] 
**type** | **NSString*** |  | [optional] 
**offersFirstPartyDelivery** | **NSNumber*** |  | [optional] 
**aggregatedRatingCount** | **NSNumber*** |  | [optional] 
**pickupEnabled** | **NSNumber*** |  | [optional] 
**cuisines** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**miles** | **NSNumber*** |  | [optional] 
**dollarSigns** | **NSNumber*** |  | [optional] 
**deliveryEnabled** | **NSNumber*** |  | [optional] 
**name** | **NSString*** |  | [optional] 
**phoneNumber** | **NSNumber*** |  | [optional] 
**_id** | **NSString*** |  | [optional] 
**localHours** | [**OAISearchRestaurants200ResponseRestaurantsInnerLocalHours***](OAISearchRestaurants200ResponseRestaurantsInnerLocalHours.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


