# OAISearchRecipes200ResponseRecipesInnerNutrition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**NSArray&lt;OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;***](OAISearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


