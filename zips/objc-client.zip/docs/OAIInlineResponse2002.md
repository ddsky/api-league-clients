# OAIInlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **NSNumber*** |  | [optional] 
**number** | **NSNumber*** |  | [optional] 
**available** | **NSNumber*** |  | [optional] 
**varNews** | [**NSArray&lt;OAIInlineResponse2002News&gt;***](OAIInlineResponse2002News.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


