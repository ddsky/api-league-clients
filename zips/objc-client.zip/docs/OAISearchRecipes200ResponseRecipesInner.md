# OAISearchRecipes200ResponseRecipesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**nutrition** | [**OAISearchRecipes200ResponseRecipesInnerNutrition***](OAISearchRecipes200ResponseRecipesInnerNutrition.md) |  | [optional] 
**_id** | **NSNumber*** |  | [optional] 
**title** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


