# OAIRetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | [optional] 
**percentOfDailyNeeds** | **NSNumber*** |  | [optional] 
**amount** | **NSNumber*** |  | [optional] 
**unit** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


