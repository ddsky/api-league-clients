# OAIRetrieveRecipeInformation200ResponseIngredientsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **NSString*** |  | [optional] 
**nameClean** | **NSString*** |  | [optional] 
**amount** | **NSNumber*** |  | [optional] 
**unit** | **NSString*** |  | [optional] 
**measures** | [**OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasures***](OAIRetrieveRecipeInformation200ResponseIngredientsInnerMeasures.md) |  | [optional] 
**original** | **NSString*** |  | [optional] 
**meta** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**originalName** | **NSString*** |  | [optional] 
**name** | **NSString*** |  | [optional] 
**_id** | **NSNumber*** |  | [optional] 
**aisle** | **NSString*** |  | [optional] 
**consistency** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


