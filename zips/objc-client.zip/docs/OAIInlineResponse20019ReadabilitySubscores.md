# OAIInlineResponse20019ReadabilitySubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **NSNumber*** |  | [optional] 
**forcast** | **NSNumber*** |  | [optional] 
**flesch** | **NSNumber*** |  | [optional] 
**smog** | **NSNumber*** |  | [optional] 
**ari** | **NSNumber*** |  | [optional] 
**lix** | **NSNumber*** |  | [optional] 
**colemanLiau** | **NSNumber*** |  | [optional] 
**kincaid** | **NSNumber*** |  | [optional] 
**fog** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


