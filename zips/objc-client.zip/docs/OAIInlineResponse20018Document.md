# OAIInlineResponse20018Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | **NSString*** |  | [optional] 
**confidence** | **NSNumber*** |  | [optional] 
**averageConfidence** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


