# OAIInlineResponse20020Dates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **NSNumber*** |  | [optional] 
**date** | **NSString*** |  | [optional] 
**normalizedDate** | [**OAINull***](OAINull.md) |  | [optional] 
**tag** | **NSString*** |  | [optional] 
**endPosition** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


