# OAIInlineResponse2007Images

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **NSNumber*** |  | [optional] 
**url** | **NSString*** |  | [optional] 
**height** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


