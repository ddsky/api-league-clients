# OAIDetectSentiment200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**OAIDetectSentiment200ResponseDocument***](OAIDetectSentiment200ResponseDocument.md) |  | [optional] 
**sentences** | [**NSArray&lt;OAIDetectSentiment200ResponseSentencesInner&gt;***](OAIDetectSentiment200ResponseSentencesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


