# OAIInlineResponse20018Readability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20018ReadabilityMainscores***](OAIInlineResponse20018ReadabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20018ReadabilitySubscores***](OAIInlineResponse20018ReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


