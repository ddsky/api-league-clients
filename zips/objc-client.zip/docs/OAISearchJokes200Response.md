# OAISearchJokes200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**NSArray&lt;OAISearchJokes200ResponseJokesInner&gt;***](OAISearchJokes200ResponseJokesInner.md) |  | [optional] 
**available** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


