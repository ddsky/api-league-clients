# OAIInlineResponse20018Skimmability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIInlineResponse20018SkimmabilityMainscores***](OAIInlineResponse20018SkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIInlineResponse20018SkimmabilitySubscores***](OAIInlineResponse20018SkimmabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


