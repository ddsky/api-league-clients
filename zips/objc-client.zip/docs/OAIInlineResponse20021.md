# OAIInlineResponse20021

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**NSArray&lt;OAIInlineResponse20021Dates&gt;***](OAIInlineResponse20021Dates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


