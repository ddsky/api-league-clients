# OAIScoreText200ResponseSkimmability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIScoreText200ResponseSkimmabilityMainscores***](OAIScoreText200ResponseSkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIScoreText200ResponseSkimmabilitySubscores***](OAIScoreText200ResponseSkimmabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


