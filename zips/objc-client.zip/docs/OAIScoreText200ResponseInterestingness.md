# OAIScoreText200ResponseInterestingness

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**OAIScoreText200ResponseSkimmabilityMainscores***](OAIScoreText200ResponseSkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**OAIScoreText200ResponseInterestingnessSubscores***](OAIScoreText200ResponseInterestingnessSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


