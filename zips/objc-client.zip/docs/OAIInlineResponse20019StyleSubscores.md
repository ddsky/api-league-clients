# OAIInlineResponse20019StyleSubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abbreviationScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**styleScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 
**spellingScore** | **NSArray&lt;NSNumber*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


