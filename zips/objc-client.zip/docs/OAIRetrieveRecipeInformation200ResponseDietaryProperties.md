# OAIRetrieveRecipeInformation200ResponseDietaryProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lowFodmap** | **NSNumber*** |  | [optional] 
**vegetarian** | **NSNumber*** |  | [optional] 
**vegan** | **NSNumber*** |  | [optional] 
**glutenFree** | **NSNumber*** |  | [optional] 
**dairyFree** | **NSNumber*** |  | [optional] 
**gaps** | **NSString*** |  | [optional] 
**diets** | **NSArray&lt;NSString*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


