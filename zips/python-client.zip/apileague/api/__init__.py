# flake8: noqa

# import apis into api package
from apileague.api.art_api import ArtApi
from apileague.api.books_api import BooksApi
from apileague.api.humor_api import HumorApi
from apileague.api.knowledge_api import KnowledgeApi
from apileague.api.math_api import MathApi
from apileague.api.media_api import MediaApi
from apileague.api.news_api import NewsApi
from apileague.api.storage_api import StorageApi
from apileague.api.text_api import TextApi
from apileague.api.web_api import WebApi

