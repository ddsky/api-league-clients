# ExtractAuthors200ResponseAuthorsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **str** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from apileague.models.extract_authors200_response_authors_inner import ExtractAuthors200ResponseAuthorsInner

# TODO update the JSON string below
json = "{}"
# create an instance of ExtractAuthors200ResponseAuthorsInner from a JSON string
extract_authors200_response_authors_inner_instance = ExtractAuthors200ResponseAuthorsInner.from_json(json)
# print the JSON string representation of the object
print(ExtractAuthors200ResponseAuthorsInner.to_json())

# convert the object into a dict
extract_authors200_response_authors_inner_dict = extract_authors200_response_authors_inner_instance.to_dict()
# create an instance of ExtractAuthors200ResponseAuthorsInner from a dict
extract_authors200_response_authors_inner_from_dict = ExtractAuthors200ResponseAuthorsInner.from_dict(extract_authors200_response_authors_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


