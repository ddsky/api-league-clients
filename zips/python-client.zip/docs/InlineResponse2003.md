# InlineResponse2003


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str, none_type** |  | [optional] 
**text** | **str, none_type** |  | [optional] 
**url** | **str, none_type** |  | [optional] 
**image** | **str, none_type** |  | [optional] 
**publish_date** | **str, none_type** |  | [optional] 
**author** | **str, none_type** |  | [optional] 
**language** | **str, none_type** |  | [optional] 
**source_country** | **str, none_type** |  | [optional] 
**sentiment** | **float** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


