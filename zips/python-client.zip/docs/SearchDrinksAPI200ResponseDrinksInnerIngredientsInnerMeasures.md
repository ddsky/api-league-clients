# SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

## Example

```python
from apileague.models.search_drinks_api200_response_drinks_inner_ingredients_inner_measures import SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures

# TODO update the JSON string below
json = "{}"
# create an instance of SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures from a JSON string
search_drinks_api200_response_drinks_inner_ingredients_inner_measures_instance = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.from_json(json)
# print the JSON string representation of the object
print(SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.to_json())

# convert the object into a dict
search_drinks_api200_response_drinks_inner_ingredients_inner_measures_dict = search_drinks_api200_response_drinks_inner_ingredients_inner_measures_instance.to_dict()
# create an instance of SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures from a dict
search_drinks_api200_response_drinks_inner_ingredients_inner_measures_from_dict = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.from_dict(search_drinks_api200_response_drinks_inner_ingredients_inner_measures_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


