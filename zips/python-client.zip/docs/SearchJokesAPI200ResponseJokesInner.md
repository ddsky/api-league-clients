# SearchJokesAPI200ResponseJokesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joke** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_jokes_api200_response_jokes_inner import SearchJokesAPI200ResponseJokesInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchJokesAPI200ResponseJokesInner from a JSON string
search_jokes_api200_response_jokes_inner_instance = SearchJokesAPI200ResponseJokesInner.from_json(json)
# print the JSON string representation of the object
print(SearchJokesAPI200ResponseJokesInner.to_json())

# convert the object into a dict
search_jokes_api200_response_jokes_inner_dict = search_jokes_api200_response_jokes_inner_instance.to_dict()
# create an instance of SearchJokesAPI200ResponseJokesInner from a dict
search_jokes_api200_response_jokes_inner_from_dict = SearchJokesAPI200ResponseJokesInner.from_dict(search_jokes_api200_response_jokes_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


