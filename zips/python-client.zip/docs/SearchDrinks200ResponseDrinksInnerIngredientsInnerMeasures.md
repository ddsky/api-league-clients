# SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

## Example

```python
from apileague.models.search_drinks200_response_drinks_inner_ingredients_inner_measures import SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures

# TODO update the JSON string below
json = "{}"
# create an instance of SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures from a JSON string
search_drinks200_response_drinks_inner_ingredients_inner_measures_instance = SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures.from_json(json)
# print the JSON string representation of the object
print(SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures.to_json())

# convert the object into a dict
search_drinks200_response_drinks_inner_ingredients_inner_measures_dict = search_drinks200_response_drinks_inner_ingredients_inner_measures_instance.to_dict()
# create an instance of SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures from a dict
search_drinks200_response_drinks_inner_ingredients_inner_measures_from_dict = SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures.from_dict(search_drinks200_response_drinks_inner_ingredients_inner_measures_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


