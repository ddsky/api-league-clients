# StoreKeyValueGETAPI200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 

## Example

```python
from apileague.models.store_key_value_getapi200_response import StoreKeyValueGETAPI200Response

# TODO update the JSON string below
json = "{}"
# create an instance of StoreKeyValueGETAPI200Response from a JSON string
store_key_value_getapi200_response_instance = StoreKeyValueGETAPI200Response.from_json(json)
# print the JSON string representation of the object
print(StoreKeyValueGETAPI200Response.to_json())

# convert the object into a dict
store_key_value_getapi200_response_dict = store_key_value_getapi200_response_instance.to_dict()
# create an instance of StoreKeyValueGETAPI200Response from a dict
store_key_value_getapi200_response_from_dict = StoreKeyValueGETAPI200Response.from_dict(store_key_value_getapi200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


