# SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_games_api200_response_active_filter_options_inner_values_inner import SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner from a JSON string
search_games_api200_response_active_filter_options_inner_values_inner_instance = SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.from_json(json)
# print the JSON string representation of the object
print(SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.to_json())

# convert the object into a dict
search_games_api200_response_active_filter_options_inner_values_inner_dict = search_games_api200_response_active_filter_options_inner_values_inner_instance.to_dict()
# create an instance of SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner from a dict
search_games_api200_response_active_filter_options_inner_values_inner_from_dict = SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.from_dict(search_games_api200_response_active_filter_options_inner_values_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


