# SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**image** | **str** |  | [optional] 
**id** | **int** |  | [optional] 

## Example

```python
from apileague.models.search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner import SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner from a JSON string
search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner_instance = SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.from_json(json)
# print the JSON string representation of the object
print(SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.to_json())

# convert the object into a dict
search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner_dict = search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner_instance.to_dict()
# create an instance of SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner from a dict
search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner_from_dict = SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.from_dict(search_drinks200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


