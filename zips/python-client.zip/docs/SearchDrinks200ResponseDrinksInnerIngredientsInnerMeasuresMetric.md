# SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | **str** |  | [optional] 
**amount** | **float** |  | [optional] 
**unit_long** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_drinks200_response_drinks_inner_ingredients_inner_measures_metric import SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric

# TODO update the JSON string below
json = "{}"
# create an instance of SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric from a JSON string
search_drinks200_response_drinks_inner_ingredients_inner_measures_metric_instance = SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.from_json(json)
# print the JSON string representation of the object
print(SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.to_json())

# convert the object into a dict
search_drinks200_response_drinks_inner_ingredients_inner_measures_metric_dict = search_drinks200_response_drinks_inner_ingredients_inner_measures_metric_instance.to_dict()
# create an instance of SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric from a dict
search_drinks200_response_drinks_inner_ingredients_inner_measures_metric_from_dict = SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.from_dict(search_drinks200_response_drinks_inner_ingredients_inner_measures_metric_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


