# SearchMemesAPI200ResponseMemesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_memes_api200_response_memes_inner import SearchMemesAPI200ResponseMemesInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchMemesAPI200ResponseMemesInner from a JSON string
search_memes_api200_response_memes_inner_instance = SearchMemesAPI200ResponseMemesInner.from_json(json)
# print the JSON string representation of the object
print(SearchMemesAPI200ResponseMemesInner.to_json())

# convert the object into a dict
search_memes_api200_response_memes_inner_dict = search_memes_api200_response_memes_inner_instance.to_dict()
# create an instance of SearchMemesAPI200ResponseMemesInner from a dict
search_memes_api200_response_memes_inner_from_dict = SearchMemesAPI200ResponseMemesInner.from_dict(search_memes_api200_response_memes_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


