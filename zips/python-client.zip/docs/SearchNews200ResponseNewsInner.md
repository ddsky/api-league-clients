# SearchNews200ResponseNewsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **str** |  | [optional] 
**image** | **str** |  | [optional] 
**sentiment** | **float** |  | [optional] 
**source_country** | **str** |  | [optional] 
**language** | **str** |  | [optional] 
**id** | **int** |  | [optional] 
**text** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**publish_date** | **str** |  | [optional] 
**url** | **str** |  | [optional] 
**authors** | **List[Optional[str]]** |  | [optional] 

## Example

```python
from apileague.models.search_news200_response_news_inner import SearchNews200ResponseNewsInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchNews200ResponseNewsInner from a JSON string
search_news200_response_news_inner_instance = SearchNews200ResponseNewsInner.from_json(json)
# print the JSON string representation of the object
print SearchNews200ResponseNewsInner.to_json()

# convert the object into a dict
search_news200_response_news_inner_dict = search_news200_response_news_inner_instance.to_dict()
# create an instance of SearchNews200ResponseNewsInner from a dict
search_news200_response_news_inner_form_dict = search_news200_response_news_inner.from_dict(search_news200_response_news_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


