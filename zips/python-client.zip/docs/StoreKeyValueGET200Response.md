# StoreKeyValueGET200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 

## Example

```python
from apileague.models.store_key_value_get200_response import StoreKeyValueGET200Response

# TODO update the JSON string below
json = "{}"
# create an instance of StoreKeyValueGET200Response from a JSON string
store_key_value_get200_response_instance = StoreKeyValueGET200Response.from_json(json)
# print the JSON string representation of the object
print(StoreKeyValueGET200Response.to_json())

# convert the object into a dict
store_key_value_get200_response_dict = store_key_value_get200_response_instance.to_dict()
# create an instance of StoreKeyValueGET200Response from a dict
store_key_value_get200_response_from_dict = StoreKeyValueGET200Response.from_dict(store_key_value_get200_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


