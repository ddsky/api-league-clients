# SearchJokes200ResponseJokesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joke** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_jokes200_response_jokes_inner import SearchJokes200ResponseJokesInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchJokes200ResponseJokesInner from a JSON string
search_jokes200_response_jokes_inner_instance = SearchJokes200ResponseJokesInner.from_json(json)
# print the JSON string representation of the object
print SearchJokes200ResponseJokesInner.to_json()

# convert the object into a dict
search_jokes200_response_jokes_inner_dict = search_jokes200_response_jokes_inner_instance.to_dict()
# create an instance of SearchJokes200ResponseJokesInner from a dict
search_jokes200_response_jokes_inner_form_dict = search_jokes200_response_jokes_inner.from_dict(search_jokes200_response_jokes_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


