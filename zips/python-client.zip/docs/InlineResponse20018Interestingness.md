# InlineResponse20018Interestingness


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20018SkimmabilityMainscores**](InlineResponse20018SkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**InlineResponse20018InterestingnessSubscores**](InlineResponse20018InterestingnessSubscores.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


