# SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**link** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_royalty_free_images_api200_response_images_inner_license import SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense

# TODO update the JSON string below
json = "{}"
# create an instance of SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense from a JSON string
search_royalty_free_images_api200_response_images_inner_license_instance = SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense.from_json(json)
# print the JSON string representation of the object
print(SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense.to_json())

# convert the object into a dict
search_royalty_free_images_api200_response_images_inner_license_dict = search_royalty_free_images_api200_response_images_inner_license_instance.to_dict()
# create an instance of SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense from a dict
search_royalty_free_images_api200_response_images_inner_license_from_dict = SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense.from_dict(search_royalty_free_images_api200_response_images_inner_license_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


