# SearchMemes200ResponseMemesInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

## Example

```python
from apileague.models.search_memes200_response_memes_inner import SearchMemes200ResponseMemesInner

# TODO update the JSON string below
json = "{}"
# create an instance of SearchMemes200ResponseMemesInner from a JSON string
search_memes200_response_memes_inner_instance = SearchMemes200ResponseMemesInner.from_json(json)
# print the JSON string representation of the object
print SearchMemes200ResponseMemesInner.to_json()

# convert the object into a dict
search_memes200_response_memes_inner_dict = search_memes200_response_memes_inner_instance.to_dict()
# create an instance of SearchMemes200ResponseMemesInner from a dict
search_memes200_response_memes_inner_form_dict = search_memes200_response_memes_inner.from_dict(search_memes200_response_memes_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


