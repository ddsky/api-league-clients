# RetrieveRecipeInformation200ResponseTimes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_minutes** | **int** |  | [optional] 

## Example

```python
from apileague.models.retrieve_recipe_information200_response_times import RetrieveRecipeInformation200ResponseTimes

# TODO update the JSON string below
json = "{}"
# create an instance of RetrieveRecipeInformation200ResponseTimes from a JSON string
retrieve_recipe_information200_response_times_instance = RetrieveRecipeInformation200ResponseTimes.from_json(json)
# print the JSON string representation of the object
print RetrieveRecipeInformation200ResponseTimes.to_json()

# convert the object into a dict
retrieve_recipe_information200_response_times_dict = retrieve_recipe_information200_response_times_instance.to_dict()
# create an instance of RetrieveRecipeInformation200ResponseTimes from a dict
retrieve_recipe_information200_response_times_form_dict = retrieve_recipe_information200_response_times.from_dict(retrieve_recipe_information200_response_times_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


