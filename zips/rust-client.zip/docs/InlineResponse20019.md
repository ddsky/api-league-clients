# InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_words** | Option<**i32**> |  | [optional]
**number_of_sentences** | Option<**i32**> |  | [optional]
**readability** | Option<[**crate::models::InlineResponse20019Readability**](inline_response_200_19_readability.md)> |  | [optional]
**skimmability** | Option<[**crate::models::InlineResponse20019Skimmability**](inline_response_200_19_skimmability.md)> |  | [optional]
**interestingness** | Option<[**crate::models::InlineResponse20019Interestingness**](inline_response_200_19_interestingness.md)> |  | [optional]
**style** | Option<[**crate::models::InlineResponse20019Style**](inline_response_200_19_style.md)> |  | [optional]
**total_score** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


