# TopNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**top_news** | Option<[**Vec<models::TopNews200ResponseTopNewsInner>**](topNews_200_response_top_news_inner.md)> |  | [optional]
**language** | Option<**String**> |  | [optional]
**country** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


