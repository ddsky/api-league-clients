# ScoreReadability200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | Option<[**models::ScoreText200ResponseReadability**](scoreText_200_response_readability.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


