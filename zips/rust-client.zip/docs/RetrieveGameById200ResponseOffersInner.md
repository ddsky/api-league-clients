# RetrieveGameById200ResponseOffersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**store_name** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**price** | Option<[**models::RetrieveGameById200ResponseOffersInnerPrice**](retrieveGameById_200_response_offers_inner_price.md)> |  | [optional]
**platform** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


