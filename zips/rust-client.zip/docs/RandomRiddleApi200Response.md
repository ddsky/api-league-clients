# RandomRiddleApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**riddle** | Option<**String**> |  | [optional]
**answer** | Option<**String**> |  | [optional]
**difficulty** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


