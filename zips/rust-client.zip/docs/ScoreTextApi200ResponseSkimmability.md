# ScoreTextApi200ResponseSkimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**models::ScoreTextApi200ResponseSkimmabilityMainscores**](scoreTextAPI_200_response_skimmability_mainscores.md)> |  | [optional]
**subscores** | Option<[**models::ScoreTextApi200ResponseSkimmabilitySubscores**](scoreTextAPI_200_response_skimmability_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


