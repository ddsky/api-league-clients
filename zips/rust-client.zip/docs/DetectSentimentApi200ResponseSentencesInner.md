# DetectSentimentApi200ResponseSentencesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | Option<**String**> |  | [optional]
**offset** | Option<**i32**> |  | [optional]
**confidence** | Option<**i32**> |  | [optional]
**length** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


