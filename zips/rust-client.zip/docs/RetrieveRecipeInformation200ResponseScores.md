# RetrieveRecipeInformation200ResponseScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta_score** | Option<**f32**> |  | [optional]
**weight_watcher_smart_points** | Option<**i32**> |  | [optional]
**health_score** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


