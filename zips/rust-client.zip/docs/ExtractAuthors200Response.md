# ExtractAuthors200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | Option<[**Vec<models::ExtractAuthors200ResponseAuthorsInner>**](extractAuthors_200_response_authors_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


