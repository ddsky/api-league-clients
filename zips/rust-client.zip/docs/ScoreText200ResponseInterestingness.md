# ScoreText200ResponseInterestingness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**models::ScoreText200ResponseSkimmabilityMainscores**](scoreText_200_response_skimmability_mainscores.md)> |  | [optional]
**subscores** | Option<[**models::ScoreText200ResponseInterestingnessSubscores**](scoreText_200_response_interestingness_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


