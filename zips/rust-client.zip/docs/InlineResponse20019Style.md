# InlineResponse20019Style

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**crate::models::InlineResponse20019ReadabilityMainscores**](inline_response_200_19_readability_mainscores.md)> |  | [optional]
**subscores** | Option<[**crate::models::InlineResponse20019StyleSubscores**](inline_response_200_19_style_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


