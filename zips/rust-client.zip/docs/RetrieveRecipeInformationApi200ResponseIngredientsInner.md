# RetrieveRecipeInformationApi200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**i32**> |  | [optional]
**aisle** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**consistency** | Option<**String**> |  | [optional]
**name** | Option<**String**> |  | [optional]
**original** | Option<**String**> |  | [optional]
**amount** | Option<**f64**> |  | [optional]
**unit** | Option<**String**> |  | [optional]
**meta** | Option<**Vec<String>**> |  | [optional]
**measures** | Option<[**models::RetrieveRecipeInformationApi200ResponseIngredientsInnerMeasures**](retrieveRecipeInformationAPI_200_response_ingredients_inner_measures.md)> |  | [optional]
**original_name** | Option<**String**> |  | [optional]
**name_clean** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


