# SearchMemes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | Option<[**Vec<crate::models::SearchMemes200ResponseMemesInner>**](searchMemes_200_response_memes_inner.md)> |  | [optional]
**available** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


