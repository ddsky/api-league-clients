# RetrieveRecipeInformation200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | Option<**f32**> |  | [optional]
**spiciness** | Option<**i32**> |  | [optional]
**saltiness** | Option<**i32**> |  | [optional]
**bitterness** | Option<**f32**> |  | [optional]
**savoriness** | Option<**f32**> |  | [optional]
**sweetness** | Option<**f32**> |  | [optional]
**sourness** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


