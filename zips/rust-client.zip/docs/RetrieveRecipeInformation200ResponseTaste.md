# RetrieveRecipeInformation200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | Option<**f64**> |  | [optional]
**spiciness** | Option<**i32**> |  | [optional]
**saltiness** | Option<**i32**> |  | [optional]
**bitterness** | Option<**f64**> |  | [optional]
**savoriness** | Option<**f64**> |  | [optional]
**sweetness** | Option<**f64**> |  | [optional]
**sourness** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


