# SearchRecipes200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | Option<**Vec<String>**> |  | [optional]
**nutrition** | Option<[**crate::models::SearchRecipes200ResponseRecipesInnerNutrition**](searchRecipes_200_response_recipes_inner_nutrition.md)> |  | [optional]
**id** | Option<**i32**> |  | [optional]
**title** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


