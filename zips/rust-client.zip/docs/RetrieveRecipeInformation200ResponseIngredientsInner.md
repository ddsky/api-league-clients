# RetrieveRecipeInformation200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | Option<**String**> |  | [optional]
**name_clean** | Option<**String**> |  | [optional]
**amount** | Option<**f32**> |  | [optional]
**unit** | Option<**String**> |  | [optional]
**measures** | Option<[**crate::models::RetrieveRecipeInformation200ResponseIngredientsInnerMeasures**](retrieveRecipeInformation_200_response_ingredients_inner_measures.md)> |  | [optional]
**original** | Option<**String**> |  | [optional]
**meta** | Option<**Vec<String>**> |  | [optional]
**original_name** | Option<**String**> |  | [optional]
**name** | Option<**String**> |  | [optional]
**id** | Option<**i32**> |  | [optional]
**aisle** | Option<**String**> |  | [optional]
**consistency** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


