# DetectSentiment200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | Option<[**models::DetectSentiment200ResponseDocument**](detectSentiment_200_response_document.md)> |  | [optional]
**sentences** | Option<[**Vec<models::DetectSentiment200ResponseSentencesInner>**](detectSentiment_200_response_sentences_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


