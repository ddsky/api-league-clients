# DetectSentimentApi200ResponseDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | Option<**String**> |  | [optional]
**confidence** | Option<**i32**> |  | [optional]
**average_confidence** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


