# SearchRecipes200ResponseRecipesInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | Option<[**Vec<models::SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner>**](searchRecipes_200_response_recipes_inner_nutrition_nutrients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


