# InlineResponse2002

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**available** | Option<**i32**> |  | [optional]
**news** | Option<[**Vec<crate::models::InlineResponse2002News>**](inline_response_200_2_news.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


