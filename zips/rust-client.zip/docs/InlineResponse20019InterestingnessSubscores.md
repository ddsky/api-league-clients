# InlineResponse20019InterestingnessSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title_rating_score** | Option<**Vec<i32>**> |  | [optional]
**quote_score** | Option<**Vec<i32>**> |  | [optional]
**length_score** | Option<**Vec<i32>**> |  | [optional]
**link_score** | Option<**Vec<i32>**> |  | [optional]
**google_hits_score** | Option<**Vec<i32>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


