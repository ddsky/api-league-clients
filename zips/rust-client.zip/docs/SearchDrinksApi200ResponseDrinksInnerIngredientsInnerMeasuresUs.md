# SearchDrinksApi200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | Option<**i32**> |  | [optional]
**unit_short** | Option<**String**> |  | [optional]
**unit_long** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


