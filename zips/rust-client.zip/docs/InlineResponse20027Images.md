# InlineResponse20027Images

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | Option<**i32**> |  | [optional]
**license** | Option<[**crate::models::InlineResponse20027License**](inline_response_200_27_license.md)> |  | [optional]
**thumbnail** | Option<**String**> |  | [optional]
**id** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]
**height** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


