# InlineResponse2004

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | Option<[**Vec<crate::models::InlineResponse2004Jokes>**](inline_response_200_4_jokes.md)> |  | [optional]
**available** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


