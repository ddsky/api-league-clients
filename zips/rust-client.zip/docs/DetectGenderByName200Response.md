# DetectGenderByName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**probability_male** | Option<**f64**> |  | [optional]
**probability_female** | Option<**f64**> |  | [optional]
**popularity** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


