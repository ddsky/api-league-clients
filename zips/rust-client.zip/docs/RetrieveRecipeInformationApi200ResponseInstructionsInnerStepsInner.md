# RetrieveRecipeInformationApi200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | Option<**i32**> |  | [optional]
**ingredients** | Option<[**Vec<models::SearchDrinksApi200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner>**](searchDrinksAPI_200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]
**equipment** | Option<[**Vec<models::SearchDrinksApi200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner>**](searchDrinksAPI_200_response_drinks_inner_instructions_inner_steps_inner_ingredients_inner.md)> |  | [optional]
**step** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


