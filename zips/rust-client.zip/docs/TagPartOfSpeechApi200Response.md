# TagPartOfSpeechApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagged_text** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


