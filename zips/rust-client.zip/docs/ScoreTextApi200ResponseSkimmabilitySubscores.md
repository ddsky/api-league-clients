# ScoreTextApi200ResponseSkimmabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bullet_point_ratio_score** | Option<**Vec<i32>**> |  | [optional]
**image_score** | Option<**Vec<i32>**> |  | [optional]
**highlighted_word_ratio_score** | Option<**Vec<i32>**> |  | [optional]
**video_score** | Option<**Vec<i32>**> |  | [optional]
**paragraph_score** | Option<**Vec<i32>**> |  | [optional]
**paragraph_headline_ratio_score** | Option<**Vec<i32>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


