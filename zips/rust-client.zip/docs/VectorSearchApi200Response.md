# VectorSearchApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vectors** | Option<[**Vec<models::VectorSearchApi200ResponseVectorsInner>**](vectorSearchAPI_200_response_vectors_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


