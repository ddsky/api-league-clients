# SearchGifs200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | Option<[**Vec<models::SearchGifs200ResponseImagesInner>**](searchGifs_200_response_images_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


