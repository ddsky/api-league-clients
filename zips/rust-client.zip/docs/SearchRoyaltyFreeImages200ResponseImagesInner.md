# SearchRoyaltyFreeImages200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | Option<**i32**> |  | [optional]
**license** | Option<[**crate::models::SearchRoyaltyFreeImages200ResponseImagesInnerLicense**](searchRoyaltyFreeImages_200_response_images_inner_license.md)> |  | [optional]
**thumbnail** | Option<**String**> |  | [optional]
**id** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]
**height** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


