# RetrieveRecipeInformationApi200ResponseDietaryProperties

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**low_fodmap** | Option<**bool**> |  | [optional]
**vegetarian** | Option<**bool**> |  | [optional]
**vegan** | Option<**bool**> |  | [optional]
**gluten_free** | Option<**bool**> |  | [optional]
**dairy_free** | Option<**bool**> |  | [optional]
**gaps** | Option<**String**> |  | [optional]
**diets** | Option<**Vec<String>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


