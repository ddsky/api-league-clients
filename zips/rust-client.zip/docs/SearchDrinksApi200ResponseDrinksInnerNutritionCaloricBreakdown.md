# SearchDrinksApi200ResponseDrinksInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_fat** | Option<**f64**> |  | [optional]
**percent_carbs** | Option<**f64**> |  | [optional]
**percent_protein** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


