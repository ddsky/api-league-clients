# SearchRestaurants200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | Option<[**crate::models::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](searchRestaurants_200_response_restaurants_inner_local_hours_operational.md)> |  | [optional]
**delivery** | Option<[**crate::models::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](searchRestaurants_200_response_restaurants_inner_local_hours_operational.md)> |  | [optional]
**pickup** | Option<[**crate::models::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](searchRestaurants_200_response_restaurants_inner_local_hours_operational.md)> |  | [optional]
**dine_in** | Option<[**crate::models::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational**](searchRestaurants_200_response_restaurants_inner_local_hours_operational.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


