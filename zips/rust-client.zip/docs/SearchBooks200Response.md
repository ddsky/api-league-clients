# SearchBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**offset** | Option<**i32**> |  | [optional]
**books** | Option<[**Vec<models::SearchBooks200ResponseBooksInner>**](searchBooks_200_response_books_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


