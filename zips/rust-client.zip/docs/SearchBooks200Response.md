# SearchBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_results** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**offset** | Option<**i32**> |  | [optional]
**books** | Option<[**Vec<Vec<models::SearchBooks200ResponseBooksInnerInner>>**](Vec.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


