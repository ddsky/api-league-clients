# RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | Option<**String**> |  | [optional]
**amount** | Option<**f64**> |  | [optional]
**unit_long** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


