# ExtractEntitiesApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | Option<[**Vec<models::ExtractEntitiesApi200ResponseEntitiesInner>**](extractEntitiesAPI_200_response_entities_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


