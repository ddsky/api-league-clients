# ScoreText200ResponseSkimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**crate::models::ScoreText200ResponseSkimmabilityMainscores**](scoreText_200_response_skimmability_mainscores.md)> |  | [optional]
**subscores** | Option<[**crate::models::ScoreText200ResponseSkimmabilitySubscores**](scoreText_200_response_skimmability_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


