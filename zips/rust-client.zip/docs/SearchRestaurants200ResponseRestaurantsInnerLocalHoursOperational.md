# SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | Option<**String**> |  | [optional]
**saturday** | Option<**String**> |  | [optional]
**tuesday** | Option<**String**> |  | [optional]
**thursday** | Option<**String**> |  | [optional]
**friday** | Option<**String**> |  | [optional]
**wednesday** | Option<**String**> |  | [optional]
**monday** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


