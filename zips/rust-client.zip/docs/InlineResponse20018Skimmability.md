# InlineResponse20018Skimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**crate::models::InlineResponse20018SkimmabilityMainscores**](inline_response_200_18_skimmability_mainscores.md)> |  | [optional]
**subscores** | Option<[**crate::models::InlineResponse20018SkimmabilitySubscores**](inline_response_200_18_skimmability_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


