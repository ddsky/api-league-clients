# ExtractNewsApi200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | Option<**i32**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]
**height** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


