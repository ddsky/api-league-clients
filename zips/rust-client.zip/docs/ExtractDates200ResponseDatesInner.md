# ExtractDates200ResponseDatesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | Option<**i32**> |  | [optional]
**date** | Option<**String**> |  | [optional]
**normalized_date** | Option<**f32**> |  | [optional]
**tag** | Option<**String**> |  | [optional]
**end_position** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


