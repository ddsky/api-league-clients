# SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**recipes** | Option<[**Vec<models::SearchRecipes200ResponseRecipesInner>**](searchRecipes_200_response_recipes_inner.md)> |  | [optional]
**total_results** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


