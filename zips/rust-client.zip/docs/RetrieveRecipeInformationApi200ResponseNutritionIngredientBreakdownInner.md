# RetrieveRecipeInformationApi200ResponseNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**amount** | Option<**f64**> |  | [optional]
**unit** | Option<**String**> |  | [optional]
**id** | Option<**i32**> |  | [optional]
**nutrients** | Option<[**Vec<models::SearchDrinksApi200ResponseDrinksInnerNutritionNutrientsInner>**](searchDrinksAPI_200_response_drinks_inner_nutrition_nutrients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


