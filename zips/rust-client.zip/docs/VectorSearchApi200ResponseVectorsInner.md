# VectorSearchApi200ResponseVectorsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**author** | Option<**String**> |  | [optional]
**image_url** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


