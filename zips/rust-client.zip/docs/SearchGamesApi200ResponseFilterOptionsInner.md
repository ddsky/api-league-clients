# SearchGamesApi200ResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**filter_type** | Option<**String**> |  | [optional]
**key** | Option<**String**> |  | [optional]
**values** | Option<[**Vec<models::SearchGamesApi200ResponseFilterOptionsInnerValuesInner>**](searchGamesAPI_200_response_filter_options_inner_values_inner.md)> |  | [optional]
**filter_connection** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


