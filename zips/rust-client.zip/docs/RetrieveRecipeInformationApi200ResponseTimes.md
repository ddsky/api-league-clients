# RetrieveRecipeInformationApi200ResponseTimes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_minutes** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


