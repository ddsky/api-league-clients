# SearchDrinks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**drinks** | Option<[**Vec<models::SearchDrinks200ResponseDrinksInner>**](searchDrinks_200_response_drinks_inner.md)> |  | [optional]
**total_results** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


