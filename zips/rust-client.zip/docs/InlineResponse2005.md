# InlineResponse2005

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | Option<[**Vec<crate::models::InlineResponse2005Memes>**](inline_response_200_5_memes.md)> |  | [optional]
**available** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


