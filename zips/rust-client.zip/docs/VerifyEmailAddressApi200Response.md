# VerifyEmailAddressApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | Option<**String**> |  | [optional]
**domain** | Option<**String**> |  | [optional]
**first_name** | Option<**String**> |  | [optional]
**middle_name** | Option<**String**> |  | [optional]
**last_name** | Option<**String**> |  | [optional]
**full_name** | Option<**String**> |  | [optional]
**username** | Option<**String**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**result** | Option<**String**> |  | [optional]
**disposable** | Option<**bool**> |  | [optional]
**accept_all** | Option<**bool**> |  | [optional]
**free_provider** | Option<**bool**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


