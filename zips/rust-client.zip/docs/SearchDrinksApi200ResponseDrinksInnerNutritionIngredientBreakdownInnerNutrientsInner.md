# SearchDrinksApi200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**percent_of_daily_needs** | Option<**f64**> |  | [optional]
**amount** | Option<**i32**> |  | [optional]
**unit** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


