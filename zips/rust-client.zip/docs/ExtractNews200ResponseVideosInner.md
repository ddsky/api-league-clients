# ExtractNews200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | Option<**String**> |  | [optional]
**duration** | Option<**i32**> |  | [optional]
**thumbnail** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**url** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


