# SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | Option<**String**> |  | [optional]
**amount** | Option<**i32**> |  | [optional]
**unit** | Option<**String**> |  | [optional]
**id** | Option<**i32**> |  | [optional]
**nutrients** | Option<[**Vec<models::SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner>**](searchDrinks_200_response_drinks_inner_nutrition_ingredient_breakdown_inner_nutrients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


