# SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**available** | Option<**i32**> |  | [optional]
**news** | Option<[**Vec<crate::models::SearchNews200ResponseNewsInner>**](searchNews_200_response_news_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


