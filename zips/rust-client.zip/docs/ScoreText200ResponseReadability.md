# ScoreText200ResponseReadability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**models::ScoreText200ResponseReadabilityMainscores**](scoreText_200_response_readability_mainscores.md)> |  | [optional]
**subscores** | Option<[**models::ScoreText200ResponseReadabilitySubscores**](scoreText_200_response_readability_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


