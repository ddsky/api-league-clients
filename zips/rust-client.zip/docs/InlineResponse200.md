# InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | Option<**i32**> |  | [optional]
**number** | Option<**i32**> |  | [optional]
**offset** | Option<**i32**> |  | [optional]
**books** | Option<[**Vec<crate::models::InlineResponse200Books>**](inline_response_200_books.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


