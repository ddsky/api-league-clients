# ScoreText200ResponseStyle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**crate::models::ScoreText200ResponseReadabilityMainscores**](scoreText_200_response_readability_mainscores.md)> |  | [optional]
**subscores** | Option<[**crate::models::ScoreText200ResponseStyleSubscores**](scoreText_200_response_style_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


