# ExtractEntitiesApi200ResponseEntitiesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | Option<**i32**> |  | [optional]
**image** | Option<**String**> |  | [optional]
**r#type** | Option<**String**> |  | [optional]
**value** | Option<**String**> |  | [optional]
**end_position** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


