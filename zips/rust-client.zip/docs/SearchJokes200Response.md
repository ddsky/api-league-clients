# SearchJokes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | Option<[**Vec<models::SearchJokes200ResponseJokesInner>**](searchJokes_200_response_jokes_inner.md)> |  | [optional]
**available** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


