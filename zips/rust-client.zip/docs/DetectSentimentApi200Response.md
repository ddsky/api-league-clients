# DetectSentimentApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | Option<[**models::DetectSentimentApi200ResponseDocument**](detectSentimentAPI_200_response_document.md)> |  | [optional]
**sentences** | Option<[**Vec<models::DetectSentimentApi200ResponseSentencesInner>**](detectSentimentAPI_200_response_sentences_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


