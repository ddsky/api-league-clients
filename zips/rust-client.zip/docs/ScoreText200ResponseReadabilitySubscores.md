# ScoreText200ResponseReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reading_time_seconds** | Option<**i32**> |  | [optional]
**forcast** | Option<**f64**> |  | [optional]
**flesch** | Option<**f64**> |  | [optional]
**smog** | Option<**f64**> |  | [optional]
**ari** | Option<**f64**> |  | [optional]
**lix** | Option<**f64**> |  | [optional]
**coleman_liau** | Option<**f64**> |  | [optional]
**kincaid** | Option<**f64**> |  | [optional]
**fog** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


