# SearchDrinksApi200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**i32**> |  | [optional]
**name** | Option<**String**> |  | [optional]
**amount** | Option<**i32**> |  | [optional]
**unit** | Option<**String**> |  | [optional]
**nutrients** | Option<[**Vec<models::SearchDrinksApi200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner>**](searchDrinksAPI_200_response_drinks_inner_nutrition_ingredient_breakdown_inner_nutrients_inner.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


