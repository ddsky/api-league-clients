# RetrievePageRankApi200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page_rank** | Option<**f64**> |  | [optional]
**position** | Option<**i32**> |  | [optional]
**percentile** | Option<**f64**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


