# RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_fat** | Option<**f32**> |  | [optional]
**percent_carbs** | Option<**f32**> |  | [optional]
**percent_protein** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


