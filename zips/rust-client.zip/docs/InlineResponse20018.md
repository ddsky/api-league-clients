# InlineResponse20018

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | Option<[**crate::models::InlineResponse20018Document**](inline_response_200_18_document.md)> |  | [optional]
**sentences** | Option<[**Vec<crate::models::InlineResponse20018Sentences>**](inline_response_200_18_sentences.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


