# InlineResponse20018ReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reading_time_seconds** | Option<**i32**> |  | [optional]
**forcast** | Option<**i32**> |  | [optional]
**flesch** | Option<**f32**> |  | [optional]
**smog** | Option<**f32**> |  | [optional]
**ari** | Option<**f32**> |  | [optional]
**lix** | Option<**i32**> |  | [optional]
**coleman_liau** | Option<**f32**> |  | [optional]
**kincaid** | Option<**f32**> |  | [optional]
**fog** | Option<**f32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


