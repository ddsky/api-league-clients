# ScoreTextApi200ResponseStyle

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | Option<[**models::ScoreTextApi200ResponseReadabilityMainscores**](scoreTextAPI_200_response_readability_mainscores.md)> |  | [optional]
**subscores** | Option<[**models::ScoreTextApi200ResponseStyleSubscores**](scoreTextAPI_200_response_style_subscores.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


