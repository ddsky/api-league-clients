# DetectMainImageColor200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**specific_color** | Option<**String**> |  | [optional]
**main_color** | Option<**String**> |  | [optional]
**hex_code** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


