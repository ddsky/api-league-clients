# SearchDrinksApi200ResponseDrinksInnerCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_name** | Option<**String**> |  | [optional]
**source_url** | Option<**String**> |  | [optional]
**text** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


