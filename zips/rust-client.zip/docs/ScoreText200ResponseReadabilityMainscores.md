# ScoreText200ResponseReadabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | Option<**i32**> |  | [optional]
**total** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


