
# InlineResponse20020Dates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **kotlin.Int** |  |  [optional]
**date** | **kotlin.String** |  |  [optional]
**normalizedDate** | [**Null**](Null.md) |  |  [optional]
**tag** | **kotlin.String** |  |  [optional]
**endPosition** | **kotlin.Int** |  |  [optional]



