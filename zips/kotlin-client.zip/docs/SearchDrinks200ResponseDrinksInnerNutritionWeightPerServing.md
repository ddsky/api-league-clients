
# SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



