
# ListWordSynonyms200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synonyms** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]



