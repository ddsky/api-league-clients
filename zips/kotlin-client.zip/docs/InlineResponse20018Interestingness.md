
# InlineResponse20018Interestingness

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20018SkimmabilityMainscores**](InlineResponse20018SkimmabilityMainscores.md) |  |  [optional]
**subscores** | [**InlineResponse20018InterestingnessSubscores**](InlineResponse20018InterestingnessSubscores.md) |  |  [optional]



