
# SearchGamesAPI200ResponseResultsInnerRating

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **count** | **kotlin.Int** |  |  [optional] |
| **mean** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



