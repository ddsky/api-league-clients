
# SearchRoyaltyFreeImages200ResponseImagesInnerLicense

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  |  [optional]
**link** | **kotlin.String** |  |  [optional]



