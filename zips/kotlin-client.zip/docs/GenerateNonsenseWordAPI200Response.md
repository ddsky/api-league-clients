
# GenerateNonsenseWordAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **word** | **kotlin.String** |  |  [optional] |
| **rating** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



