
# ExtractNews200ResponseVideosInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **kotlin.String** |  |  [optional]
**duration** | **kotlin.Int** |  |  [optional]
**thumbnail** | **kotlin.String** |  |  [optional]
**title** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]



