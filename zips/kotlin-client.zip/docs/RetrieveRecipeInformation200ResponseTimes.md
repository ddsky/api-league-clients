
# RetrieveRecipeInformation200ResponseTimes

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **totalMinutes** | **kotlin.Int** |  |  [optional] |



