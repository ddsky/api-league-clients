
# DetectSentimentAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **document** | [**DetectSentimentAPI200ResponseDocument**](DetectSentimentAPI200ResponseDocument.md) |  |  [optional] |
| **sentences** | [**kotlin.collections.List&lt;DetectSentimentAPI200ResponseSentencesInner&gt;**](DetectSentimentAPI200ResponseSentencesInner.md) |  |  [optional] |



