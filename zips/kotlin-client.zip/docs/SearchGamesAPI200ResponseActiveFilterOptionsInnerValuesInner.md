
# SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **match** | **kotlin.String** |  |  [optional] |
| **&#x60;value&#x60;** | **kotlin.String** |  |  [optional] |



