
# ExtractAuthorsAPI200ResponseAuthorsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **link** | **kotlin.String** |  |  [optional] |
| **name** | **kotlin.String** |  |  [optional] |



