
# InlineResponse20026

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **kotlin.String** |  |  [optional]
**plural** | **kotlin.String** |  |  [optional]



