
# RetrieveRecipeInformation200ResponseDietaryProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lowFodmap** | **kotlin.Boolean** |  |  [optional]
**vegetarian** | **kotlin.Boolean** |  |  [optional]
**vegan** | **kotlin.Boolean** |  |  [optional]
**glutenFree** | **kotlin.Boolean** |  |  [optional]
**dairyFree** | **kotlin.Boolean** |  |  [optional]
**gaps** | **kotlin.String** |  |  [optional]
**diets** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]



