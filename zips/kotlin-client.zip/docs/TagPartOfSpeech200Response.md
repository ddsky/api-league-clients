
# TagPartOfSpeech200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **taggedText** | **kotlin.String** |  |  [optional] |



