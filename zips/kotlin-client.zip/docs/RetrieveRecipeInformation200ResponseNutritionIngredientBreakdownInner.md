
# RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  |  [optional]
**amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**unit** | **kotlin.String** |  |  [optional]
**id** | **kotlin.Int** |  |  [optional]
**nutrients** | [**kotlin.collections.List&lt;RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional]



