
# SearchNews200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **kotlin.Int** |  |  [optional]
**number** | **kotlin.Int** |  |  [optional]
**available** | **kotlin.Int** |  |  [optional]
**news** | [**kotlin.collections.List&lt;SearchNews200ResponseNewsInner&gt;**](SearchNews200ResponseNewsInner.md) |  |  [optional]



