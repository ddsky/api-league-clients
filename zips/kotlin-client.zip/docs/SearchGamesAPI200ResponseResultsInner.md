
# SearchGamesAPI200ResponseResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **image** | **kotlin.String** |  |  [optional] |
| **shortDescription** | **kotlin.String** |  |  [optional] |
| **year** | **kotlin.Int** |  |  [optional] |
| **link** | **kotlin.String** |  |  [optional] |
| **rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  |  [optional] |
| **adultOnly** | **kotlin.Boolean** |  |  [optional] |
| **screenshots** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **platforms** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseResultsInnerPlatformsInner&gt;**](SearchGamesAPI200ResponseResultsInnerPlatformsInner.md) |  |  [optional] |
| **microTrailer** | **kotlin.String** |  |  [optional] |
| **name** | **kotlin.String** |  |  [optional] |
| **genre** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **gameplay** | **kotlin.String** |  |  [optional] |



