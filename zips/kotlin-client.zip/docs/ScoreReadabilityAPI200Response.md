
# ScoreReadabilityAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **readability** | [**ScoreTextAPI200ResponseReadability**](ScoreTextAPI200ResponseReadability.md) |  |  [optional] |



