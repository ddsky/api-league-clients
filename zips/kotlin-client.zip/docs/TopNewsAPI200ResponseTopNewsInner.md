
# TopNewsAPI200ResponseTopNewsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **news** | [**kotlin.collections.List&lt;TopNewsAPI200ResponseTopNewsInnerNewsInner&gt;**](TopNewsAPI200ResponseTopNewsInnerNewsInner.md) |  |  [optional] |



