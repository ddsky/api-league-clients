
# RandomMeme200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**type** | **kotlin.String** |  |  [optional]
**width** | **kotlin.Int** |  |  [optional]
**height** | **kotlin.Int** |  |  [optional]
**ratio** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



