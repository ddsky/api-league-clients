
# RetrieveArtworkById200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **id** | **kotlin.Int** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **startDate** | **kotlin.Int** |  |  [optional] |
| **endDate** | **kotlin.Int** |  |  [optional] |
| **description** | **kotlin.String** |  |  [optional] |



