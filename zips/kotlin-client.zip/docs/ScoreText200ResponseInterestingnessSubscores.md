
# ScoreText200ResponseInterestingnessSubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titleRatingScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**quoteScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**lengthScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**linkScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**googleHitsScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]



