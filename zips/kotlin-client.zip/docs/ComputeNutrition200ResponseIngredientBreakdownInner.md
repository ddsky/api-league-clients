
# ComputeNutrition200ResponseIngredientBreakdownInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  |  [optional]
**amount** | **kotlin.Int** |  |  [optional]
**unit** | **kotlin.String** |  |  [optional]
**id** | **kotlin.Int** |  |  [optional]
**nutrients** | [**kotlin.collections.List&lt;ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner&gt;**](ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner.md) |  |  [optional]



