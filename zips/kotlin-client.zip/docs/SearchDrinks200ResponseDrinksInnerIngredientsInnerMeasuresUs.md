
# SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **unitShort** | **kotlin.String** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unitLong** | **kotlin.String** |  |  [optional] |



