
# VerifyEmailAddress200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **email** | **kotlin.String** |  |  [optional] |
| **domain** | **kotlin.String** |  |  [optional] |
| **firstName** | **kotlin.String** |  |  [optional] |
| **middleName** | **kotlin.String** |  |  [optional] |
| **lastName** | **kotlin.String** |  |  [optional] |
| **fullName** | **kotlin.String** |  |  [optional] |
| **username** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **result** | **kotlin.String** |  |  [optional] |
| **disposable** | **kotlin.Boolean** |  |  [optional] |
| **acceptAll** | **kotlin.Boolean** |  |  [optional] |
| **freeProvider** | **kotlin.Boolean** |  |  [optional] |



