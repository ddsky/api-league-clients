
# SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



