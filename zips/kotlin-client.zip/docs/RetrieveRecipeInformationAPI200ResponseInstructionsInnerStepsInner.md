
# RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | **kotlin.Int** |  |  [optional] |
| **ingredients** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **equipment** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **step** | **kotlin.String** |  |  [optional] |



