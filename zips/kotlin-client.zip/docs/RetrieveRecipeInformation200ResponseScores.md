
# RetrieveRecipeInformation200ResponseScores

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **metaScore** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **weightWatcherSmartPoints** | **kotlin.Int** |  |  [optional] |
| **healthScore** | **kotlin.Int** |  |  [optional] |



