
# SearchWebAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **results** | [**kotlin.collections.List&lt;SearchWebAPI200ResponseResultsInner&gt;**](SearchWebAPI200ResponseResultsInner.md) |  |  [optional] |



