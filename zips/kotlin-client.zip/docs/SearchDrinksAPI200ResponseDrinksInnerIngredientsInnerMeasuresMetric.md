
# SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **unitShort** | **kotlin.String** |  |  [optional] |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **unitLong** | **kotlin.String** |  |  [optional] |



