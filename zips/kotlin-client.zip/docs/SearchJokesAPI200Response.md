
# SearchJokesAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **jokes** | [**kotlin.collections.List&lt;SearchJokesAPI200ResponseJokesInner&gt;**](SearchJokesAPI200ResponseJokesInner.md) |  |  [optional] |
| **available** | **kotlin.Int** |  |  [optional] |



