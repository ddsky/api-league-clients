
# SearchGifs200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **images** | [**kotlin.collections.List&lt;SearchGifs200ResponseImagesInner&gt;**](SearchGifs200ResponseImagesInner.md) |  |  [optional] |



