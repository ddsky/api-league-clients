
# PluralizeWord200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **kotlin.String** |  |  [optional]
**plural** | **kotlin.String** |  |  [optional]



