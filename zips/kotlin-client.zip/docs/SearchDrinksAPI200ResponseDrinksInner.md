
# SearchDrinksAPI200ResponseDrinksInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **flavors** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **instructions** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.md) |  |  [optional] |
| **images** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **nutrition** | [**SearchDrinksAPI200ResponseDrinksInnerNutrition**](SearchDrinksAPI200ResponseDrinksInnerNutrition.md) |  |  [optional] |
| **glassType** | **kotlin.String** |  |  [optional] |
| **credits** | [**SearchDrinksAPI200ResponseDrinksInnerCredits**](SearchDrinksAPI200ResponseDrinksInnerCredits.md) |  |  [optional] |
| **pricePerServing** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **description** | **kotlin.String** |  |  [optional] |
| **ingredients** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInner.md) |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **cuisines** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |



