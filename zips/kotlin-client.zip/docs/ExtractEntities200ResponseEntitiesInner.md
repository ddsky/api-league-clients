
# ExtractEntities200ResponseEntitiesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **kotlin.Int** |  |  [optional]
**image** | **kotlin.String** |  |  [optional]
**type** | **kotlin.String** |  |  [optional]
**&#x60;value&#x60;** | **kotlin.String** |  |  [optional]
**endPosition** | **kotlin.Int** |  |  [optional]



