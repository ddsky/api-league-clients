
# SearchWeb200ResponseResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **title** | **kotlin.String** |  |  [optional] |
| **summary** | **kotlin.String** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |



