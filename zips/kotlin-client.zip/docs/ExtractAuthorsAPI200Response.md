
# ExtractAuthorsAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **authors** | [**kotlin.collections.List&lt;ExtractAuthorsAPI200ResponseAuthorsInner&gt;**](ExtractAuthorsAPI200ResponseAuthorsInner.md) |  |  [optional] |



