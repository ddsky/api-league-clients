
# InlineResponse2005Memes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **kotlin.String** |  |  [optional]
**description** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]



