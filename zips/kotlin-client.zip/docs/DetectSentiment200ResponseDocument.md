
# DetectSentiment200ResponseDocument

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **sentiment** | **kotlin.String** |  |  [optional] |
| **confidence** | **kotlin.Int** |  |  [optional] |
| **averageConfidence** | **kotlin.Int** |  |  [optional] |



