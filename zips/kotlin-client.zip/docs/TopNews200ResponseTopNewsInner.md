
# TopNews200ResponseTopNewsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **news** | [**kotlin.collections.List&lt;TopNews200ResponseTopNewsInnerNewsInner&gt;**](TopNews200ResponseTopNewsInnerNewsInner.md) |  |  [optional] |



