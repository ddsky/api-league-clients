
# SearchDrinks200ResponseDrinksInnerIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **image** | **kotlin.String** |  |  [optional] |
| **nameClean** | **kotlin.String** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |
| **measures** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures.md) |  |  [optional] |
| **original** | **kotlin.String** |  |  [optional] |
| **meta** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **originalName** | **kotlin.String** |  |  [optional] |
| **name** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **aisle** | **kotlin.String** |  |  [optional] |
| **consistency** | **kotlin.String** |  |  [optional] |



