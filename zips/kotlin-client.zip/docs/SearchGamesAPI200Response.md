
# SearchGamesAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **sorting** | [**kotlin.Any**](.md) |  |  [optional] |
| **activeFilterOptions** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseActiveFilterOptionsInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInner.md) |  |  [optional] |
| **query** | **kotlin.String** |  |  [optional] |
| **totalResults** | **kotlin.Int** |  |  [optional] |
| **limit** | **kotlin.Int** |  |  [optional] |
| **offset** | **kotlin.Int** |  |  [optional] |
| **results** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseResultsInner&gt;**](SearchGamesAPI200ResponseResultsInner.md) |  |  [optional] |
| **filterOptions** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseFilterOptionsInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInner.md) |  |  [optional] |
| **sortingOptions** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseSortingOptionsInner&gt;**](SearchGamesAPI200ResponseSortingOptionsInner.md) |  |  [optional] |



