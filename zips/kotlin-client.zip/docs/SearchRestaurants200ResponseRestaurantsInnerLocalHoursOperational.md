
# SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **sunday** | **kotlin.String** |  |  [optional] |
| **saturday** | **kotlin.String** |  |  [optional] |
| **tuesday** | **kotlin.String** |  |  [optional] |
| **thursday** | **kotlin.String** |  |  [optional] |
| **friday** | **kotlin.String** |  |  [optional] |
| **wednesday** | **kotlin.String** |  |  [optional] |
| **monday** | **kotlin.String** |  |  [optional] |



