
# InlineResponse20014

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | [**kotlin.collections.List&lt;InlineResponse20014Authors&gt;**](InlineResponse20014Authors.md) |  |  [optional]



