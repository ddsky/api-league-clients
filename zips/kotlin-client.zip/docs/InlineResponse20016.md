
# InlineResponse20016

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**correctedText** | **kotlin.String** |  |  [optional]



