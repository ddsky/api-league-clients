
# VectorSearchAPI200ResponseVectorsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **license** | **kotlin.String** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **author** | **kotlin.String** |  |  [optional] |
| **imageUrl** | **kotlin.String** |  |  [optional] |



