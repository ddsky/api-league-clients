
# DetectSentiment200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **document** | [**DetectSentiment200ResponseDocument**](DetectSentiment200ResponseDocument.md) |  |  [optional] |
| **sentences** | [**kotlin.collections.List&lt;DetectSentiment200ResponseSentencesInner&gt;**](DetectSentiment200ResponseSentencesInner.md) |  |  [optional] |



