
# SearchRecipes200ResponseRecipesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]
**nutrition** | [**SearchRecipes200ResponseRecipesInnerNutrition**](SearchRecipes200ResponseRecipesInnerNutrition.md) |  |  [optional]
**id** | **kotlin.Int** |  |  [optional]
**title** | **kotlin.String** |  |  [optional]



