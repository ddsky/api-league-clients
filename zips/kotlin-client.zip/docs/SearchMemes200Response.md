
# SearchMemes200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **memes** | [**kotlin.collections.List&lt;SearchMemes200ResponseMemesInner&gt;**](SearchMemes200ResponseMemesInner.md) |  |  [optional] |
| **available** | **kotlin.Int** |  |  [optional] |



