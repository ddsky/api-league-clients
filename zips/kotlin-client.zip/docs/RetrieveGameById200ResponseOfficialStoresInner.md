
# RetrieveGameById200ResponseOfficialStoresInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **url** | **kotlin.String** |  |  [optional] |
| **source** | **kotlin.String** |  |  [optional] |



