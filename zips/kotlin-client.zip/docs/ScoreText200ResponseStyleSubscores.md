
# ScoreText200ResponseStyleSubscores

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **abbreviationScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional] |
| **styleScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional] |
| **spellingScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional] |



