
# RetrieveRecipeInformation200ResponseInstructionsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  |  [optional]
**steps** | [**kotlin.collections.List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  |  [optional]



