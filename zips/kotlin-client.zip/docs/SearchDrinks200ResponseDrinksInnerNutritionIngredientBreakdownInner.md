
# SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **nutrients** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional] |



