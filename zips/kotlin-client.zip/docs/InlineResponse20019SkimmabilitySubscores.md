
# InlineResponse20019SkimmabilitySubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulletPointRatioScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**imageScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**highlightedWordRatioScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**videoScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**paragraphScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]
**paragraphHeadlineRatioScore** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional]



