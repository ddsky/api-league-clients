
# InlineResponse2004Jokes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joke** | **kotlin.String** |  |  [optional]



