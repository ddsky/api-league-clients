
# DetectMainImageColorAPI200ResponseInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **specificColor** | **kotlin.String** |  |  [optional] |
| **mainColor** | **kotlin.String** |  |  [optional] |
| **hexCode** | **kotlin.String** |  |  [optional] |



