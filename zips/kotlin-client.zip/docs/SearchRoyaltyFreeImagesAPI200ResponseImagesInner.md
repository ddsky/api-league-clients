
# SearchRoyaltyFreeImagesAPI200ResponseImagesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **width** | **kotlin.Int** |  |  [optional] |
| **license** | [**SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense**](SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense.md) |  |  [optional] |
| **thumbnail** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.String** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |
| **height** | **kotlin.Int** |  |  [optional] |



