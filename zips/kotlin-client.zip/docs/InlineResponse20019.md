
# InlineResponse20019

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfWords** | **kotlin.Int** |  |  [optional]
**numberOfSentences** | **kotlin.Int** |  |  [optional]
**readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  |  [optional]
**skimmability** | [**InlineResponse20019Skimmability**](InlineResponse20019Skimmability.md) |  |  [optional]
**interestingness** | [**InlineResponse20019Interestingness**](InlineResponse20019Interestingness.md) |  |  [optional]
**style** | [**InlineResponse20019Style**](InlineResponse20019Style.md) |  |  [optional]
**totalScore** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



