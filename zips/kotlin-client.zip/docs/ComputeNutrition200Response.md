
# ComputeNutrition200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **nutrients** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional] |
| **properties** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional] |
| **flavonoids** | [**kotlin.collections.List&lt;SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  |  [optional] |
| **ingredientBreakdown** | [**kotlin.collections.List&lt;ComputeNutrition200ResponseIngredientBreakdownInner&gt;**](ComputeNutrition200ResponseIngredientBreakdownInner.md) |  |  [optional] |
| **caloricBreakdown** | [**SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  |  [optional] |
| **weightPerServing** | [**SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  |  [optional] |



