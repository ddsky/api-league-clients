
# DetectGenderByNameAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **probabilityMale** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **probabilityFemale** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **popularity** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



