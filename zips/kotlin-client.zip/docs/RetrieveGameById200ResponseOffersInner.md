
# RetrieveGameById200ResponseOffersInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **storeName** | **kotlin.String** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **price** | [**RetrieveGameById200ResponseOffersInnerPrice**](RetrieveGameById200ResponseOffersInnerPrice.md) |  |  [optional] |
| **platform** | **kotlin.String** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |



