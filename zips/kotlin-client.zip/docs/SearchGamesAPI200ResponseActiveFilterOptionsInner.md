
# SearchGamesAPI200ResponseActiveFilterOptionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **key** | **kotlin.String** |  |  [optional] |
| **connection** | **kotlin.String** |  |  [optional] |
| **propertyValues** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.md) |  |  [optional] |



