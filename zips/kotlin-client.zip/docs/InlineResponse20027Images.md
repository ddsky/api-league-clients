
# InlineResponse20027Images

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **kotlin.Int** |  |  [optional]
**license** | [**InlineResponse20027License**](InlineResponse20027License.md) |  |  [optional]
**thumbnail** | **kotlin.String** |  |  [optional]
**id** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**height** | **kotlin.Int** |  |  [optional]



