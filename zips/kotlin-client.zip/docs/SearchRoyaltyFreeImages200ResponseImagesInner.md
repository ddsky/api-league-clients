
# SearchRoyaltyFreeImages200ResponseImagesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **kotlin.Int** |  |  [optional]
**license** | [**SearchRoyaltyFreeImages200ResponseImagesInnerLicense**](SearchRoyaltyFreeImages200ResponseImagesInnerLicense.md) |  |  [optional]
**thumbnail** | **kotlin.String** |  |  [optional]
**id** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**height** | **kotlin.Int** |  |  [optional]



