
# FindSimilarBooksAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **similarBooks** | [**kotlin.collections.List&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;**](SearchBooksAPI200ResponseBooksInnerInner.md) |  |  [optional] |



