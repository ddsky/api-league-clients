
# FindSimilarGamesAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **results** | [**kotlin.collections.List&lt;FindSimilarGamesAPI200ResponseResultsInner&gt;**](FindSimilarGamesAPI200ResponseResultsInner.md) |  |  [optional] |



