
# ArtSearchAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **available** | **kotlin.Int** |  |  [optional] |
| **number** | **kotlin.Int** |  |  [optional] |
| **offset** | **kotlin.Int** |  |  [optional] |
| **artworks** | [**kotlin.collections.List&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;**](SearchBooksAPI200ResponseBooksInnerInner.md) |  |  [optional] |



