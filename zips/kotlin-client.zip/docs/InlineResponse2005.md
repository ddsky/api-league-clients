
# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**kotlin.collections.List&lt;InlineResponse2005Memes&gt;**](InlineResponse2005Memes.md) |  |  [optional]
**available** | **kotlin.Int** |  |  [optional]



