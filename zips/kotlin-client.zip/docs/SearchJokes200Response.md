
# SearchJokes200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **jokes** | [**kotlin.collections.List&lt;SearchJokes200ResponseJokesInner&gt;**](SearchJokes200ResponseJokesInner.md) |  |  [optional] |
| **available** | **kotlin.Int** |  |  [optional] |



