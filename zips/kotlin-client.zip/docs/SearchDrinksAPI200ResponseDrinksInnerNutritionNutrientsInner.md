
# SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **percentOfDailyNeeds** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



