
# InlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**word** | **kotlin.String** |  |  [optional]
**rating** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



