
# CorrectSpellingAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **correctedText** | **kotlin.String** |  |  [optional] |



