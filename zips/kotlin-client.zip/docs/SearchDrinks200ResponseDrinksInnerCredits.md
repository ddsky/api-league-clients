
# SearchDrinks200ResponseDrinksInnerCredits

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **text** | **kotlin.String** |  |  [optional] |
| **sourceName** | **kotlin.String** |  |  [optional] |
| **sourceUrl** | **kotlin.String** |  |  [optional] |



