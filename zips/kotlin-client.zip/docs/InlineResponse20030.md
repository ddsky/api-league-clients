
# InlineResponse20030

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**targetAmount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**targetUnit** | **kotlin.String** |  |  [optional]



