
# StemText200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **kotlin.String** |  |  [optional]
**stemmed** | **kotlin.String** |  |  [optional]



