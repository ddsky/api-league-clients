
# InlineResponse20017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **kotlin.String** |  |  [optional]
**confidence** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



