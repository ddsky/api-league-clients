
# VectorSearchAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **vectors** | [**kotlin.collections.List&lt;VectorSearchAPI200ResponseVectorsInner&gt;**](VectorSearchAPI200ResponseVectorsInner.md) |  |  [optional] |



