
# ExtractEntities200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **entities** | [**kotlin.collections.List&lt;ExtractEntities200ResponseEntitiesInner&gt;**](ExtractEntities200ResponseEntitiesInner.md) |  |  [optional] |



