
# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**kotlin.collections.List&lt;InlineResponse2004Jokes&gt;**](InlineResponse2004Jokes.md) |  |  [optional]
**available** | **kotlin.Int** |  |  [optional]



