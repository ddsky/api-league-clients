
# SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



