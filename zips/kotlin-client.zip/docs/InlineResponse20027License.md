
# InlineResponse20027License

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **kotlin.String** |  |  [optional]
**link** | **kotlin.String** |  |  [optional]



