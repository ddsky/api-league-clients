
# ExtractDatesAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **dates** | [**kotlin.collections.List&lt;ExtractDatesAPI200ResponseDatesInner&gt;**](ExtractDatesAPI200ResponseDatesInner.md) |  |  [optional] |



