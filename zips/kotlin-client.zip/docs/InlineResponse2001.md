
# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**kotlin.collections.List&lt;InlineResponse200Books&gt;**](InlineResponse200Books.md) |  |  [optional]



