
# TopNewsAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **topNews** | [**kotlin.collections.List&lt;TopNewsAPI200ResponseTopNewsInner&gt;**](TopNewsAPI200ResponseTopNewsInner.md) |  |  [optional] |
| **language** | **kotlin.String** |  |  [optional] |
| **country** | **kotlin.String** |  |  [optional] |



