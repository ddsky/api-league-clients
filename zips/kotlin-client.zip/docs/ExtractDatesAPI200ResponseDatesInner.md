
# ExtractDatesAPI200ResponseDatesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **startPosition** | **kotlin.Int** |  |  [optional] |
| **date** | **kotlin.String** |  |  [optional] |
| **normalizedDate** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **tag** | **kotlin.String** |  |  [optional] |
| **endPosition** | **kotlin.Int** |  |  [optional] |



