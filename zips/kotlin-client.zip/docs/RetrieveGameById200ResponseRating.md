
# RetrieveGameById200ResponseRating

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **count** | **kotlin.Int** |  |  [optional] |
| **countCritics** | **kotlin.Int** |  |  [optional] |
| **meanPlayers** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **meanCritics** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **mean** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **countPlayers** | **kotlin.Int** |  |  [optional] |



