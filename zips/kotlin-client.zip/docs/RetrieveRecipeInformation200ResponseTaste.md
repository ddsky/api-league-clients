
# RetrieveRecipeInformation200ResponseTaste

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **fattiness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **spiciness** | **kotlin.Int** |  |  [optional] |
| **saltiness** | **kotlin.Int** |  |  [optional] |
| **bitterness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **savoriness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **sweetness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **sourness** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



