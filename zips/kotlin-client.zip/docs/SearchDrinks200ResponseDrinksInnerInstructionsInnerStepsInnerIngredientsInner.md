
# SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **image** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |



