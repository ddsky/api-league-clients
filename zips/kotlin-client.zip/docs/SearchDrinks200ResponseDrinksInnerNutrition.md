
# SearchDrinks200ResponseDrinksInnerNutrition

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **weightPerServing** | [**SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  |  [optional] |
| **caloricBreakdown** | [**SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  |  [optional] |
| **flavonoids** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional] |
| **ingredientBreakdown** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  |  [optional] |
| **properties** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional] |
| **nutrients** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional] |



