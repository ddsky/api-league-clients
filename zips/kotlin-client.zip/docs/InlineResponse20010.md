
# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **kotlin.String** |  |  [optional]
**quote** | **kotlin.String** |  |  [optional]



