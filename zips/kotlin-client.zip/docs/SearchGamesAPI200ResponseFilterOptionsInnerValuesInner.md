
# SearchGamesAPI200ResponseFilterOptionsInnerValuesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **count** | **kotlin.Int** |  |  [optional] |
| **key** | **kotlin.String** |  |  [optional] |



