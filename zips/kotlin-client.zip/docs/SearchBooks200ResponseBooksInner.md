
# SearchBooks200ResponseBooksInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **kotlin.String** |  |  [optional]
**image** | **kotlin.String** |  |  [optional]
**id** | **kotlin.Int** |  |  [optional]



