
# SearchDrinksAPI200ResponseDrinksInnerInstructionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **steps** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  |  [optional] |



