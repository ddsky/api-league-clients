
# InlineResponse20015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**kotlin.collections.List&lt;InlineResponse20015Results&gt;**](InlineResponse20015Results.md) |  |  [optional]



