
# RandomRiddleAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **riddle** | **kotlin.String** |  |  [optional] |
| **answer** | **kotlin.String** |  |  [optional] |
| **difficulty** | **kotlin.String** |  |  [optional] |



