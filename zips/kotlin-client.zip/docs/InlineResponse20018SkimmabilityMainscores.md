
# InlineResponse20018SkimmabilityMainscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **kotlin.Int** |  |  [optional]
**total** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



