
# SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **nutrients** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional] |



