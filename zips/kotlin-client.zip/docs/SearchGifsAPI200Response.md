
# SearchGifsAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **images** | [**kotlin.collections.List&lt;SearchGifsAPI200ResponseImagesInner&gt;**](SearchGifsAPI200ResponseImagesInner.md) |  |  [optional] |



