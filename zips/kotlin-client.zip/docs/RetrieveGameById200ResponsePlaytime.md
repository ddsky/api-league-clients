
# RetrieveGameById200ResponsePlaytime

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **percentiles** | **kotlin.collections.List&lt;kotlin.Int&gt;** |  |  [optional] |
| **min** | **kotlin.Int** |  |  [optional] |
| **median** | **kotlin.Int** |  |  [optional] |
| **max** | **kotlin.Int** |  |  [optional] |
| **mean** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **mentions** | **kotlin.Int** |  |  [optional] |



