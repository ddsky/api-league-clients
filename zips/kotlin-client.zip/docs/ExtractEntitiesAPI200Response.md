
# ExtractEntitiesAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **entities** | [**kotlin.collections.List&lt;ExtractEntitiesAPI200ResponseEntitiesInner&gt;**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  |  [optional] |



