
# SearchDrinks200ResponseDrinksInnerInstructionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **steps** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  |  [optional] |



