
# InlineResponse20022

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synonyms** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]



