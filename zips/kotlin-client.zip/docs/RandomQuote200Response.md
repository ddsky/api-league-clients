
# RandomQuote200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **kotlin.String** |  |  [optional]
**quote** | **kotlin.String** |  |  [optional]



