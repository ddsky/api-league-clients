
# ExtractContentFromAWebPage200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **kotlin.String** |  |  [optional]
**mainText** | **kotlin.String** |  |  [optional]
**mainHtml** | **kotlin.String** |  |  [optional]
**images** | **kotlin.collections.List&lt;kotlin.String&gt;** |  |  [optional]



