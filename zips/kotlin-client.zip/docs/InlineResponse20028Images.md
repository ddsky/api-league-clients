
# InlineResponse20028Images

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **kotlin.Int** |  |  [optional]
**license** | [**InlineResponse20028License**](InlineResponse20028License.md) |  |  [optional]
**thumbnail** | **kotlin.String** |  |  [optional]
**id** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]
**height** | **kotlin.Int** |  |  [optional]



