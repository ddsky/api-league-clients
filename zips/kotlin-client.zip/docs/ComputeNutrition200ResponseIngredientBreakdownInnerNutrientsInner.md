
# ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **percentOfDailyNeeds** | **kotlin.Int** |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



