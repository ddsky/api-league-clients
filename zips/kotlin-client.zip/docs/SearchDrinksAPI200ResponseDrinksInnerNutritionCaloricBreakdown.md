
# SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **percentFat** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **percentCarbs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **percentProtein** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



