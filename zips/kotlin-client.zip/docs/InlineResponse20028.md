
# InlineResponse20028

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**kotlin.collections.List&lt;InlineResponse20028Images&gt;**](InlineResponse20028Images.md) |  |  [optional]



