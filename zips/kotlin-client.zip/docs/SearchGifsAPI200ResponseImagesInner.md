
# SearchGifsAPI200ResponseImagesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **width** | **kotlin.Int** |  |  [optional] |
| **url** | **kotlin.String** |  |  [optional] |
| **height** | **kotlin.Int** |  |  [optional] |



