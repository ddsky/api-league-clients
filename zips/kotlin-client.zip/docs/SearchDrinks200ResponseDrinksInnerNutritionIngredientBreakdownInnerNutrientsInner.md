
# SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **percentOfDailyNeeds** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **amount** | **kotlin.Int** |  |  [optional] |
| **unit** | **kotlin.String** |  |  [optional] |



