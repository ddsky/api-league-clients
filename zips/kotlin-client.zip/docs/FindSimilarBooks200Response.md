
# FindSimilarBooks200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**kotlin.collections.List&lt;SearchBooks200ResponseBooksInnerInner&gt;**](SearchBooks200ResponseBooksInnerInner.md) |  |  [optional]



