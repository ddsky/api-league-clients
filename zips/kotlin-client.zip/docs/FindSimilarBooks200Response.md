
# FindSimilarBooks200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**kotlin.collections.List&lt;SearchBooks200ResponseBooksInner&gt;**](SearchBooks200ResponseBooksInner.md) |  |  [optional]



