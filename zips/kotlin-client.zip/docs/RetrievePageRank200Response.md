
# RetrievePageRank200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **pageRank** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **position** | **kotlin.Int** |  |  [optional] |
| **percentile** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



