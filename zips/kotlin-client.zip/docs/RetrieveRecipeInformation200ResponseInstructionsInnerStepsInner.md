
# RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **kotlin.Int** |  |  [optional]
**ingredients** | [**kotlin.collections.List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | [**kotlin.collections.List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**step** | **kotlin.String** |  |  [optional]



