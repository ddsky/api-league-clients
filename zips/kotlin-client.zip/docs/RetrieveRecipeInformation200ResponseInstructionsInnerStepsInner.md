
# RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **number** | **kotlin.Int** |  |  [optional] |
| **ingredients** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **equipment** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
| **step** | **kotlin.String** |  |  [optional] |



