
# ScoreText200ResponseReadabilityMainscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **kotlin.Int** |  |  [optional]
**total** | **kotlin.Int** |  |  [optional]



