
# SearchBooks200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **kotlin.Int** |  |  [optional]
**number** | **kotlin.Int** |  |  [optional]
**offset** | **kotlin.Int** |  |  [optional]
**books** | [**kotlin.collections.List&lt;SearchBooks200ResponseBooksInner&gt;**](SearchBooks200ResponseBooksInner.md) |  |  [optional]



