
# SearchMemes200ResponseMemesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **kotlin.String** |  |  [optional]
**description** | **kotlin.String** |  |  [optional]
**url** | **kotlin.String** |  |  [optional]



