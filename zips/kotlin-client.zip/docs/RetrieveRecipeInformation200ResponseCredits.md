
# RetrieveRecipeInformation200ResponseCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **kotlin.String** |  |  [optional]
**text** | **kotlin.String** |  |  [optional]
**sourceName** | **kotlin.String** |  |  [optional]
**sourceUrl** | **kotlin.String** |  |  [optional]



