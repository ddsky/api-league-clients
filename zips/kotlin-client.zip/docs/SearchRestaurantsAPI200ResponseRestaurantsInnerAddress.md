
# SearchRestaurantsAPI200ResponseRestaurantsInnerAddress

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **zipcode** | **kotlin.String** |  |  [optional] |
| **country** | **kotlin.String** |  |  [optional] |
| **city** | **kotlin.String** |  |  [optional] |
| **latitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **lon** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **streetAddr2** | **kotlin.String** |  |  [optional] |
| **state** | **kotlin.String** |  |  [optional] |
| **streetAddr** | **kotlin.String** |  |  [optional] |
| **lat** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **longitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



