
# SearchNewsAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Int** |  |  [optional] |
| **number** | **kotlin.Int** |  |  [optional] |
| **available** | **kotlin.Int** |  |  [optional] |
| **news** | [**kotlin.collections.List&lt;SearchNewsAPI200ResponseNewsInner&gt;**](SearchNewsAPI200ResponseNewsInner.md) |  |  [optional] |



