
# FindSimilarGamesAPI200ResponseResultsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **image** | **kotlin.String** |  |  [optional] |
| **shortDescription** | **kotlin.String** |  |  [optional] |
| **microTrailer** | **kotlin.String** |  |  [optional] |
| **year** | **kotlin.Int** |  |  [optional] |
| **name** | **kotlin.String** |  |  [optional] |
| **genre** | **kotlin.String** |  |  [optional] |
| **link** | **kotlin.String** |  |  [optional] |
| **rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **adultOnly** | **kotlin.Boolean** |  |  [optional] |
| **screenshots** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **gameplay** | **kotlin.String** |  |  [optional] |



