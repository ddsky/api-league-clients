
# SearchGamesAPI200ResponseResultsInnerPlatformsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **&#x60;value&#x60;** | **kotlin.String** |  |  [optional] |



