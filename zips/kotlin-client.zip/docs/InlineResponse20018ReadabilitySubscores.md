
# InlineResponse20018ReadabilitySubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **kotlin.Int** |  |  [optional]
**forcast** | **kotlin.Int** |  |  [optional]
**flesch** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**smog** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**ari** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**lix** | **kotlin.Int** |  |  [optional]
**colemanLiau** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**kincaid** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**fog** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



