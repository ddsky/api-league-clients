
# ExtractDates200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **dates** | [**kotlin.collections.List&lt;ExtractDates200ResponseDatesInner&gt;**](ExtractDates200ResponseDatesInner.md) |  |  [optional] |



