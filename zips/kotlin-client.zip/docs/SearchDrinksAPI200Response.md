
# SearchDrinksAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **offset** | **kotlin.Int** |  |  [optional] |
| **number** | **kotlin.Int** |  |  [optional] |
| **drinks** | [**kotlin.collections.List&lt;SearchDrinksAPI200ResponseDrinksInner&gt;**](SearchDrinksAPI200ResponseDrinksInner.md) |  |  [optional] |
| **totalResults** | **kotlin.Int** |  |  [optional] |



