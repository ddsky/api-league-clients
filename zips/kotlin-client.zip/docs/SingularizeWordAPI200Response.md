
# SingularizeWordAPI200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **original** | **kotlin.String** |  |  [optional] |
| **singular** | **kotlin.String** |  |  [optional] |



