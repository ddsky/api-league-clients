
# ReadKeyValueFromStore200Response

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **&#x60;value&#x60;** | **kotlin.String** |  |  [optional] |



