
# RetrieveRecipeInformationAPI200ResponseInstructionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **steps** | [**kotlin.collections.List&lt;RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner.md) |  |  [optional] |



