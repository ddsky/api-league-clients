
# SearchDrinks200ResponseDrinksInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **flavors** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **instructions** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInner.md) |  |  [optional] |
| **images** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |
| **nutrition** | [**SearchDrinks200ResponseDrinksInnerNutrition**](SearchDrinks200ResponseDrinksInnerNutrition.md) |  |  [optional] |
| **glassType** | **kotlin.String** |  |  [optional] |
| **credits** | [**SearchDrinks200ResponseDrinksInnerCredits**](SearchDrinks200ResponseDrinksInnerCredits.md) |  |  [optional] |
| **pricePerServing** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **description** | **kotlin.String** |  |  [optional] |
| **ingredients** | [**kotlin.collections.List&lt;SearchDrinks200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerIngredientsInner.md) |  |  [optional] |
| **id** | **kotlin.Int** |  |  [optional] |
| **title** | **kotlin.String** |  |  [optional] |
| **cuisines** | **kotlin.collections.List&lt;kotlin.String?&gt;** |  |  [optional] |



