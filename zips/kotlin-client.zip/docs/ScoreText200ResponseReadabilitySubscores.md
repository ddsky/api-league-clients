
# ScoreText200ResponseReadabilitySubscores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **kotlin.Int** |  |  [optional]
**forcast** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**flesch** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**smog** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**ari** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**lix** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**colemanLiau** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**kincaid** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**fog** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]



