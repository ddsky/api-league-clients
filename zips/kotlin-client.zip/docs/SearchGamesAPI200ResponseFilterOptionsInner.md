
# SearchGamesAPI200ResponseFilterOptionsInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  [optional] |
| **filterType** | **kotlin.String** |  |  [optional] |
| **key** | **kotlin.String** |  |  [optional] |
| **propertyValues** | [**kotlin.collections.List&lt;SearchGamesAPI200ResponseFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  |  [optional] |
| **filterConnection** | **kotlin.String** |  |  [optional] |



