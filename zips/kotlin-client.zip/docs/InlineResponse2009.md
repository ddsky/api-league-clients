
# InlineResponse2009

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trivia** | **kotlin.String** |  |  [optional]



