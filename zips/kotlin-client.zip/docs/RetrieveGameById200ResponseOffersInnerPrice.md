
# RetrieveGameById200ResponseOffersInnerPrice

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **currency** | **kotlin.String** |  |  [optional] |
| **discountPercent** | **kotlin.Int** |  |  [optional] |
| **&#x60;value&#x60;** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **initial** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |



