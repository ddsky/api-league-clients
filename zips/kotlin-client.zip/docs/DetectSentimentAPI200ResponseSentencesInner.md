
# DetectSentimentAPI200ResponseSentencesInner

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **length** | **kotlin.Int** |  |  [optional] |
| **sentiment** | **kotlin.String** |  |  [optional] |
| **offset** | **kotlin.Int** |  |  [optional] |
| **confidence** | **kotlin.Int** |  |  [optional] |



