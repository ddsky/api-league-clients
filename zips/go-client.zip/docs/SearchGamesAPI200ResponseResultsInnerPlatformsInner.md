# SearchGamesAPI200ResponseResultsInnerPlatformsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | Pointer to **NullableString** |  | [optional] 
**Name** | Pointer to **NullableString** |  | [optional] 

## Methods

### NewSearchGamesAPI200ResponseResultsInnerPlatformsInner

`func NewSearchGamesAPI200ResponseResultsInnerPlatformsInner() *SearchGamesAPI200ResponseResultsInnerPlatformsInner`

NewSearchGamesAPI200ResponseResultsInnerPlatformsInner instantiates a new SearchGamesAPI200ResponseResultsInnerPlatformsInner object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewSearchGamesAPI200ResponseResultsInnerPlatformsInnerWithDefaults

`func NewSearchGamesAPI200ResponseResultsInnerPlatformsInnerWithDefaults() *SearchGamesAPI200ResponseResultsInnerPlatformsInner`

NewSearchGamesAPI200ResponseResultsInnerPlatformsInnerWithDefaults instantiates a new SearchGamesAPI200ResponseResultsInnerPlatformsInner object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetValue

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) HasValue() bool`

HasValue returns a boolean if a field has been set.

### SetValueNil

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) SetValueNil(b bool)`

 SetValueNil sets the value for Value to be an explicit nil

### UnsetValue
`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) UnsetValue()`

UnsetValue ensures that no value is present for Value, not even an explicit nil
### GetName

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) HasName() bool`

HasName returns a boolean if a field has been set.

### SetNameNil

`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) SetNameNil(b bool)`

 SetNameNil sets the value for Name to be an explicit nil

### UnsetName
`func (o *SearchGamesAPI200ResponseResultsInnerPlatformsInner) UnsetName()`

UnsetName ensures that no value is present for Name, not even an explicit nil

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


