# SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metric** | Pointer to [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**Us** | Pointer to [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

## Methods

### NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures

`func NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures() *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures`

NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures instantiates a new SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresWithDefaults

`func NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresWithDefaults() *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures`

NewSearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresWithDefaults instantiates a new SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetric

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) GetMetric() SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric`

GetMetric returns the Metric field if non-nil, zero value otherwise.

### GetMetricOk

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) GetMetricOk() (*SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric, bool)`

GetMetricOk returns a tuple with the Metric field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetric

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) SetMetric(v SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric)`

SetMetric sets Metric field to given value.

### HasMetric

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) HasMetric() bool`

HasMetric returns a boolean if a field has been set.

### GetUs

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) GetUs() SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs`

GetUs returns the Us field if non-nil, zero value otherwise.

### GetUsOk

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) GetUsOk() (*SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs, bool)`

GetUsOk returns a tuple with the Us field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUs

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) SetUs(v SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs)`

SetUs sets Us field to given value.

### HasUs

`func (o *SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures) HasUs() bool`

HasUs returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


