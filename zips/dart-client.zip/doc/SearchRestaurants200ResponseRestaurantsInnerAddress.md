# openapi.model.SearchRestaurants200ResponseRestaurantsInnerAddress

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**latitude** | **num** |  | [optional] 
**lon** | **num** |  | [optional] 
**streetAddr2** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**streetAddr** | **String** |  | [optional] 
**lat** | **num** |  | [optional] 
**longitude** | **num** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


