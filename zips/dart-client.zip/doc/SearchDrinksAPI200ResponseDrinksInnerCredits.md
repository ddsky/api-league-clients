# openapi.model.SearchDrinksAPI200ResponseDrinksInnerCredits

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceName** | **String** |  | [optional] 
**sourceUrl** | **String** |  | [optional] 
**text** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


