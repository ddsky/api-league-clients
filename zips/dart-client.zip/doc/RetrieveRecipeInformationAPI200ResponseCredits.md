# openapi.model.RetrieveRecipeInformationAPI200ResponseCredits

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**sourceName** | **String** |  | [optional] 
**sourceUrl** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


