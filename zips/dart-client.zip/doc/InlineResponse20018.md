# openapi.model.InlineResponse20018

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**InlineResponse20018Document**](InlineResponse20018Document.md) |  | [optional] 
**sentences** | [**List<InlineResponse20018Sentences>**](InlineResponse20018Sentences.md) |  | [optional] [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


