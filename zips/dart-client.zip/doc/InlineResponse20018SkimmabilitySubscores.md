# openapi.model.InlineResponse20018SkimmabilitySubscores

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulletPointRatioScore** | **List<int>** |  | [optional] [default to const []]
**imageScore** | **List<int>** |  | [optional] [default to const []]
**highlightedWordRatioScore** | **List<int>** |  | [optional] [default to const []]
**videoScore** | **List<int>** |  | [optional] [default to const []]
**paragraphScore** | **List<int>** |  | [optional] [default to const []]
**paragraphHeadlineRatioScore** | **List<int>** |  | [optional] [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


