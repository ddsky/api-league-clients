# openapi.model.SearchRestaurantsAPI200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**List<SearchRestaurantsAPI200ResponseRestaurantsInner>**](SearchRestaurantsAPI200ResponseRestaurantsInner.md) |  | [optional] [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


