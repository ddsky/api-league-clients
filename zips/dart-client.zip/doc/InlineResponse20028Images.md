# openapi.model.InlineResponse20028Images

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional] 
**license** | [**InlineResponse20028License**](InlineResponse20028License.md) |  | [optional] 
**thumbnail** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


