# openapi.model.RetrieveRecipeInformationAPI200ResponseScores

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weightWatcherSmartPoints** | **int** |  | [optional] 
**healthScore** | **int** |  | [optional] 
**metaScore** | **num** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


