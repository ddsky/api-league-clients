# openapi.model.ScoreText200ResponseReadability

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**ScoreText200ResponseReadabilityMainscores**](ScoreText200ResponseReadabilityMainscores.md) |  | [optional] 
**subscores** | [**ScoreText200ResponseReadabilitySubscores**](ScoreText200ResponseReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


