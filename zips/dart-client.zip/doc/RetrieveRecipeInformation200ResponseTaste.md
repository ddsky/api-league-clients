# openapi.model.RetrieveRecipeInformation200ResponseTaste

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | **num** |  | [optional] 
**spiciness** | **int** |  | [optional] 
**saltiness** | **int** |  | [optional] 
**bitterness** | **num** |  | [optional] 
**savoriness** | **num** |  | [optional] 
**sweetness** | **num** |  | [optional] 
**sourness** | **num** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


