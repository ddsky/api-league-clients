# openapi.model.RetrieveRecipeInformation200ResponseScores

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metaScore** | **num** |  | [optional] 
**weightWatcherSmartPoints** | **int** |  | [optional] 
**healthScore** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


