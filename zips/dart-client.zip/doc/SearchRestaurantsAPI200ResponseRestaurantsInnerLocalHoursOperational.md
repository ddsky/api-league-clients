# openapi.model.SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **String** |  | [optional] 
**saturday** | **String** |  | [optional] 
**tuesday** | **String** |  | [optional] 
**thursday** | **String** |  | [optional] 
**friday** | **String** |  | [optional] 
**wednesday** | **String** |  | [optional] 
**monday** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


