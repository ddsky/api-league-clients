# openapi.model.RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional] 
**ingredients** | [**List<SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner>**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] [default to const []]
**equipment** | [**List<SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner>**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] [default to const []]
**step** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


