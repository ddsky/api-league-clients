# openapi.model.InlineResponse20018Style

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20018ReadabilityMainscores**](InlineResponse20018ReadabilityMainscores.md) |  | [optional] 
**subscores** | [**InlineResponse20018StyleSubscores**](InlineResponse20018StyleSubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


