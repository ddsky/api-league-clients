# openapi.model.InlineResponse20018InterestingnessSubscores

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titleRatingScore** | **List<int>** |  | [optional] [default to const []]
**quoteScore** | **List<int>** |  | [optional] [default to const []]
**lengthScore** | **List<int>** |  | [optional] [default to const []]
**linkScore** | **List<int>** |  | [optional] [default to const []]
**googleHitsScore** | **List<int>** |  | [optional] [default to const []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


