# openapi.model.ExtractEntitiesAPI200ResponseEntitiesInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **int** |  | [optional] 
**image** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**value** | **String** |  | [optional] 
**endPosition** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


