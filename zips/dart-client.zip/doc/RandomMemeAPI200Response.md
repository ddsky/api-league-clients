# openapi.model.RandomMemeAPI200Response

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**width** | **int** |  | [optional] 
**height** | **int** |  | [optional] 
**ratio** | **num** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


