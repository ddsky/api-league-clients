# openapi.model.ExtractNewsAPI200ResponseVideosInner

## Load the model package
```dart
import 'package:openapi/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**summary** | **String** |  | [optional] 
**duration** | **int** |  | [optional] 
**thumbnail** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


