//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ScoreTextAPI200ResponseStyleSubscores {
  /// Returns a new [ScoreTextAPI200ResponseStyleSubscores] instance.
  ScoreTextAPI200ResponseStyleSubscores({
    this.abbreviationScore = const [],
    this.styleScore = const [],
    this.spellingScore = const [],
  });

  List<num> abbreviationScore;

  List<num> styleScore;

  List<num> spellingScore;

  @override
  bool operator ==(Object other) => identical(this, other) || other is ScoreTextAPI200ResponseStyleSubscores &&
    _deepEquality.equals(other.abbreviationScore, abbreviationScore) &&
    _deepEquality.equals(other.styleScore, styleScore) &&
    _deepEquality.equals(other.spellingScore, spellingScore);

  @override
  int get hashCode =>
    // ignore: unnecessary_parenthesis
    (abbreviationScore.hashCode) +
    (styleScore.hashCode) +
    (spellingScore.hashCode);

  @override
  String toString() => 'ScoreTextAPI200ResponseStyleSubscores[abbreviationScore=$abbreviationScore, styleScore=$styleScore, spellingScore=$spellingScore]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
      json[r'abbreviation_score'] = this.abbreviationScore;
      json[r'style_score'] = this.styleScore;
      json[r'spelling_score'] = this.spellingScore;
    return json;
  }

  /// Returns a new [ScoreTextAPI200ResponseStyleSubscores] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static ScoreTextAPI200ResponseStyleSubscores? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key), 'Required key "ScoreTextAPI200ResponseStyleSubscores[$key]" is missing from JSON.');
          assert(json[key] != null, 'Required key "ScoreTextAPI200ResponseStyleSubscores[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return ScoreTextAPI200ResponseStyleSubscores(
        abbreviationScore: json[r'abbreviation_score'] is Iterable
            ? (json[r'abbreviation_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        styleScore: json[r'style_score'] is Iterable
            ? (json[r'style_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        spellingScore: json[r'spelling_score'] is Iterable
            ? (json[r'spelling_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
      );
    }
    return null;
  }

  static List<ScoreTextAPI200ResponseStyleSubscores> listFromJson(dynamic json, {bool growable = false,}) {
    final result = <ScoreTextAPI200ResponseStyleSubscores>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = ScoreTextAPI200ResponseStyleSubscores.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, ScoreTextAPI200ResponseStyleSubscores> mapFromJson(dynamic json) {
    final map = <String, ScoreTextAPI200ResponseStyleSubscores>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = ScoreTextAPI200ResponseStyleSubscores.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of ScoreTextAPI200ResponseStyleSubscores-objects as value to a dart map
  static Map<String, List<ScoreTextAPI200ResponseStyleSubscores>> mapListFromJson(dynamic json, {bool growable = false,}) {
    final map = <String, List<ScoreTextAPI200ResponseStyleSubscores>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = ScoreTextAPI200ResponseStyleSubscores.listFromJson(entry.value, growable: growable,);
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
  };
}

