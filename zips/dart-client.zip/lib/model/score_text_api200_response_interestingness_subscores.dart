//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ScoreTextAPI200ResponseInterestingnessSubscores {
  /// Returns a new [ScoreTextAPI200ResponseInterestingnessSubscores] instance.
  ScoreTextAPI200ResponseInterestingnessSubscores({
    this.googleHitsScore = const [],
    this.linkScore = const [],
    this.quoteScore = const [],
    this.titleRatingScore = const [],
    this.lengthScore = const [],
  });

  List<num> googleHitsScore;

  List<num> linkScore;

  List<num> quoteScore;

  List<num> titleRatingScore;

  List<num> lengthScore;

  @override
  bool operator ==(Object other) => identical(this, other) || other is ScoreTextAPI200ResponseInterestingnessSubscores &&
    _deepEquality.equals(other.googleHitsScore, googleHitsScore) &&
    _deepEquality.equals(other.linkScore, linkScore) &&
    _deepEquality.equals(other.quoteScore, quoteScore) &&
    _deepEquality.equals(other.titleRatingScore, titleRatingScore) &&
    _deepEquality.equals(other.lengthScore, lengthScore);

  @override
  int get hashCode =>
    // ignore: unnecessary_parenthesis
    (googleHitsScore.hashCode) +
    (linkScore.hashCode) +
    (quoteScore.hashCode) +
    (titleRatingScore.hashCode) +
    (lengthScore.hashCode);

  @override
  String toString() => 'ScoreTextAPI200ResponseInterestingnessSubscores[googleHitsScore=$googleHitsScore, linkScore=$linkScore, quoteScore=$quoteScore, titleRatingScore=$titleRatingScore, lengthScore=$lengthScore]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
      json[r'google_hits_score'] = this.googleHitsScore;
      json[r'link_score'] = this.linkScore;
      json[r'quote_score'] = this.quoteScore;
      json[r'title_rating_score'] = this.titleRatingScore;
      json[r'length_score'] = this.lengthScore;
    return json;
  }

  /// Returns a new [ScoreTextAPI200ResponseInterestingnessSubscores] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static ScoreTextAPI200ResponseInterestingnessSubscores? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key), 'Required key "ScoreTextAPI200ResponseInterestingnessSubscores[$key]" is missing from JSON.');
          assert(json[key] != null, 'Required key "ScoreTextAPI200ResponseInterestingnessSubscores[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return ScoreTextAPI200ResponseInterestingnessSubscores(
        googleHitsScore: json[r'google_hits_score'] is Iterable
            ? (json[r'google_hits_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        linkScore: json[r'link_score'] is Iterable
            ? (json[r'link_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        quoteScore: json[r'quote_score'] is Iterable
            ? (json[r'quote_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        titleRatingScore: json[r'title_rating_score'] is Iterable
            ? (json[r'title_rating_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
        lengthScore: json[r'length_score'] is Iterable
            ? (json[r'length_score'] as Iterable).cast<num>().toList(growable: false)
            : const [],
      );
    }
    return null;
  }

  static List<ScoreTextAPI200ResponseInterestingnessSubscores> listFromJson(dynamic json, {bool growable = false,}) {
    final result = <ScoreTextAPI200ResponseInterestingnessSubscores>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = ScoreTextAPI200ResponseInterestingnessSubscores.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, ScoreTextAPI200ResponseInterestingnessSubscores> mapFromJson(dynamic json) {
    final map = <String, ScoreTextAPI200ResponseInterestingnessSubscores>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = ScoreTextAPI200ResponseInterestingnessSubscores.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of ScoreTextAPI200ResponseInterestingnessSubscores-objects as value to a dart map
  static Map<String, List<ScoreTextAPI200ResponseInterestingnessSubscores>> mapListFromJson(dynamic json, {bool growable = false,}) {
    final map = <String, List<ScoreTextAPI200ResponseInterestingnessSubscores>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = ScoreTextAPI200ResponseInterestingnessSubscores.listFromJson(entry.value, growable: growable,);
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
  };
}

