//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric {
  /// Returns a new [SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric] instance.
  SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric({
    this.amount,
    this.unitShort,
    this.unitLong,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  num? amount;

  String? unitShort;

  String? unitLong;

  @override
  bool operator ==(Object other) => identical(this, other) || other is SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric &&
    other.amount == amount &&
    other.unitShort == unitShort &&
    other.unitLong == unitLong;

  @override
  int get hashCode =>
    // ignore: unnecessary_parenthesis
    (amount == null ? 0 : amount!.hashCode) +
    (unitShort == null ? 0 : unitShort!.hashCode) +
    (unitLong == null ? 0 : unitLong!.hashCode);

  @override
  String toString() => 'SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric[amount=$amount, unitShort=$unitShort, unitLong=$unitLong]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.amount != null) {
      json[r'amount'] = this.amount;
    } else {
      json[r'amount'] = null;
    }
    if (this.unitShort != null) {
      json[r'unit_short'] = this.unitShort;
    } else {
      json[r'unit_short'] = null;
    }
    if (this.unitLong != null) {
      json[r'unit_long'] = this.unitLong;
    } else {
      json[r'unit_long'] = null;
    }
    return json;
  }

  /// Returns a new [SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key), 'Required key "SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric[$key]" is missing from JSON.');
          assert(json[key] != null, 'Required key "SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric(
        amount: num.parse('${json[r'amount']}'),
        unitShort: mapValueOfType<String>(json, r'unit_short'),
        unitLong: mapValueOfType<String>(json, r'unit_long'),
      );
    }
    return null;
  }

  static List<SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric> listFromJson(dynamic json, {bool growable = false,}) {
    final result = <SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric> mapFromJson(dynamic json) {
    final map = <String, SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric-objects as value to a dart map
  static Map<String, List<SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric>> mapListFromJson(dynamic json, {bool growable = false,}) {
    final map = <String, List<SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.listFromJson(entry.value, growable: growable,);
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
  };
}

