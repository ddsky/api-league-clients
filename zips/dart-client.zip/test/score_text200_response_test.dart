//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ScoreText200Response
void main() {
  // final instance = ScoreText200Response();

  group('test ScoreText200Response', () {
    // int numberOfWords
    test('to test the property `numberOfWords`', () async {
      // TODO
    });

    // int numberOfSentences
    test('to test the property `numberOfSentences`', () async {
      // TODO
    });

    // ScoreText200ResponseReadability readability
    test('to test the property `readability`', () async {
      // TODO
    });

    // ScoreText200ResponseSkimmability skimmability
    test('to test the property `skimmability`', () async {
      // TODO
    });

    // ScoreText200ResponseInterestingness interestingness
    test('to test the property `interestingness`', () async {
      // TODO
    });

    // ScoreText200ResponseStyle style
    test('to test the property `style`', () async {
      // TODO
    });

    // num totalScore
    test('to test the property `totalScore`', () async {
      // TODO
    });


  });

}
