//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ExtractDates200ResponseDatesInner
void main() {
  // final instance = ExtractDates200ResponseDatesInner();

  group('test ExtractDates200ResponseDatesInner', () {
    // int startPosition
    test('to test the property `startPosition`', () async {
      // TODO
    });

    // String date
    test('to test the property `date`', () async {
      // TODO
    });

    // num normalizedDate
    test('to test the property `normalizedDate`', () async {
      // TODO
    });

    // String tag
    test('to test the property `tag`', () async {
      // TODO
    });

    // int endPosition
    test('to test the property `endPosition`', () async {
      // TODO
    });


  });

}
