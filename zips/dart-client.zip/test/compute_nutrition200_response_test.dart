//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ComputeNutrition200Response
void main() {
  // final instance = ComputeNutrition200Response();

  group('test ComputeNutrition200Response', () {
    // List<RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner> nutrients (default value: const [])
    test('to test the property `nutrients`', () async {
      // TODO
    });

    // List<RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner> properties (default value: const [])
    test('to test the property `properties`', () async {
      // TODO
    });

    // List<SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner> flavonoids (default value: const [])
    test('to test the property `flavonoids`', () async {
      // TODO
    });

    // List<ComputeNutrition200ResponseIngredientBreakdownInner> ingredientBreakdown (default value: const [])
    test('to test the property `ingredientBreakdown`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown caloricBreakdown
    test('to test the property `caloricBreakdown`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseNutritionWeightPerServing weightPerServing
    test('to test the property `weightPerServing`', () async {
      // TODO
    });


  });

}
