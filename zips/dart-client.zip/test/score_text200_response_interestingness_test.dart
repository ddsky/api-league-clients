//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ScoreText200ResponseInterestingness
void main() {
  // final instance = ScoreText200ResponseInterestingness();

  group('test ScoreText200ResponseInterestingness', () {
    // ScoreText200ResponseSkimmabilityMainscores mainscores
    test('to test the property `mainscores`', () async {
      // TODO
    });

    // ScoreText200ResponseInterestingnessSubscores subscores
    test('to test the property `subscores`', () async {
      // TODO
    });


  });

}
