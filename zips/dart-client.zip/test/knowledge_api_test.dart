//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for KnowledgeApi
void main() {
  // final instance = KnowledgeApi();

  group('tests for KnowledgeApi', () {
    // Random Quote API
    //
    // This API returns a random quote from a collection of quotes. The quotes are from famous people and are in English.
    //
    //Future<RandomQuoteAPI200Response> randomQuoteAPI({ int minLength, int maxLength }) async
    test('test randomQuoteAPI', () async {
      // TODO
    });

    // Random Riddle API
    //
    // The riddles API returns a random riddle or brain-teaser. Riddles are a great way to exercise your brain and keep it sharp. The API supports brain-teasers in three difficulty levels: easy, medium, and hard. You can also get a random riddle without specifying a difficulty level.
    //
    //Future<RandomRiddleAPI200Response> randomRiddleAPI({ String difficulty }) async
    test('test randomRiddleAPI', () async {
      // TODO
    });

    // Random Trivia API
    //
    // This endpoint returns a random piece of trivia like \"Rio de Janeiro was once the capital of Portugal, making it the only European capital outside of Europe.\".
    //
    //Future<RandomTriviaAPI200Response> randomTriviaAPI({ int maxLength }) async
    test('test randomTriviaAPI', () async {
      // TODO
    });

  });
}
