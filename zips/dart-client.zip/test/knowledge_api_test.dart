//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for KnowledgeApi
void main() {
  // final instance = KnowledgeApi();

  group('tests for KnowledgeApi', () {
    // Random Quote
    //
    // This API returns a random quote from a collection of quotes. The quotes are from famous people and are in English.
    //
    //Future<RandomQuote200Response> randomQuote({ int minLength, int maxLength }) async
    test('test randomQuote', () async {
      // TODO
    });

    // Random Trivia
    //
    // This endpoint returns a random piece of trivia.
    //
    //Future<RandomTrivia200Response> randomTrivia({ int maxLength }) async
    test('test randomTrivia', () async {
      // TODO
    });

  });
}
