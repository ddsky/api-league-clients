//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ComputeNutritionAPI200ResponseIngredientBreakdownInner
void main() {
  // final instance = ComputeNutritionAPI200ResponseIngredientBreakdownInner();

  group('test ComputeNutritionAPI200ResponseIngredientBreakdownInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // int amount
    test('to test the property `amount`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });

    // List<ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner> nutrients (default value: const [])
    test('to test the property `nutrients`', () async {
      // TODO
    });


  });

}
