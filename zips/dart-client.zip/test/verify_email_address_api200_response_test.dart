//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for VerifyEmailAddressAPI200Response
void main() {
  // final instance = VerifyEmailAddressAPI200Response();

  group('test VerifyEmailAddressAPI200Response', () {
    // String email
    test('to test the property `email`', () async {
      // TODO
    });

    // String domain
    test('to test the property `domain`', () async {
      // TODO
    });

    // String firstName
    test('to test the property `firstName`', () async {
      // TODO
    });

    // String middleName
    test('to test the property `middleName`', () async {
      // TODO
    });

    // String lastName
    test('to test the property `lastName`', () async {
      // TODO
    });

    // String fullName
    test('to test the property `fullName`', () async {
      // TODO
    });

    // String username
    test('to test the property `username`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String result
    test('to test the property `result`', () async {
      // TODO
    });

    // bool disposable
    test('to test the property `disposable`', () async {
      // TODO
    });

    // bool acceptAll
    test('to test the property `acceptAll`', () async {
      // TODO
    });

    // bool freeProvider
    test('to test the property `freeProvider`', () async {
      // TODO
    });


  });

}
