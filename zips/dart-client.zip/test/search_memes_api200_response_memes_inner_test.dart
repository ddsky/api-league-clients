//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchMemesAPI200ResponseMemesInner
void main() {
  // final instance = SearchMemesAPI200ResponseMemesInner();

  group('test SearchMemesAPI200ResponseMemesInner', () {
    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // String url
    test('to test the property `url`', () async {
      // TODO
    });


  });

}
