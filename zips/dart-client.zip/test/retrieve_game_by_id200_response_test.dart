//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveGameById200Response
void main() {
  // final instance = RetrieveGameById200Response();

  group('test RetrieveGameById200Response', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String gameplay
    test('to test the property `gameplay`', () async {
      // TODO
    });

    // String link
    test('to test the property `link`', () async {
      // TODO
    });

    // String xUrl
    test('to test the property `xUrl`', () async {
      // TODO
    });

    // RetrieveGameById200ResponseRating rating
    test('to test the property `rating`', () async {
      // TODO
    });

    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // String shortDescription
    test('to test the property `shortDescription`', () async {
      // TODO
    });

    // String releaseDate
    test('to test the property `releaseDate`', () async {
      // TODO
    });

    // String developer
    test('to test the property `developer`', () async {
      // TODO
    });

    // RetrieveGameById200ResponsePlaytime playtime
    test('to test the property `playtime`', () async {
      // TODO
    });

    // List<SearchGamesAPI200ResponseResultsInnerPlatformsInner> platforms (default value: const [])
    test('to test the property `platforms`', () async {
      // TODO
    });

    // List<String> tags (default value: const [])
    test('to test the property `tags`', () async {
      // TODO
    });

    // List<SearchGamesAPI200ResponseResultsInnerPlatformsInner> genres (default value: const [])
    test('to test the property `genres`', () async {
      // TODO
    });

    // String genre
    test('to test the property `genre`', () async {
      // TODO
    });

    // List<SearchGamesAPI200ResponseResultsInnerPlatformsInner> themes (default value: const [])
    test('to test the property `themes`', () async {
      // TODO
    });

    // bool adultOnly
    test('to test the property `adultOnly`', () async {
      // TODO
    });

    // List<SearchGamesAPI200ResponseResultsInnerPlatformsInner> playModes (default value: const [])
    test('to test the property `playModes`', () async {
      // TODO
    });

    // List<String> screenshots (default value: const [])
    test('to test the property `screenshots`', () async {
      // TODO
    });

    // List<String> videos (default value: const [])
    test('to test the property `videos`', () async {
      // TODO
    });

    // List<RetrieveGameById200ResponseOffersInner> offers (default value: const [])
    test('to test the property `offers`', () async {
      // TODO
    });

    // List<RetrieveGameById200ResponseOfficialStoresInner> officialStores (default value: const [])
    test('to test the property `officialStores`', () async {
      // TODO
    });

    // String microTrailer
    test('to test the property `microTrailer`', () async {
      // TODO
    });


  });

}
