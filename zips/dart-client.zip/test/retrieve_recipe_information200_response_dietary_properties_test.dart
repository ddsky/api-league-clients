//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformation200ResponseDietaryProperties
void main() {
  // final instance = RetrieveRecipeInformation200ResponseDietaryProperties();

  group('test RetrieveRecipeInformation200ResponseDietaryProperties', () {
    // bool lowFodmap
    test('to test the property `lowFodmap`', () async {
      // TODO
    });

    // bool vegetarian
    test('to test the property `vegetarian`', () async {
      // TODO
    });

    // bool vegan
    test('to test the property `vegan`', () async {
      // TODO
    });

    // bool glutenFree
    test('to test the property `glutenFree`', () async {
      // TODO
    });

    // bool dairyFree
    test('to test the property `dairyFree`', () async {
      // TODO
    });

    // String gaps
    test('to test the property `gaps`', () async {
      // TODO
    });

    // List<String> diets (default value: const [])
    test('to test the property `diets`', () async {
      // TODO
    });


  });

}
