//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformation200ResponseScores
void main() {
  // final instance = RetrieveRecipeInformation200ResponseScores();

  group('test RetrieveRecipeInformation200ResponseScores', () {
    // num metaScore
    test('to test the property `metaScore`', () async {
      // TODO
    });

    // int weightWatcherSmartPoints
    test('to test the property `weightWatcherSmartPoints`', () async {
      // TODO
    });

    // int healthScore
    test('to test the property `healthScore`', () async {
      // TODO
    });


  });

}
