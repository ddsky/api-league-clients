//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchMemes200Response
void main() {
  // final instance = SearchMemes200Response();

  group('test SearchMemes200Response', () {
    // List<SearchMemes200ResponseMemesInner> memes (default value: const [])
    test('to test the property `memes`', () async {
      // TODO
    });

    // int available
    test('to test the property `available`', () async {
      // TODO
    });


  });

}
