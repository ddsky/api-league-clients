//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchGamesAPI200ResponseFilterOptionsInner
void main() {
  // final instance = SearchGamesAPI200ResponseFilterOptionsInner();

  group('test SearchGamesAPI200ResponseFilterOptionsInner', () {
    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String filterType
    test('to test the property `filterType`', () async {
      // TODO
    });

    // String key
    test('to test the property `key`', () async {
      // TODO
    });

    // List<SearchGamesAPI200ResponseFilterOptionsInnerValuesInner> values (default value: const [])
    test('to test the property `values`', () async {
      // TODO
    });

    // String filterConnection
    test('to test the property `filterConnection`', () async {
      // TODO
    });


  });

}
