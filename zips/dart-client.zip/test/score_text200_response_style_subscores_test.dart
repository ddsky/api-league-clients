//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ScoreText200ResponseStyleSubscores
void main() {
  // final instance = ScoreText200ResponseStyleSubscores();

  group('test ScoreText200ResponseStyleSubscores', () {
    // List<int> abbreviationScore (default value: const [])
    test('to test the property `abbreviationScore`', () async {
      // TODO
    });

    // List<int> styleScore (default value: const [])
    test('to test the property `styleScore`', () async {
      // TODO
    });

    // List<int> spellingScore (default value: const [])
    test('to test the property `spellingScore`', () async {
      // TODO
    });


  });

}
