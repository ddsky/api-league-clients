//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs
void main() {
  // final instance = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs();

  group('test SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs', () {
    // String unitShort
    test('to test the property `unitShort`', () async {
      // TODO
    });

    // int amount
    test('to test the property `amount`', () async {
      // TODO
    });

    // String unitLong
    test('to test the property `unitLong`', () async {
      // TODO
    });


  });

}
