//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner
void main() {
  // final instance = SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner();

  group('test SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner', () {
    // int number
    test('to test the property `number`', () async {
      // TODO
    });

    // List<SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner> ingredients (default value: const [])
    test('to test the property `ingredients`', () async {
      // TODO
    });

    // List<String> equipment (default value: const [])
    test('to test the property `equipment`', () async {
      // TODO
    });

    // String step
    test('to test the property `step`', () async {
      // TODO
    });


  });

}
