//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for DetectMainImageColorAPI200ResponseInner
void main() {
  // final instance = DetectMainImageColorAPI200ResponseInner();

  group('test DetectMainImageColorAPI200ResponseInner', () {
    // String specificColor
    test('to test the property `specificColor`', () async {
      // TODO
    });

    // String mainColor
    test('to test the property `mainColor`', () async {
      // TODO
    });

    // String hexCode
    test('to test the property `hexCode`', () async {
      // TODO
    });


  });

}
