//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for FindSimilarGamesAPI200ResponseResultsInner
void main() {
  // final instance = FindSimilarGamesAPI200ResponseResultsInner();

  group('test FindSimilarGamesAPI200ResponseResultsInner', () {
    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String shortDescription
    test('to test the property `shortDescription`', () async {
      // TODO
    });

    // String microTrailer
    test('to test the property `microTrailer`', () async {
      // TODO
    });

    // int year
    test('to test the property `year`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String genre
    test('to test the property `genre`', () async {
      // TODO
    });

    // String link
    test('to test the property `link`', () async {
      // TODO
    });

    // SearchGamesAPI200ResponseResultsInnerRating rating
    test('to test the property `rating`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // bool adultOnly
    test('to test the property `adultOnly`', () async {
      // TODO
    });

    // List<String> screenshots (default value: const [])
    test('to test the property `screenshots`', () async {
      // TODO
    });

    // String gameplay
    test('to test the property `gameplay`', () async {
      // TODO
    });


  });

}
