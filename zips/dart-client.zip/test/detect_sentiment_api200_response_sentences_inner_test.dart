//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for DetectSentimentAPI200ResponseSentencesInner
void main() {
  // final instance = DetectSentimentAPI200ResponseSentencesInner();

  group('test DetectSentimentAPI200ResponseSentencesInner', () {
    // int length
    test('to test the property `length`', () async {
      // TODO
    });

    // String sentiment
    test('to test the property `sentiment`', () async {
      // TODO
    });

    // int offset
    test('to test the property `offset`', () async {
      // TODO
    });

    // int confidence
    test('to test the property `confidence`', () async {
      // TODO
    });


  });

}
