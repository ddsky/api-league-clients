//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRestaurantsAPI200ResponseRestaurantsInnerAddress
void main() {
  // final instance = SearchRestaurantsAPI200ResponseRestaurantsInnerAddress();

  group('test SearchRestaurantsAPI200ResponseRestaurantsInnerAddress', () {
    // String zipcode
    test('to test the property `zipcode`', () async {
      // TODO
    });

    // String country
    test('to test the property `country`', () async {
      // TODO
    });

    // String city
    test('to test the property `city`', () async {
      // TODO
    });

    // num latitude
    test('to test the property `latitude`', () async {
      // TODO
    });

    // num lon
    test('to test the property `lon`', () async {
      // TODO
    });

    // String streetAddr2
    test('to test the property `streetAddr2`', () async {
      // TODO
    });

    // String state
    test('to test the property `state`', () async {
      // TODO
    });

    // String streetAddr
    test('to test the property `streetAddr`', () async {
      // TODO
    });

    // num lat
    test('to test the property `lat`', () async {
      // TODO
    });

    // num longitude
    test('to test the property `longitude`', () async {
      // TODO
    });


  });

}
