//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformation200Response
void main() {
  // final instance = RetrieveRecipeInformation200Response();

  group('test RetrieveRecipeInformation200Response', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // int servings
    test('to test the property `servings`', () async {
      // TODO
    });

    // List<String> images (default value: const [])
    test('to test the property `images`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseDietaryProperties dietaryProperties
    test('to test the property `dietaryProperties`', () async {
      // TODO
    });

    // num pricePerServing
    test('to test the property `pricePerServing`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseTimes times
    test('to test the property `times`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseNutrition nutrition
    test('to test the property `nutrition`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseTaste taste
    test('to test the property `taste`', () async {
      // TODO
    });

    // List<String> cuisines (default value: const [])
    test('to test the property `cuisines`', () async {
      // TODO
    });

    // List<String> mealTypes (default value: const [])
    test('to test the property `mealTypes`', () async {
      // TODO
    });

    // List<String> occasions (default value: const [])
    test('to test the property `occasions`', () async {
      // TODO
    });

    // List<RetrieveRecipeInformation200ResponseIngredientsInner> ingredients (default value: const [])
    test('to test the property `ingredients`', () async {
      // TODO
    });

    // List<RetrieveRecipeInformation200ResponseInstructionsInner> instructions (default value: const [])
    test('to test the property `instructions`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseCredits credits
    test('to test the property `credits`', () async {
      // TODO
    });

    // RetrieveRecipeInformation200ResponseScores scores
    test('to test the property `scores`', () async {
      // TODO
    });


  });

}
