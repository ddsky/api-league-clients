//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for GamesApi
void main() {
  // final instance = GamesApi();

  group('tests for GamesApi', () {
    // Find Similar Games API
    //
    // Find similar games based on a given game using AI. This API allows you to retrieve a list of games that are similar to a specified game, providing recommendations based on various factors such as genre, gameplay mechanics, and user preferences.
    //
    //Future<FindSimilarGamesAPI200Response> findSimilarGamesAPI(int id, { int limit }) async
    test('test findSimilarGamesAPI', () async {
      // TODO
    });

    // Retrieve Game by Id
    //
    // This API allows you to retrieve detailed information about a specific game by its unique identifier. Game details include the game's name, description, release date, developer, platforms, genres, tags, ratings, screenshots, videos, and more.
    //
    //Future<RetrieveGameById200Response> retrieveGameById(int id) async
    test('test retrieveGameById', () async {
      // TODO
    });

    // Search Games API
    //
    // Search through a vast database of over half a million video games from more than 50 platforms. This API allows you to find games based on various criteria such as genre, platform, release date, and more. The results include detailed information about each game, including ratings, descriptions, and images.
    //
    //Future<SearchGamesAPI200Response> searchGamesAPI({ String query, int offset, int limit, String filters, String sort, String sortOrder, bool generateFilterOptions }) async
    test('test searchGamesAPI', () async {
      // TODO
    });

  });
}
