//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational
void main() {
  // final instance = SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational();

  group('test SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational', () {
    // String sunday
    test('to test the property `sunday`', () async {
      // TODO
    });

    // String saturday
    test('to test the property `saturday`', () async {
      // TODO
    });

    // String tuesday
    test('to test the property `tuesday`', () async {
      // TODO
    });

    // String thursday
    test('to test the property `thursday`', () async {
      // TODO
    });

    // String friday
    test('to test the property `friday`', () async {
      // TODO
    });

    // String wednesday
    test('to test the property `wednesday`', () async {
      // TODO
    });

    // String monday
    test('to test the property `monday`', () async {
      // TODO
    });


  });

}
