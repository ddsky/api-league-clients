//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveGameById200ResponseRating
void main() {
  // final instance = RetrieveGameById200ResponseRating();

  group('test RetrieveGameById200ResponseRating', () {
    // int count
    test('to test the property `count`', () async {
      // TODO
    });

    // int countCritics
    test('to test the property `countCritics`', () async {
      // TODO
    });

    // num meanPlayers
    test('to test the property `meanPlayers`', () async {
      // TODO
    });

    // num meanCritics
    test('to test the property `meanCritics`', () async {
      // TODO
    });

    // num mean
    test('to test the property `mean`', () async {
      // TODO
    });

    // int countPlayers
    test('to test the property `countPlayers`', () async {
      // TODO
    });


  });

}
