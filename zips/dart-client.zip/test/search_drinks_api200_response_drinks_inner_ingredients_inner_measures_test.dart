//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures
void main() {
  // final instance = SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures();

  group('test SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures', () {
    // SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs us
    test('to test the property `us`', () async {
      // TODO
    });

    // SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric metric
    test('to test the property `metric`', () async {
      // TODO
    });


  });

}
