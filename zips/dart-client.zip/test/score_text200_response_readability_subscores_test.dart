//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ScoreText200ResponseReadabilitySubscores
void main() {
  // final instance = ScoreText200ResponseReadabilitySubscores();

  group('test ScoreText200ResponseReadabilitySubscores', () {
    // int readingTimeSeconds
    test('to test the property `readingTimeSeconds`', () async {
      // TODO
    });

    // num forcast
    test('to test the property `forcast`', () async {
      // TODO
    });

    // num flesch
    test('to test the property `flesch`', () async {
      // TODO
    });

    // num smog
    test('to test the property `smog`', () async {
      // TODO
    });

    // num ari
    test('to test the property `ari`', () async {
      // TODO
    });

    // num lix
    test('to test the property `lix`', () async {
      // TODO
    });

    // num colemanLiau
    test('to test the property `colemanLiau`', () async {
      // TODO
    });

    // num kincaid
    test('to test the property `kincaid`', () async {
      // TODO
    });

    // num fog
    test('to test the property `fog`', () async {
      // TODO
    });


  });

}
