//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchJokesAPI200Response
void main() {
  // final instance = SearchJokesAPI200Response();

  group('test SearchJokesAPI200Response', () {
    // List<SearchJokesAPI200ResponseJokesInner> jokes (default value: const [])
    test('to test the property `jokes`', () async {
      // TODO
    });

    // int available
    test('to test the property `available`', () async {
      // TODO
    });


  });

}
