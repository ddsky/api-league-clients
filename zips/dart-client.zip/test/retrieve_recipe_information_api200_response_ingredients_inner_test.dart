//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformationAPI200ResponseIngredientsInner
void main() {
  // final instance = RetrieveRecipeInformationAPI200ResponseIngredientsInner();

  group('test RetrieveRecipeInformationAPI200ResponseIngredientsInner', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String aisle
    test('to test the property `aisle`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String consistency
    test('to test the property `consistency`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String original
    test('to test the property `original`', () async {
      // TODO
    });

    // num amount
    test('to test the property `amount`', () async {
      // TODO
    });

    // String unit
    test('to test the property `unit`', () async {
      // TODO
    });

    // List<String> meta (default value: const [])
    test('to test the property `meta`', () async {
      // TODO
    });

    // RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures measures
    test('to test the property `measures`', () async {
      // TODO
    });

    // String originalName
    test('to test the property `originalName`', () async {
      // TODO
    });

    // String nameClean
    test('to test the property `nameClean`', () async {
      // TODO
    });


  });

}
