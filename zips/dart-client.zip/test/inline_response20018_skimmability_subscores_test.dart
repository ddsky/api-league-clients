//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for InlineResponse20018SkimmabilitySubscores
void main() {
  final instance = InlineResponse20018SkimmabilitySubscores();

  group('test InlineResponse20018SkimmabilitySubscores', () {
    // List<int> bulletPointRatioScore (default value: const [])
    test('to test the property `bulletPointRatioScore`', () async {
      // TODO
    });

    // List<int> imageScore (default value: const [])
    test('to test the property `imageScore`', () async {
      // TODO
    });

    // List<int> highlightedWordRatioScore (default value: const [])
    test('to test the property `highlightedWordRatioScore`', () async {
      // TODO
    });

    // List<int> videoScore (default value: const [])
    test('to test the property `videoScore`', () async {
      // TODO
    });

    // List<int> paragraphScore (default value: const [])
    test('to test the property `paragraphScore`', () async {
      // TODO
    });

    // List<int> paragraphHeadlineRatioScore (default value: const [])
    test('to test the property `paragraphHeadlineRatioScore`', () async {
      // TODO
    });


  });

}
