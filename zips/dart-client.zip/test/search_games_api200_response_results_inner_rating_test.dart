//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchGamesAPI200ResponseResultsInnerRating
void main() {
  // final instance = SearchGamesAPI200ResponseResultsInnerRating();

  group('test SearchGamesAPI200ResponseResultsInnerRating', () {
    // num mean
    test('to test the property `mean`', () async {
      // TODO
    });

    // int count
    test('to test the property `count`', () async {
      // TODO
    });


  });

}
