//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformationAPI200ResponseNutrition
void main() {
  // final instance = RetrieveRecipeInformationAPI200ResponseNutrition();

  group('test RetrieveRecipeInformationAPI200ResponseNutrition', () {
    // SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing weightPerServing
    test('to test the property `weightPerServing`', () async {
      // TODO
    });

    // SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown caloricBreakdown
    test('to test the property `caloricBreakdown`', () async {
      // TODO
    });

    // List<SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner> flavonoids (default value: const [])
    test('to test the property `flavonoids`', () async {
      // TODO
    });

    // List<RetrieveRecipeInformationAPI200ResponseNutritionIngredientBreakdownInner> ingredientBreakdown (default value: const [])
    test('to test the property `ingredientBreakdown`', () async {
      // TODO
    });

    // List<SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner> properties (default value: const [])
    test('to test the property `properties`', () async {
      // TODO
    });

    // List<SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner> nutrients (default value: const [])
    test('to test the property `nutrients`', () async {
      // TODO
    });


  });

}
