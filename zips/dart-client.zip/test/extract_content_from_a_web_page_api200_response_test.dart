//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ExtractContentFromAWebPageAPI200Response
void main() {
  // final instance = ExtractContentFromAWebPageAPI200Response();

  group('test ExtractContentFromAWebPageAPI200Response', () {
    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // String mainText
    test('to test the property `mainText`', () async {
      // TODO
    });

    // String mainHtml
    test('to test the property `mainHtml`', () async {
      // TODO
    });

    // List<String> images (default value: const [])
    test('to test the property `images`', () async {
      // TODO
    });


  });

}
