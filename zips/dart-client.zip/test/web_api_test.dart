//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for WebApi
void main() {
  // final instance = WebApi();

  group('tests for WebApi', () {
    // Extract Authors
    //
    // Extracts the authors from a given URL. This API is useful for extracting the authors from a blog post or news article. The API will return a list of authors with their names and links to their profiles if available.
    //
    //Future<ExtractAuthors200Response> extractAuthors(String url) async
    test('test extractAuthors', () async {
      // TODO
    });

    // Extract Content from a Web Page
    //
    // Extract the main content from a web page. This API is useful for extracting the main text, title, and images from a web page. It can be used to create a summary of the content of a web page, or to extract the main content of a web page to display it in a different format.
    //
    //Future<ExtractContentFromAWebPage200Response> extractContentFromAWebPage(String url) async
    test('test extractContentFromAWebPage', () async {
      // TODO
    });

    // Extract Publish Date
    //
    // Extract the publish date of an article (news or blog). The API will return the publish date of the article if it can be found. The date returned is in the format YYYY-MM-DD.
    //
    //Future<ExtractPublishDate200Response> extractPublishDate(String url) async
    test('test extractPublishDate', () async {
      // TODO
    });

    // Search Web
    //
    // Search the web for a given query. The API returns a list of results with the title, summary, and URL.
    //
    //Future<SearchWeb200Response> searchWeb(String query, { int number }) async
    test('test searchWeb', () async {
      // TODO
    });

  });
}
