//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for InlineResponse20020Dates
void main() {
  final instance = InlineResponse20020Dates();

  group('test InlineResponse20020Dates', () {
    // int startPosition
    test('to test the property `startPosition`', () async {
      // TODO
    });

    // String date
    test('to test the property `date`', () async {
      // TODO
    });

    // ModelNull normalizedDate
    test('to test the property `normalizedDate`', () async {
      // TODO
    });

    // String tag
    test('to test the property `tag`', () async {
      // TODO
    });

    // int endPosition
    test('to test the property `endPosition`', () async {
      // TODO
    });


  });

}
