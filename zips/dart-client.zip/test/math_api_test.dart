//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for MathApi
void main() {
  final instance = MathApi();

  group('tests for MathApi', () {
    // Convert Units
    //
    // Convert units from one to another. The API returns the amount and the unit of the target unit.
    //
    //Future<InlineResponse20029> convertUnits(double sourceAmount, String sourceUnit, String targetUnit, { String foodName }) async
    test('test convertUnits', () async {
      // TODO
    });

  });
}
