//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for StorageApi
void main() {
  final instance = StorageApi();

  group('tests for StorageApi', () {
    // Read Key Value from Store
    //
    // Read a value from the key-value store. The key-value store is a simple storage system that allows you to store and retrieve data using a key. The data is stored in the cloud and can be accessed from anywhere. You can use the key-value store to store any type of data, such as text or numbers. The key-value store is a great way to store data that you want to access from multiple devices or locations.
    //
    //Future<InlineResponse20030> readKeyValueFromStore(String key) async
    test('test readKeyValueFromStore', () async {
      // TODO
    });

    // Store Key Value (GET)
    //
    // Store a value in the key-value store. The key-value store is a simple storage system that allows you to store and retrieve data using a key. The data is stored in the cloud and can be accessed from anywhere. You can use the key-value store to store any type of data, such as text or numbers. The key-value store is a great way to store data that you want to access from multiple devices or locations.
    //
    //Future<InlineResponse20031> storeKeyValueGET(String key, String value) async
    test('test storeKeyValueGET', () async {
      // TODO
    });

  });
}
