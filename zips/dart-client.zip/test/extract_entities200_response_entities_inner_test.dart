//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ExtractEntities200ResponseEntitiesInner
void main() {
  // final instance = ExtractEntities200ResponseEntitiesInner();

  group('test ExtractEntities200ResponseEntitiesInner', () {
    // int startPosition
    test('to test the property `startPosition`', () async {
      // TODO
    });

    // String image
    test('to test the property `image`', () async {
      // TODO
    });

    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // String value
    test('to test the property `value`', () async {
      // TODO
    });

    // int endPosition
    test('to test the property `endPosition`', () async {
      // TODO
    });


  });

}
