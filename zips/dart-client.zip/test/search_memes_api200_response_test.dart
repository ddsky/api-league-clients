//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchMemesAPI200Response
void main() {
  // final instance = SearchMemesAPI200Response();

  group('test SearchMemesAPI200Response', () {
    // List<SearchMemesAPI200ResponseMemesInner> memes (default value: const [])
    test('to test the property `memes`', () async {
      // TODO
    });

    // int available
    test('to test the property `available`', () async {
      // TODO
    });


  });

}
