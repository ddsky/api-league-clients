//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchDrinksAPI200ResponseDrinksInner
void main() {
  // final instance = SearchDrinksAPI200ResponseDrinksInner();

  group('test SearchDrinksAPI200ResponseDrinksInner', () {
    // List<String> flavors (default value: const [])
    test('to test the property `flavors`', () async {
      // TODO
    });

    // List<SearchDrinksAPI200ResponseDrinksInnerInstructionsInner> instructions (default value: const [])
    test('to test the property `instructions`', () async {
      // TODO
    });

    // List<String> images (default value: const [])
    test('to test the property `images`', () async {
      // TODO
    });

    // SearchDrinksAPI200ResponseDrinksInnerNutrition nutrition
    test('to test the property `nutrition`', () async {
      // TODO
    });

    // String glassType
    test('to test the property `glassType`', () async {
      // TODO
    });

    // SearchDrinksAPI200ResponseDrinksInnerCredits credits
    test('to test the property `credits`', () async {
      // TODO
    });

    // num pricePerServing
    test('to test the property `pricePerServing`', () async {
      // TODO
    });

    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // List<SearchDrinksAPI200ResponseDrinksInnerIngredientsInner> ingredients (default value: const [])
    test('to test the property `ingredients`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // String title
    test('to test the property `title`', () async {
      // TODO
    });

    // List<String> cuisines (default value: const [])
    test('to test the property `cuisines`', () async {
      // TODO
    });


  });

}
