//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for ScoreTextAPI200Response
void main() {
  // final instance = ScoreTextAPI200Response();

  group('test ScoreTextAPI200Response', () {
    // int numberOfWords
    test('to test the property `numberOfWords`', () async {
      // TODO
    });

    // int numberOfSentences
    test('to test the property `numberOfSentences`', () async {
      // TODO
    });

    // ScoreTextAPI200ResponseReadability readability
    test('to test the property `readability`', () async {
      // TODO
    });

    // ScoreTextAPI200ResponseSkimmability skimmability
    test('to test the property `skimmability`', () async {
      // TODO
    });

    // ScoreTextAPI200ResponseInterestingness interestingness
    test('to test the property `interestingness`', () async {
      // TODO
    });

    // ScoreTextAPI200ResponseStyle style
    test('to test the property `style`', () async {
      // TODO
    });

    // num totalScore
    test('to test the property `totalScore`', () async {
      // TODO
    });


  });

}
