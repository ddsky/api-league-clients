//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.0

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for ArtApi
void main() {
  final instance = ArtApi();

  group('tests for ArtApi', () {
    // Image to Ascii Art by Image File
    //
    // Convert an image to ASCII art. You can pass the image as body to the API. This endpoint is using the POST method and the actual image file as the body of the request.
    //
    //Future<String> imageToAsciiArtByImageFile({ num width, num height }) async
    test('test imageToAsciiArtByImageFile', () async {
      // TODO
    });

    // Random Poem
    //
    // Retrieve a random poem by many famous authors. You can filter poem's by length (number of lines).
    //
    //Future<InlineResponse20011> randomPoem({ num minLines, num maxLines }) async
    test('test randomPoem', () async {
      // TODO
    });

  });
}
