//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';


/// tests for ArtApi
void main() {
  // final instance = ArtApi();

  group('tests for ArtApi', () {
    // Image to Ascii Art by URL API
    //
    // Convert an image to ASCII art. You can pass the image URL as a query parameter. The API returns the ASCII art as plain text. This endpoint is using the GET method and an image URL as a query parameter.
    //
    //Future<String> imageToAsciiArtByURLAPI(String url, { int width, int height }) async
    test('test imageToAsciiArtByURLAPI', () async {
      // TODO
    });

    // Random Poem API
    //
    // Retrieve a random poem by many famous authors. You can filter poem's by length (number of lines).
    //
    //Future<RandomPoemAPI200Response> randomPoemAPI({ int minLines, int maxLines }) async
    test('test randomPoemAPI', () async {
      // TODO
    });

  });
}
