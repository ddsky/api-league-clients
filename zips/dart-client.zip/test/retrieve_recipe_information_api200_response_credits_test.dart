//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformationAPI200ResponseCredits
void main() {
  // final instance = RetrieveRecipeInformationAPI200ResponseCredits();

  group('test RetrieveRecipeInformationAPI200ResponseCredits', () {
    // String sourceName
    test('to test the property `sourceName`', () async {
      // TODO
    });

    // String sourceUrl
    test('to test the property `sourceUrl`', () async {
      // TODO
    });

    // String text
    test('to test the property `text`', () async {
      // TODO
    });

    // String license
    test('to test the property `license`', () async {
      // TODO
    });


  });

}
