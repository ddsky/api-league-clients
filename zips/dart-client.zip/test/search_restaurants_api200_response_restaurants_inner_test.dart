//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for SearchRestaurantsAPI200ResponseRestaurantsInner
void main() {
  // final instance = SearchRestaurantsAPI200ResponseRestaurantsInner();

  group('test SearchRestaurantsAPI200ResponseRestaurantsInner', () {
    // bool offersThirdPartyDelivery
    test('to test the property `offersThirdPartyDelivery`', () async {
      // TODO
    });

    // SearchRestaurantsAPI200ResponseRestaurantsInnerAddress address
    test('to test the property `address`', () async {
      // TODO
    });

    // bool supportsUpcCodes
    test('to test the property `supportsUpcCodes`', () async {
      // TODO
    });

    // bool isOpen
    test('to test the property `isOpen`', () async {
      // TODO
    });

    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // int weightedRatingValue
    test('to test the property `weightedRatingValue`', () async {
      // TODO
    });

    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // bool offersFirstPartyDelivery
    test('to test the property `offersFirstPartyDelivery`', () async {
      // TODO
    });

    // int aggregatedRatingCount
    test('to test the property `aggregatedRatingCount`', () async {
      // TODO
    });

    // bool pickupEnabled
    test('to test the property `pickupEnabled`', () async {
      // TODO
    });

    // List<String> cuisines (default value: const [])
    test('to test the property `cuisines`', () async {
      // TODO
    });

    // num miles
    test('to test the property `miles`', () async {
      // TODO
    });

    // int dollarSigns
    test('to test the property `dollarSigns`', () async {
      // TODO
    });

    // bool deliveryEnabled
    test('to test the property `deliveryEnabled`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // num phoneNumber
    test('to test the property `phoneNumber`', () async {
      // TODO
    });

    // String id
    test('to test the property `id`', () async {
      // TODO
    });

    // SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours localHours
    test('to test the property `localHours`', () async {
      // TODO
    });


  });

}
