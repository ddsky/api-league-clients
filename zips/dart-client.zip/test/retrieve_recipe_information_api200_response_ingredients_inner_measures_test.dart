//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures
void main() {
  // final instance = RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures();

  group('test RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures', () {
    // SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric metric
    test('to test the property `metric`', () async {
      // TODO
    });

    // SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric us
    test('to test the property `us`', () async {
      // TODO
    });


  });

}
