//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.12

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:openapi/api.dart';
import 'package:test/test.dart';

// tests for RandomMeme200Response
void main() {
  // final instance = RandomMeme200Response();

  group('test RandomMeme200Response', () {
    // String description
    test('to test the property `description`', () async {
      // TODO
    });

    // String url
    test('to test the property `url`', () async {
      // TODO
    });

    // String type
    test('to test the property `type`', () async {
      // TODO
    });

    // int width
    test('to test the property `width`', () async {
      // TODO
    });

    // int height
    test('to test the property `height`', () async {
      // TODO
    });

    // num ratio
    test('to test the property `ratio`', () async {
      // TODO
    });


  });

}
