# WWW::OpenAPIClient::Object::SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


