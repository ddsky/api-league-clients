# WWW::OpenAPIClient::Object::InlineResponse20030

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20030;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target_amount** | **double** |  | [optional] 
**target_unit** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


