# WWW::OpenAPIClient::Object::SearchRecipes200ResponseRecipesInnerNutrition

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRecipes200ResponseRecipesInnerNutrition;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**ARRAY[SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner]**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


