# WWW::OpenAPIClient::Object::SearchWebAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchWebAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**ARRAY[SearchWebAPI200ResponseResultsInner]**](SearchWebAPI200ResponseResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


