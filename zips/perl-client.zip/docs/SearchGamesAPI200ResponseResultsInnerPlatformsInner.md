# WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseResultsInnerPlatformsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseResultsInnerPlatformsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**value** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


