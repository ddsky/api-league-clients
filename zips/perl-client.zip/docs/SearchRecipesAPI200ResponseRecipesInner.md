# WWW::OpenAPIClient::Object::SearchRecipesAPI200ResponseRecipesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRecipesAPI200ResponseRecipesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **ARRAY[string]** |  | [optional] 
**nutrition** | [**SearchRecipesAPI200ResponseRecipesInnerNutrition**](SearchRecipesAPI200ResponseRecipesInnerNutrition.md) |  | [optional] 
**id** | **int** |  | [optional] 
**title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


