# WWW::OpenAPIClient::Object::InlineResponse2007

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse2007;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**ARRAY[InlineResponse2007Images]**](InlineResponse2007Images.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


