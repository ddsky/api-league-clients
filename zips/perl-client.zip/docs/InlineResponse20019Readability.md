# WWW::OpenAPIClient::Object::InlineResponse20019Readability

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20019Readability;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20019ReadabilityMainscores**](InlineResponse20019ReadabilityMainscores.md) |  | [optional] 
**subscores** | [**InlineResponse20019ReadabilitySubscores**](InlineResponse20019ReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


