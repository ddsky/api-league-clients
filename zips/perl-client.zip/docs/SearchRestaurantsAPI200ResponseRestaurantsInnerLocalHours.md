# WWW::OpenAPIClient::Object::SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**delivery** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**pickup** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**dine_in** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


