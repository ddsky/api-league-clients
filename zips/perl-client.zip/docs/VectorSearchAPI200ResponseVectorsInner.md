# WWW::OpenAPIClient::Object::VectorSearchAPI200ResponseVectorsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::VectorSearchAPI200ResponseVectorsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **string** |  | [optional] 
**title** | **string** |  | [optional] 
**author** | **string** |  | [optional] 
**image_url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


