# WWW::OpenAPIClient::Object::RetrieveGameById200ResponseOfficialStoresInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveGameById200ResponseOfficialStoresInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** |  | [optional] 
**source** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


