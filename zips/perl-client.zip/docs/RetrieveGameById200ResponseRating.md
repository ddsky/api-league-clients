# WWW::OpenAPIClient::Object::RetrieveGameById200ResponseRating

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveGameById200ResponseRating;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**count_critics** | **int** |  | [optional] 
**mean_players** | **double** |  | [optional] 
**mean_critics** | **double** |  | [optional] 
**mean** | **double** |  | [optional] 
**count_players** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


