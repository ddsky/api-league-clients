# WWW::OpenAPIClient::Object::SearchMemesAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchMemesAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**ARRAY[SearchMemesAPI200ResponseMemesInner]**](SearchMemesAPI200ResponseMemesInner.md) |  | [optional] 
**available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


