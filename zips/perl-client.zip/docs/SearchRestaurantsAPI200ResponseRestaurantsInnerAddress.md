# WWW::OpenAPIClient::Object::SearchRestaurantsAPI200ResponseRestaurantsInnerAddress

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRestaurantsAPI200ResponseRestaurantsInnerAddress;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **string** |  | [optional] 
**country** | **string** |  | [optional] 
**city** | **string** |  | [optional] 
**latitude** | **double** |  | [optional] 
**lon** | **double** |  | [optional] 
**street_addr_2** | **string** |  | [optional] 
**state** | **string** |  | [optional] 
**street_addr** | **string** |  | [optional] 
**lat** | **double** |  | [optional] 
**longitude** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


