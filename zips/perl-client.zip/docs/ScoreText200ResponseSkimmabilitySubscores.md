# WWW::OpenAPIClient::Object::ScoreText200ResponseSkimmabilitySubscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreText200ResponseSkimmabilitySubscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bullet_point_ratio_score** | **ARRAY[int]** |  | [optional] 
**image_score** | **ARRAY[int]** |  | [optional] 
**highlighted_word_ratio_score** | **ARRAY[int]** |  | [optional] 
**video_score** | **ARRAY[int]** |  | [optional] 
**paragraph_score** | **ARRAY[int]** |  | [optional] 
**paragraph_headline_ratio_score** | **ARRAY[int]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


