# WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerInstructionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerInstructionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**steps** | [**ARRAY[SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


