# WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseScores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseScores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta_score** | **double** |  | [optional] 
**weight_watcher_smart_points** | **int** |  | [optional] 
**health_score** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


