# WWW::OpenAPIClient::Object::InlineResponse20012

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20012;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional] 
**main_text** | **string** |  | [optional] 
**main_html** | **string** |  | [optional] 
**images** | **ARRAY[string]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


