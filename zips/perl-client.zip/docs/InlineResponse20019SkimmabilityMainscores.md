# WWW::OpenAPIClient::Object::InlineResponse20019SkimmabilityMainscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20019SkimmabilityMainscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | **int** |  | [optional] 
**total** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


