# WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**image** | **string** |  | [optional] 
**id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


