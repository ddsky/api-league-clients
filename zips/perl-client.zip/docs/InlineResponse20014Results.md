# WWW::OpenAPIClient::Object::InlineResponse20014Results

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20014Results;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional] 
**summary** | **string** |  | [optional] 
**url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


