# WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseTimes

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseTimes;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_minutes** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


