# WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | **string** |  | [optional] 
**amount** | **double** |  | [optional] 
**unit_long** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


