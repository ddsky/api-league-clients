# WWW::OpenAPIClient::Object::TopNews200ResponseTopNewsInnerNewsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::TopNews200ResponseTopNewsInnerNewsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **string** |  | [optional] 
**image** | **string** |  | [optional] 
**author** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**text** | **string** |  | [optional] 
**title** | **string** |  | [optional] 
**publish_date** | **string** |  | [optional] 
**url** | **string** |  | [optional] 
**authors** | **ARRAY[string]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


