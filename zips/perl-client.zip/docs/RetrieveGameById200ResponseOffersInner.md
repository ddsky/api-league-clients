# WWW::OpenAPIClient::Object::RetrieveGameById200ResponseOffersInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveGameById200ResponseOffersInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**store_name** | **string** |  | [optional] 
**title** | **string** |  | [optional] 
**price** | [**RetrieveGameById200ResponseOffersInnerPrice**](RetrieveGameById200ResponseOffersInnerPrice.md) |  | [optional] 
**platform** | **string** |  | [optional] 
**url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


