# WWW::OpenAPIClient::Object::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **string** |  | [optional] 
**saturday** | **string** |  | [optional] 
**tuesday** | **string** |  | [optional] 
**thursday** | **string** |  | [optional] 
**friday** | **string** |  | [optional] 
**wednesday** | **string** |  | [optional] 
**monday** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


