# WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseResultsInnerRating

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseResultsInnerRating;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**mean** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


