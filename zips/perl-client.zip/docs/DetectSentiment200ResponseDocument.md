# WWW::OpenAPIClient::Object::DetectSentiment200ResponseDocument

## Load the model package
```perl
use WWW::OpenAPIClient::Object::DetectSentiment200ResponseDocument;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | **string** |  | [optional] 
**confidence** | **int** |  | [optional] 
**average_confidence** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


