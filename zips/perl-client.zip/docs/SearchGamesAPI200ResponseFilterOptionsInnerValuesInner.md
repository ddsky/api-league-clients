# WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseFilterOptionsInnerValuesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseFilterOptionsInnerValuesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**count** | **int** |  | [optional] 
**key** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


