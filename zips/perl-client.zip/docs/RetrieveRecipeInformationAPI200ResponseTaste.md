# WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseTaste

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseTaste;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | **double** |  | [optional] 
**spiciness** | **int** |  | [optional] 
**saltiness** | **int** |  | [optional] 
**bitterness** | **double** |  | [optional] 
**savoriness** | **double** |  | [optional] 
**sweetness** | **double** |  | [optional] 
**sourness** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


