# WWW::OpenAPIClient::Object::SearchGifsAPI200ResponseImagesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGifsAPI200ResponseImagesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** |  | [optional] 
**width** | **int** |  | [optional] 
**height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


