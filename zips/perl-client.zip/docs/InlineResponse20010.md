# WWW::OpenAPIClient::Object::InlineResponse20010

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20010;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **string** |  | [optional] 
**quote** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


