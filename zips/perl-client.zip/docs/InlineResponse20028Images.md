# WWW::OpenAPIClient::Object::InlineResponse20028Images

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20028Images;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional] 
**license** | [**InlineResponse20028License**](InlineResponse20028License.md) |  | [optional] 
**thumbnail** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**url** | **string** |  | [optional] 
**height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


