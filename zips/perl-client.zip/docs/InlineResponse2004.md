# WWW::OpenAPIClient::Object::InlineResponse2004

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse2004;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**ARRAY[InlineResponse2004Jokes]**](InlineResponse2004Jokes.md) |  | [optional] 
**available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


