# WWW::OpenAPIClient::Object::ExtractAuthors200ResponseAuthorsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ExtractAuthors200ResponseAuthorsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **string** |  | [optional] 
**name** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


