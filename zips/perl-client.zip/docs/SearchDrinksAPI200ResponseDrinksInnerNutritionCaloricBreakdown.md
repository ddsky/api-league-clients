# WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_fat** | **double** |  | [optional] 
**percent_carbs** | **double** |  | [optional] 
**percent_protein** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


