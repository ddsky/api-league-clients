# WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseCredits

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseCredits;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **string** |  | [optional] 
**text** | **string** |  | [optional] 
**source_name** | **string** |  | [optional] 
**source_url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


