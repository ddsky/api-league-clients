# WWW::OpenAPIClient::Object::InlineResponse20021

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20021;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**ARRAY[InlineResponse20021Dates]**](InlineResponse20021Dates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


