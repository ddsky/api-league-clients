# WWW::OpenAPIClient::Object::SearchJokesAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchJokesAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**ARRAY[SearchJokesAPI200ResponseJokesInner]**](SearchJokesAPI200ResponseJokesInner.md) |  | [optional] 
**available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


