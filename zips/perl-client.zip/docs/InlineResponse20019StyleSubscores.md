# WWW::OpenAPIClient::Object::InlineResponse20019StyleSubscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20019StyleSubscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abbreviation_score** | **ARRAY[int]** |  | [optional] 
**style_score** | **ARRAY[int]** |  | [optional] 
**spelling_score** | **ARRAY[int]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


