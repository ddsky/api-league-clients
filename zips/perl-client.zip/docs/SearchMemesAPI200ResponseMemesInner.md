# WWW::OpenAPIClient::Object::SearchMemesAPI200ResponseMemesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchMemesAPI200ResponseMemesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** |  | [optional] 
**url** | **string** |  | [optional] 
**type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


