# WWW::OpenAPIClient::Object::RetrievePageRank200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrievePageRank200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page_rank** | **double** |  | [optional] 
**position** | **int** |  | [optional] 
**percentile** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


