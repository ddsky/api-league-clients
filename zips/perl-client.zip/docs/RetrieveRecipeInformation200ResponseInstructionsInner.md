# WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseInstructionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformation200ResponseInstructionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**steps** | [**ARRAY[RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


