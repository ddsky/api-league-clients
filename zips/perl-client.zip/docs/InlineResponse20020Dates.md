# WWW::OpenAPIClient::Object::InlineResponse20020Dates

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20020Dates;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | **int** |  | [optional] 
**date** | **string** |  | [optional] 
**normalized_date** | [**Null**](Null.md) |  | [optional] 
**tag** | **string** |  | [optional] 
**end_position** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


