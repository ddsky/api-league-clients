# WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseReadability

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseReadability;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**ScoreTextAPI200ResponseReadabilityMainscores**](ScoreTextAPI200ResponseReadabilityMainscores.md) |  | [optional] 
**subscores** | [**ScoreTextAPI200ResponseReadabilitySubscores**](ScoreTextAPI200ResponseReadabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


