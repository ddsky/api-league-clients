# WWW::OpenAPIClient::Object::ScoreText200ResponseSkimmability

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreText200ResponseSkimmability;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**ScoreText200ResponseSkimmabilityMainscores**](ScoreText200ResponseSkimmabilityMainscores.md) |  | [optional] 
**subscores** | [**ScoreText200ResponseSkimmabilitySubscores**](ScoreText200ResponseSkimmabilitySubscores.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


