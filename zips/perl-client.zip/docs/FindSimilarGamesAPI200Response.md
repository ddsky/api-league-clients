# WWW::OpenAPIClient::Object::FindSimilarGamesAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::FindSimilarGamesAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**ARRAY[FindSimilarGamesAPI200ResponseResultsInner]**](FindSimilarGamesAPI200ResponseResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


