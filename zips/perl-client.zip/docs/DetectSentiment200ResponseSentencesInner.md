# WWW::OpenAPIClient::Object::DetectSentiment200ResponseSentencesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::DetectSentiment200ResponseSentencesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **int** |  | [optional] 
**sentiment** | **string** |  | [optional] 
**offset** | **int** |  | [optional] 
**confidence** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


