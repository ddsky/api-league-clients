# WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | **string** |  | [optional] 
**amount** | **int** |  | [optional] 
**unit_long** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


