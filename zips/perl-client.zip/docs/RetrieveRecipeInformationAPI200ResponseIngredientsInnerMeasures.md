# WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseIngredientsInnerMeasures;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


