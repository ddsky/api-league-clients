# WWW::OpenAPIClient::Object::SearchJokes200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchJokes200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**ARRAY[SearchJokes200ResponseJokesInner]**](SearchJokes200ResponseJokesInner.md) |  | [optional] 
**available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


