# WWW::OpenAPIClient::Object::SearchGifs200ResponseImagesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGifs200ResponseImagesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional] 
**url** | **string** |  | [optional] 
**height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


