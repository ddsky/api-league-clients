# WWW::OpenAPIClient::Object::ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**percent_of_daily_needs** | **int** |  | [optional] 
**amount** | **int** |  | [optional] 
**unit** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


