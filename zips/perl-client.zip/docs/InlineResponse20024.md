# WWW::OpenAPIClient::Object::InlineResponse20024

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20024;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **string** |  | [optional] 
**stemmed** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


