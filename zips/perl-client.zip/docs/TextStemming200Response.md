# WWW::OpenAPIClient::Object::TextStemming200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::TextStemming200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **string** |  | [optional] 
**stemmed** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


