# WWW::OpenAPIClient::Object::InlineResponse20026Entities

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20026Entities;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | **int** |  | [optional] 
**image** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**value** | **string** |  | [optional] 
**end_position** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


