# WWW::OpenAPIClient::Object::InlineResponse20017

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20017;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **string** |  | [optional] 
**confidence** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


