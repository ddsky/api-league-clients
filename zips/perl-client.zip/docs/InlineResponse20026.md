# WWW::OpenAPIClient::Object::InlineResponse20026

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20026;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **string** |  | [optional] 
**plural** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


