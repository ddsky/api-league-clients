# WWW::OpenAPIClient::Object::SearchWeb200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchWeb200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**ARRAY[SearchWeb200ResponseResultsInner]**](SearchWeb200ResponseResultsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


