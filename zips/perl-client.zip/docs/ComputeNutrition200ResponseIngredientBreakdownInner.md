# WWW::OpenAPIClient::Object::ComputeNutrition200ResponseIngredientBreakdownInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ComputeNutrition200ResponseIngredientBreakdownInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**amount** | **int** |  | [optional] 
**unit** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**nutrients** | [**ARRAY[ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner]**](ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


