# WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseInterestingnessSubscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseInterestingnessSubscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title_rating_score** | **ARRAY[int]** |  | [optional] 
**quote_score** | **ARRAY[int]** |  | [optional] 
**length_score** | **ARRAY[int]** |  | [optional] 
**link_score** | **ARRAY[int]** |  | [optional] 
**google_hits_score** | **ARRAY[int]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


