# WWW::OpenAPIClient::Object::InlineResponse20027Images

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse20027Images;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional] 
**license** | [**InlineResponse20027License**](InlineResponse20027License.md) |  | [optional] 
**thumbnail** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**url** | **string** |  | [optional] 
**height** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


