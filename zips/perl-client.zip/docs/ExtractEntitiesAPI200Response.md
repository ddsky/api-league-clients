# WWW::OpenAPIClient::Object::ExtractEntitiesAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ExtractEntitiesAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**ARRAY[ExtractEntitiesAPI200ResponseEntitiesInner]**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


