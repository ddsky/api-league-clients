# WWW::OpenAPIClient::Object::SearchRestaurantsAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchRestaurantsAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**ARRAY[SearchRestaurantsAPI200ResponseRestaurantsInner]**](SearchRestaurantsAPI200ResponseRestaurantsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


