# WWW::OpenAPIClient::Object::SearchMemes200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchMemes200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**ARRAY[SearchMemes200ResponseMemesInner]**](SearchMemes200ResponseMemesInner.md) |  | [optional] 
**available** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


