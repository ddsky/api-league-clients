# WWW::OpenAPIClient::Object::InlineResponse2009

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse2009;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trivia** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


