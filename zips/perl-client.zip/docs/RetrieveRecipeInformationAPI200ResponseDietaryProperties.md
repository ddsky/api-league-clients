# WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseDietaryProperties

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RetrieveRecipeInformationAPI200ResponseDietaryProperties;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vegetarian** | **boolean** |  | [optional] 
**vegan** | **boolean** |  | [optional] 
**gluten_free** | **boolean** |  | [optional] 
**dairy_free** | **boolean** |  | [optional] 
**low_fodmap** | **boolean** |  | [optional] 
**gaps** | **string** |  | [optional] 
**diets** | **ARRAY[string]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


