# WWW::OpenAPIClient::Object::SearchBooks200ResponseBooksInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchBooks200ResponseBooksInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional] 
**image** | **string** |  | [optional] 
**id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


