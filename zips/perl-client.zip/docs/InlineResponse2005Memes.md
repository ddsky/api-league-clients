# WWW::OpenAPIClient::Object::InlineResponse2005Memes

## Load the model package
```perl
use WWW::OpenAPIClient::Object::InlineResponse2005Memes;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **string** |  | [optional] 
**description** | **string** |  | [optional] 
**url** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


