# WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseSkimmabilityMainscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreTextAPI200ResponseSkimmabilityMainscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | **int** |  | [optional] 
**total** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


