# WWW::OpenAPIClient::Object::ScoreText200ResponseReadabilityMainscores

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreText200ResponseReadabilityMainscores;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | **int** |  | [optional] 
**total** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


