# WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseFilterOptionsInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::SearchGamesAPI200ResponseFilterOptionsInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**filter_type** | **string** |  | [optional] 
**key** | **string** |  | [optional] 
**values** | [**ARRAY[SearchGamesAPI200ResponseFilterOptionsInnerValuesInner]**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  | [optional] 
**filter_connection** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


