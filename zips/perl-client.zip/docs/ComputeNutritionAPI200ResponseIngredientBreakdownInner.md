# WWW::OpenAPIClient::Object::ComputeNutritionAPI200ResponseIngredientBreakdownInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ComputeNutritionAPI200ResponseIngredientBreakdownInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**amount** | **int** |  | [optional] 
**unit** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**nutrients** | [**ARRAY[ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner]**](ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


