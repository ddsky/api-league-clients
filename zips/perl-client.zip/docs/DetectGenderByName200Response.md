# WWW::OpenAPIClient::Object::DetectGenderByName200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::DetectGenderByName200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**probability_male** | **double** |  | [optional] 
**probability_female** | **double** |  | [optional] 
**popularity** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


