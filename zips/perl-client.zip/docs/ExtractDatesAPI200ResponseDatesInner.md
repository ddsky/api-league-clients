# WWW::OpenAPIClient::Object::ExtractDatesAPI200ResponseDatesInner

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ExtractDatesAPI200ResponseDatesInner;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | **int** |  | [optional] 
**date** | **string** |  | [optional] 
**normalized_date** | **double** |  | [optional] 
**tag** | **string** |  | [optional] 
**end_position** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


