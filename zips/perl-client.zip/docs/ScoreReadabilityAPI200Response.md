# WWW::OpenAPIClient::Object::ScoreReadabilityAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::ScoreReadabilityAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | [**ScoreTextAPI200ResponseReadability**](ScoreTextAPI200ResponseReadability.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


