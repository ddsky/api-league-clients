# WWW::OpenAPIClient::Object::RandomLifeHackAPI200Response

## Load the model package
```perl
use WWW::OpenAPIClient::Object::RandomLifeHackAPI200Response;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional] 
**description** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


