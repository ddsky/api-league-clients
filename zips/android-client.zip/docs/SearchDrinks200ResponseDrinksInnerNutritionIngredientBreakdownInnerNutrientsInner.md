

# SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**percentOfDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**amount** | **Integer** |  |  [optional]
**unit** | **String** |  |  [optional]




