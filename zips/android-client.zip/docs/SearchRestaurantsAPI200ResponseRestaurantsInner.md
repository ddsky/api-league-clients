

# SearchRestaurantsAPI200ResponseRestaurantsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offersThirdPartyDelivery** | **Boolean** |  |  [optional]
**address** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerAddress**](SearchRestaurantsAPI200ResponseRestaurantsInnerAddress.md) |  |  [optional]
**supportsUpcCodes** | **Boolean** |  |  [optional]
**isOpen** | **Boolean** |  |  [optional]
**description** | **String** |  |  [optional]
**weightedRatingValue** | **Integer** |  |  [optional]
**type** | **String** |  |  [optional]
**offersFirstPartyDelivery** | **Boolean** |  |  [optional]
**aggregatedRatingCount** | **Integer** |  |  [optional]
**pickupEnabled** | **Boolean** |  |  [optional]
**cuisines** | **List&lt;String&gt;** |  |  [optional]
**miles** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**dollarSigns** | **Integer** |  |  [optional]
**deliveryEnabled** | **Boolean** |  |  [optional]
**name** | **String** |  |  [optional]
**phoneNumber** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**id** | **String** |  |  [optional]
**localHours** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours.md) |  |  [optional]




