

# VerifyEmailAddressAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** |  |  [optional]
**domain** | **String** |  |  [optional]
**firstName** | **String** |  |  [optional]
**middleName** | **String** |  |  [optional]
**lastName** | **String** |  |  [optional]
**fullName** | **String** |  |  [optional]
**username** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**result** | **String** |  |  [optional]
**disposable** | **Boolean** |  |  [optional]
**acceptAll** | **Boolean** |  |  [optional]
**freeProvider** | **Boolean** |  |  [optional]




