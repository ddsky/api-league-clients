

# RetrieveRecipeInformation200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**steps** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  |  [optional]




