

# InlineResponse2002

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**available** | **Integer** |  |  [optional]
**news** | [**List&lt;InlineResponse2002News&gt;**](InlineResponse2002News.md) |  |  [optional]




