

# ExtractNewsAPI200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**height** | **Integer** |  |  [optional]




