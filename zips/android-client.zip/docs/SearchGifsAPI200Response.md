

# SearchGifsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**List&lt;SearchGifsAPI200ResponseImagesInner&gt;**](SearchGifsAPI200ResponseImagesInner.md) |  |  [optional]




