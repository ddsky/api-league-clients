

# SearchWebAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**List&lt;SearchWebAPI200ResponseResultsInner&gt;**](SearchWebAPI200ResponseResultsInner.md) |  |  [optional]




