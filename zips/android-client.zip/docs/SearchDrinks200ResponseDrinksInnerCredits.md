

# SearchDrinks200ResponseDrinksInnerCredits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  |  [optional]
**sourceName** | **String** |  |  [optional]
**sourceUrl** | **String** |  |  [optional]




