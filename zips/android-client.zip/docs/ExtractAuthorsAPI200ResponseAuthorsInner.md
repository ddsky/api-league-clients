

# ExtractAuthorsAPI200ResponseAuthorsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **String** |  |  [optional]
**name** | **String** |  |  [optional]




