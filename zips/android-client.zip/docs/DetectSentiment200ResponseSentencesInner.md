

# DetectSentiment200ResponseSentencesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **Integer** |  |  [optional]
**sentiment** | **String** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**confidence** | **Integer** |  |  [optional]




