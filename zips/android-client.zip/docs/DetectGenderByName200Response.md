

# DetectGenderByName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**probabilityMale** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**probabilityFemale** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**popularity** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




