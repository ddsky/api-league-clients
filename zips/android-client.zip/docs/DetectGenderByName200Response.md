

# DetectGenderByName200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**probabilityMale** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




