

# InlineResponse20014

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | [**List&lt;InlineResponse20014Authors&gt;**](InlineResponse20014Authors.md) |  |  [optional]




