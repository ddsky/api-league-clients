

# FindSimilarBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**List&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;**](SearchBooksAPI200ResponseBooksInnerInner.md) |  |  [optional]




