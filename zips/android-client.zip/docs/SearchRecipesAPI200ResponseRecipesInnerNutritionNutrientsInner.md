

# SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**unit** | **String** |  |  [optional]




