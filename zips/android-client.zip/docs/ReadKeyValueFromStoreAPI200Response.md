

# ReadKeyValueFromStoreAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **String** |  |  [optional]




