

# InlineResponse20015

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**List&lt;InlineResponse20015Results&gt;**](InlineResponse20015Results.md) |  |  [optional]




