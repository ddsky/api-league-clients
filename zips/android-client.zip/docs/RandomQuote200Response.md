

# RandomQuote200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **String** |  |  [optional]
**quote** | **String** |  |  [optional]




