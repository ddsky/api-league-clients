

# RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Integer** |  |  [optional]
**ingredients** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | [**List&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**step** | **String** |  |  [optional]




