

# InlineResponse20021

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**List&lt;InlineResponse20021Dates&gt;**](InlineResponse20021Dates.md) |  |  [optional]




