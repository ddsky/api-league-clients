

# InlineResponse20025

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  |  [optional]
**singular** | **String** |  |  [optional]




