

# SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **String** |  |  [optional]
**country** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**latitude** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lon** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**streetAddr2** | **String** |  |  [optional]
**state** | **String** |  |  [optional]
**streetAddr** | **String** |  |  [optional]
**lat** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**longitude** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




