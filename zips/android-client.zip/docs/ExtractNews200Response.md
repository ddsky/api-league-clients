

# ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**publishDate** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
**sourceCountry** | **String** |  |  [optional]
**sentiment** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




