

# InlineResponse200Books

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]




