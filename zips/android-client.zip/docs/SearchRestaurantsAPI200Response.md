

# SearchRestaurantsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**List&lt;SearchRestaurantsAPI200ResponseRestaurantsInner&gt;**](SearchRestaurantsAPI200ResponseRestaurantsInner.md) |  |  [optional]




