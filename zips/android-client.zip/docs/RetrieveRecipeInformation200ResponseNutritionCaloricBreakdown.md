

# RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentFat** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**percentCarbs** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**percentProtein** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




