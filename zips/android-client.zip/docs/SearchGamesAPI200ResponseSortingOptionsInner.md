

# SearchGamesAPI200ResponseSortingOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**key** | **String** |  |  [optional]
**sort** | **String** |  |  [optional]




