

# InlineResponse20019ReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **Integer** |  |  [optional]
**forcast** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**flesch** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**smog** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**ari** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lix** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**colemanLiau** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**kincaid** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**fog** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




