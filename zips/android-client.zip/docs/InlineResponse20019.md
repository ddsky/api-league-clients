

# InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfWords** | **Integer** |  |  [optional]
**numberOfSentences** | **Integer** |  |  [optional]
**readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  |  [optional]
**skimmability** | [**InlineResponse20019Skimmability**](InlineResponse20019Skimmability.md) |  |  [optional]
**interestingness** | [**InlineResponse20019Interestingness**](InlineResponse20019Interestingness.md) |  |  [optional]
**style** | [**InlineResponse20019Style**](InlineResponse20019Style.md) |  |  [optional]
**totalScore** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




