

# SearchJokesAPI200ResponseJokesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joke** | **String** |  |  [optional]




