

# SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **String** |  |  [optional]
**image** | **String** |  |  [optional]
**sentiment** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**sourceCountry** | **String** |  |  [optional]
**language** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**text** | **String** |  |  [optional]
**video** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**publishDate** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**authors** | **List&lt;String&gt;** |  |  [optional]




