

# InlineResponse20020Dates

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Integer** |  |  [optional]
**date** | **String** |  |  [optional]
**normalizedDate** | [**ModelNull**](ModelNull.md) |  |  [optional]
**tag** | **String** |  |  [optional]
**endPosition** | **Integer** |  |  [optional]




