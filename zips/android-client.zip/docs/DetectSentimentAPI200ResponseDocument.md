

# DetectSentimentAPI200ResponseDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | **String** |  |  [optional]
**confidence** | **Integer** |  |  [optional]
**averageConfidence** | **Integer** |  |  [optional]




