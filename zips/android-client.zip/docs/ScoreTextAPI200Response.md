

# ScoreTextAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfWords** | **Integer** |  |  [optional]
**numberOfSentences** | **Integer** |  |  [optional]
**readability** | [**ScoreTextAPI200ResponseReadability**](ScoreTextAPI200ResponseReadability.md) |  |  [optional]
**skimmability** | [**ScoreTextAPI200ResponseSkimmability**](ScoreTextAPI200ResponseSkimmability.md) |  |  [optional]
**interestingness** | [**ScoreTextAPI200ResponseInterestingness**](ScoreTextAPI200ResponseInterestingness.md) |  |  [optional]
**style** | [**ScoreTextAPI200ResponseStyle**](ScoreTextAPI200ResponseStyle.md) |  |  [optional]
**totalScore** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




