

# ExtractEntities200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**List&lt;ExtractEntities200ResponseEntitiesInner&gt;**](ExtractEntities200ResponseEntitiesInner.md) |  |  [optional]




