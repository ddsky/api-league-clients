

# RetrieveRecipeInformation200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**spiciness** | **Integer** |  |  [optional]
**saltiness** | **Integer** |  |  [optional]
**bitterness** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**savoriness** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**sweetness** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**sourness** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




