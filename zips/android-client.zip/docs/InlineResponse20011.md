

# InlineResponse20011

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**author** | **String** |  |  [optional]
**poem** | **String** |  |  [optional]




