

# VectorSearchAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vectors** | [**List&lt;VectorSearchAPI200ResponseVectorsInner&gt;**](VectorSearchAPI200ResponseVectorsInner.md) |  |  [optional]




