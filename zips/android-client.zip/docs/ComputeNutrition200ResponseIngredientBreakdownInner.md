

# ComputeNutrition200ResponseIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**amount** | **Integer** |  |  [optional]
**unit** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**nutrients** | [**List&lt;ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner&gt;**](ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner.md) |  |  [optional]




