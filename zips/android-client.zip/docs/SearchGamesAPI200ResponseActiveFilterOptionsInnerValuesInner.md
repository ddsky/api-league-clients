

# SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match** | **String** |  |  [optional]
**value** | **String** |  |  [optional]




