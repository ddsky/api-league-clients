

# InlineResponse2007

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**List&lt;InlineResponse2007Images&gt;**](InlineResponse2007Images.md) |  |  [optional]




