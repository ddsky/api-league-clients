

# SearchDrinksAPI200ResponseDrinksInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  |  [optional]
**nameClean** | **String** |  |  [optional]
**amount** | **Integer** |  |  [optional]
**unit** | **String** |  |  [optional]
**measures** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.md) |  |  [optional]
**original** | **String** |  |  [optional]
**meta** | **List&lt;String&gt;** |  |  [optional]
**originalName** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**aisle** | **String** |  |  [optional]
**consistency** | **String** |  |  [optional]




