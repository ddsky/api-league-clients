

# SearchGifs200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**List&lt;SearchGifs200ResponseImagesInner&gt;**](SearchGifs200ResponseImagesInner.md) |  |  [optional]




