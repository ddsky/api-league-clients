

# FindSimilarBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**List&lt;SearchBooks200ResponseBooksInner&gt;**](SearchBooks200ResponseBooksInner.md) |  |  [optional]




