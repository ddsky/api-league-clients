

# ScoreReadability200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | [**ScoreText200ResponseReadability**](ScoreText200ResponseReadability.md) |  |  [optional]




