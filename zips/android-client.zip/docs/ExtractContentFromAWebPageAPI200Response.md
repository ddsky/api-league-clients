

# ExtractContentFromAWebPageAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**mainText** | **String** |  |  [optional]
**mainHtml** | **String** |  |  [optional]
**images** | **List&lt;String&gt;** |  |  [optional]




