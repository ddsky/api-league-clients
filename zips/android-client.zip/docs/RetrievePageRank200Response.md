

# RetrievePageRank200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pageRank** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**position** | **Integer** |  |  [optional]
**percentile** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




