

# InlineResponse20019Style

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20019ReadabilityMainscores**](InlineResponse20019ReadabilityMainscores.md) |  |  [optional]
**subscores** | [**InlineResponse20019StyleSubscores**](InlineResponse20019StyleSubscores.md) |  |  [optional]




