

# InlineResponse20029

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**specificColor** | **String** |  |  [optional]
**mainColor** | **String** |  |  [optional]
**hexCode** | **String** |  |  [optional]




