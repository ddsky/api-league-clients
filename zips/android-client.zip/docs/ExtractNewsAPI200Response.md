

# ExtractNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**images** | [**List&lt;ExtractNewsAPI200ResponseImagesInner&gt;**](ExtractNewsAPI200ResponseImagesInner.md) |  |  [optional]
**videos** | [**List&lt;ExtractNewsAPI200ResponseVideosInner&gt;**](ExtractNewsAPI200ResponseVideosInner.md) |  |  [optional]
**publishDate** | **String** |  |  [optional]
**authors** | **List&lt;String&gt;** |  |  [optional]
**language** | **String** |  |  [optional]




