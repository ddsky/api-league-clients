

# RetrieveRecipeInformationAPI200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**steps** | [**List&lt;RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner.md) |  |  [optional]




