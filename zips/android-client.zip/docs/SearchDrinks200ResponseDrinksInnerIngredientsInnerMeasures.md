

# SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  |  [optional]
**us** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs.md) |  |  [optional]




