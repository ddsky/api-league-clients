

# ComputeNutritionAPI200ResponseIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**amount** | **Integer** |  |  [optional]
**unit** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**nutrients** | [**List&lt;ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner&gt;**](ComputeNutritionAPI200ResponseIngredientBreakdownInnerNutrientsInner.md) |  |  [optional]




