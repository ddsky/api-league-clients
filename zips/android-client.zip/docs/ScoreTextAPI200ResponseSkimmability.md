

# ScoreTextAPI200ResponseSkimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**ScoreTextAPI200ResponseSkimmabilityMainscores**](ScoreTextAPI200ResponseSkimmabilityMainscores.md) |  |  [optional]
**subscores** | [**ScoreTextAPI200ResponseSkimmabilitySubscores**](ScoreTextAPI200ResponseSkimmabilitySubscores.md) |  |  [optional]




