

# SearchGamesAPI200ResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**filterType** | **String** |  |  [optional]
**key** | **String** |  |  [optional]
**values** | [**List&lt;SearchGamesAPI200ResponseFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  |  [optional]
**filterConnection** | **String** |  |  [optional]




