

# SearchWeb200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**List&lt;SearchWeb200ResponseResultsInner&gt;**](SearchWeb200ResponseResultsInner.md) |  |  [optional]




