

# SearchMemesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**List&lt;SearchMemesAPI200ResponseMemesInner&gt;**](SearchMemesAPI200ResponseMemesInner.md) |  |  [optional]
**available** | **Integer** |  |  [optional]




