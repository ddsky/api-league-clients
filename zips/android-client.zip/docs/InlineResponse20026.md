

# InlineResponse20026

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  |  [optional]
**plural** | **String** |  |  [optional]




