

# RetrieveGameById200ResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **String** |  |  [optional]
**discountPercent** | **Integer** |  |  [optional]
**value** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**initial** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




