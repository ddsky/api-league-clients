

# ListWordSynonyms200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synonyms** | **List&lt;String&gt;** |  |  [optional]




