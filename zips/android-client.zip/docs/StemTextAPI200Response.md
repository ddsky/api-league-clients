

# StemTextAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  |  [optional]
**stemmed** | **String** |  |  [optional]




