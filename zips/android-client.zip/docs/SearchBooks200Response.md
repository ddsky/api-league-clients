

# SearchBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**books** | [**List&lt;SearchBooks200ResponseBooksInner&gt;**](SearchBooks200ResponseBooksInner.md) |  |  [optional]




