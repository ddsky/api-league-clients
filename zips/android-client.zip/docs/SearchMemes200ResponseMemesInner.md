

# SearchMemes200ResponseMemesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**url** | **String** |  |  [optional]




