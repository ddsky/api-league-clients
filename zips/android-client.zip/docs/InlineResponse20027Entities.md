

# InlineResponse20027Entities

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Integer** |  |  [optional]
**image** | **String** |  |  [optional]
**type** | **String** |  |  [optional]
**value** | **String** |  |  [optional]
**endPosition** | **Integer** |  |  [optional]




