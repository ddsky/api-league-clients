

# InlineResponse20030

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**targetAmount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**targetUnit** | **String** |  |  [optional]




