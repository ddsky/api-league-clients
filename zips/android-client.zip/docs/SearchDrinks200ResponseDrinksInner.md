

# SearchDrinks200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **List&lt;String&gt;** |  |  [optional]
**instructions** | [**List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInner.md) |  |  [optional]
**images** | **List&lt;String&gt;** |  |  [optional]
**nutrition** | [**SearchDrinks200ResponseDrinksInnerNutrition**](SearchDrinks200ResponseDrinksInnerNutrition.md) |  |  [optional]
**glassType** | **String** |  |  [optional]
**credits** | [**SearchDrinks200ResponseDrinksInnerCredits**](SearchDrinks200ResponseDrinksInnerCredits.md) |  |  [optional]
**pricePerServing** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**description** | **String** |  |  [optional]
**ingredients** | [**List&lt;SearchDrinks200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerIngredientsInner.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**cuisines** | **List&lt;String&gt;** |  |  [optional]




