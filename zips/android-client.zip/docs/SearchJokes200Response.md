

# SearchJokes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**List&lt;SearchJokes200ResponseJokesInner&gt;**](SearchJokes200ResponseJokesInner.md) |  |  [optional]
**available** | **Integer** |  |  [optional]




