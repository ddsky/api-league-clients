

# SearchBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalResults** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**books** | [**List&lt;List&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;&gt;**](List.md) |  |  [optional]




