

# SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Integer** |  |  [optional]
**ingredients** | [**List&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | **List&lt;String&gt;** |  |  [optional]
**step** | **String** |  |  [optional]




