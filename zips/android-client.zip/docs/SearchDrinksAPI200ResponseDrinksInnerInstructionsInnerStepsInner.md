

# SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Integer** |  |  [optional]
**ingredients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional]
**equipment** | **List&lt;String&gt;** |  |  [optional]
**step** | **String** |  |  [optional]




