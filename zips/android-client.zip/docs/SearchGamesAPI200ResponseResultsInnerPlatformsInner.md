

# SearchGamesAPI200ResponseResultsInnerPlatformsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**value** | **String** |  |  [optional]




