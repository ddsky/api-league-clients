

# InlineResponse20017

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** |  |  [optional]
**confidence** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




