

# RetrieveGameById200ResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Integer** |  |  [optional]
**countCritics** | **Integer** |  |  [optional]
**meanPlayers** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**meanCritics** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**mean** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**countPlayers** | **Integer** |  |  [optional]




