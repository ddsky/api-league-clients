

# SearchDrinksAPI200ResponseDrinksInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weightPerServing** | [**SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing.md) |  |  [optional]
**caloricBreakdown** | [**SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  |  [optional]
**flavonoids** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional]
**ingredientBreakdown** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  |  [optional]
**properties** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional]
**nutrients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional]




