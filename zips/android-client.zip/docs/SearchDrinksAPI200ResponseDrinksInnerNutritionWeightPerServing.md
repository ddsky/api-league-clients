

# SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Integer** |  |  [optional]
**unit** | **String** |  |  [optional]




