

# RetrieveRecipeInformationAPI200ResponseScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metaScore** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**weightWatcherSmartPoints** | **Integer** |  |  [optional]
**healthScore** | **Integer** |  |  [optional]




