

# SearchGamesAPI200ResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  |  [optional]
**connection** | **String** |  |  [optional]
**values** | [**List&lt;SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.md) |  |  [optional]




