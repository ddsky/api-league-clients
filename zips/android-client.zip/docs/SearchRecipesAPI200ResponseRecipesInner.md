

# SearchRecipesAPI200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **List&lt;String&gt;** |  |  [optional]
**nutrition** | [**SearchRecipesAPI200ResponseRecipesInnerNutrition**](SearchRecipesAPI200ResponseRecipesInnerNutrition.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]




