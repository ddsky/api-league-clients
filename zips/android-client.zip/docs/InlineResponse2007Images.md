

# InlineResponse2007Images

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Integer** |  |  [optional]
**url** | **String** |  |  [optional]
**height** | **Integer** |  |  [optional]




