

# InlineResponse2006

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**type** | **String** |  |  [optional]
**width** | **Integer** |  |  [optional]
**height** | **Integer** |  |  [optional]
**ratio** | [**BigDecimal**](BigDecimal.md) |  |  [optional]




