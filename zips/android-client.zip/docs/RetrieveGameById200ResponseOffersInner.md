

# RetrieveGameById200ResponseOffersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storeName** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**price** | [**RetrieveGameById200ResponseOffersInnerPrice**](RetrieveGameById200ResponseOffersInnerPrice.md) |  |  [optional]
**platform** | **String** |  |  [optional]
**url** | **String** |  |  [optional]




