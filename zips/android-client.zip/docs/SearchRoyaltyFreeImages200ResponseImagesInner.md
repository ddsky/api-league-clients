

# SearchRoyaltyFreeImages200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Integer** |  |  [optional]
**license** | [**SearchRoyaltyFreeImages200ResponseImagesInnerLicense**](SearchRoyaltyFreeImages200ResponseImagesInnerLicense.md) |  |  [optional]
**thumbnail** | **String** |  |  [optional]
**id** | **String** |  |  [optional]
**url** | **String** |  |  [optional]
**height** | **Integer** |  |  [optional]




