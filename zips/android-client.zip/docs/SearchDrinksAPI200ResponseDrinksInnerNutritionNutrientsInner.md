

# SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**percentOfDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**unit** | **String** |  |  [optional]




