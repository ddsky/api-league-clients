

# ExtractDatesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**List&lt;ExtractDatesAPI200ResponseDatesInner&gt;**](ExtractDatesAPI200ResponseDatesInner.md) |  |  [optional]




