

# SearchDrinksAPI200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **List&lt;String&gt;** |  |  [optional]
**instructions** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.md) |  |  [optional]
**images** | **List&lt;String&gt;** |  |  [optional]
**nutrition** | [**SearchDrinksAPI200ResponseDrinksInnerNutrition**](SearchDrinksAPI200ResponseDrinksInnerNutrition.md) |  |  [optional]
**glassType** | **String** |  |  [optional]
**credits** | [**SearchDrinksAPI200ResponseDrinksInnerCredits**](SearchDrinksAPI200ResponseDrinksInnerCredits.md) |  |  [optional]
**pricePerServing** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**description** | **String** |  |  [optional]
**ingredients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInner.md) |  |  [optional]
**id** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**cuisines** | **List&lt;String&gt;** |  |  [optional]




