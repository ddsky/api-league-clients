# android-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>com.apileague</groupId>
    <artifactId>android-client</artifactId>
    <version>1.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "com.apileague:android-client:1.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

- target/android-client-1.0.jar
- target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import com.apileague.ArtApi;

public class ArtApiExample {

    public static void main(String[] args) {
        ArtApi apiInstance = new ArtApi();
        String url = https://upload.wikimedia.org/wikipedia/commons/3/35/Basic_human_drawing.png; // String | The URL to the image.
        Integer width = 200; // Integer | The maximum width of the image (default 400, max. 500).
        Integer height = 200; // Integer | The maximum height of the image (default 400, max. 500).
        try {
            String result = apiInstance.imageToAsciiArtByURL(url, width, height);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling ArtApi#imageToAsciiArtByURL");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://api.apileague.com*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*ArtApi* | [**imageToAsciiArtByURL**](docs/ArtApi.md#imageToAsciiArtByURL) | **GET** /convert-image-to-ascii-txt | Image to Ascii Art by URL
*ArtApi* | [**randomPoem**](docs/ArtApi.md#randomPoem) | **GET** /retrieve-random-poem | Random Poem
*BooksApi* | [**findSimilarBooks**](docs/BooksApi.md#findSimilarBooks) | **GET** /list-similar-books | Find Similar Books
*BooksApi* | [**searchBooks**](docs/BooksApi.md#searchBooks) | **GET** /search-books | Search Books
*HumorApi* | [**generateNonsenseWord**](docs/HumorApi.md#generateNonsenseWord) | **GET** /generate-nonsense-word | Generate Nonsense Word
*HumorApi* | [**randomJoke**](docs/HumorApi.md#randomJoke) | **GET** /retrieve-random-joke | Random Joke
*HumorApi* | [**randomMeme**](docs/HumorApi.md#randomMeme) | **GET** /retrieve-random-meme | Random Meme
*HumorApi* | [**searchGifs**](docs/HumorApi.md#searchGifs) | **GET** /search-gifs | Search Gifs
*HumorApi* | [**searchJokes**](docs/HumorApi.md#searchJokes) | **GET** /search-jokes | Search Jokes
*HumorApi* | [**searchMemes**](docs/HumorApi.md#searchMemes) | **GET** /search-memes | Search Memes
*KnowledgeApi* | [**randomQuote**](docs/KnowledgeApi.md#randomQuote) | **GET** /retrieve-random-quote | Random Quote
*KnowledgeApi* | [**randomTrivia**](docs/KnowledgeApi.md#randomTrivia) | **GET** /retrieve-random-trivia | Random Trivia
*MathApi* | [**convertUnits**](docs/MathApi.md#convertUnits) | **GET** /convert-units | Convert Units
*MediaApi* | [**detectMainImageColor**](docs/MediaApi.md#detectMainImageColor) | **GET** /detect-color | Detect Main Image Color
*MediaApi* | [**rescaleImage**](docs/MediaApi.md#rescaleImage) | **GET** /rescale-image | Rescale Image
*MediaApi* | [**searchRoyaltyFreeImages**](docs/MediaApi.md#searchRoyaltyFreeImages) | **GET** /search-images | Search Royalty Free Images
*NewsApi* | [**extractNews**](docs/NewsApi.md#extractNews) | **GET** /extract-news | Extract News
*NewsApi* | [**searchNews**](docs/NewsApi.md#searchNews) | **GET** /search-news | Search News
*StorageApi* | [**readKeyValueFromStore**](docs/StorageApi.md#readKeyValueFromStore) | **GET** /read-key-value | Read Key Value from Store
*StorageApi* | [**storeKeyValueGET**](docs/StorageApi.md#storeKeyValueGET) | **GET** /store-key-value | Store Key Value (GET)
*TextApi* | [**correctSpelling**](docs/TextApi.md#correctSpelling) | **GET** /correct-spelling | Correct Spelling
*TextApi* | [**detectLanguage**](docs/TextApi.md#detectLanguage) | **GET** /detect-language | Detect Language
*TextApi* | [**detectSentiment**](docs/TextApi.md#detectSentiment) | **GET** /detect-sentiment | Detect Sentiment
*TextApi* | [**extractDates**](docs/TextApi.md#extractDates) | **GET** /extract-dates | Extract Dates
*TextApi* | [**extractEntities**](docs/TextApi.md#extractEntities) | **GET** /extract-entities | Extract Entities
*TextApi* | [**listWordSynonyms**](docs/TextApi.md#listWordSynonyms) | **GET** /list-synonyms | List Word Synonyms
*TextApi* | [**partOfSpeechTagging**](docs/TextApi.md#partOfSpeechTagging) | **GET** /tag-pos | Part of Speech Tagging
*TextApi* | [**pluralizeWord**](docs/TextApi.md#pluralizeWord) | **GET** /pluralize-word | Pluralize Word
*TextApi* | [**scoreReadability**](docs/TextApi.md#scoreReadability) | **GET** /score-readability | Score Readability
*TextApi* | [**scoreText**](docs/TextApi.md#scoreText) | **GET** /score-text | Score Text
*TextApi* | [**singularizeWord**](docs/TextApi.md#singularizeWord) | **GET** /singularize-word | Singularize Word
*TextApi* | [**textStemming**](docs/TextApi.md#textStemming) | **GET** /stem-text | Text Stemming
*WebApi* | [**extractAuthors**](docs/WebApi.md#extractAuthors) | **GET** /extract-authors | Extract Authors
*WebApi* | [**extractContentFromAWebPage**](docs/WebApi.md#extractContentFromAWebPage) | **GET** /extract-content | Extract Content from a Web Page
*WebApi* | [**extractPublishDate**](docs/WebApi.md#extractPublishDate) | **GET** /extract-publish-date | Extract Publish Date
*WebApi* | [**searchWeb**](docs/WebApi.md#searchWeb) | **GET** /search-web | Search Web


## Documentation for Models

 - [InlineResponse200](docs/InlineResponse200.md)
 - [InlineResponse2001](docs/InlineResponse2001.md)
 - [InlineResponse20010](docs/InlineResponse20010.md)
 - [InlineResponse20011](docs/InlineResponse20011.md)
 - [InlineResponse20012](docs/InlineResponse20012.md)
 - [InlineResponse20013](docs/InlineResponse20013.md)
 - [InlineResponse20014](docs/InlineResponse20014.md)
 - [InlineResponse20014Authors](docs/InlineResponse20014Authors.md)
 - [InlineResponse20015](docs/InlineResponse20015.md)
 - [InlineResponse20015Results](docs/InlineResponse20015Results.md)
 - [InlineResponse20016](docs/InlineResponse20016.md)
 - [InlineResponse20017](docs/InlineResponse20017.md)
 - [InlineResponse20018](docs/InlineResponse20018.md)
 - [InlineResponse20018Document](docs/InlineResponse20018Document.md)
 - [InlineResponse20018Sentences](docs/InlineResponse20018Sentences.md)
 - [InlineResponse20019](docs/InlineResponse20019.md)
 - [InlineResponse20019Interestingness](docs/InlineResponse20019Interestingness.md)
 - [InlineResponse20019InterestingnessSubscores](docs/InlineResponse20019InterestingnessSubscores.md)
 - [InlineResponse20019Readability](docs/InlineResponse20019Readability.md)
 - [InlineResponse20019ReadabilityMainscores](docs/InlineResponse20019ReadabilityMainscores.md)
 - [InlineResponse20019ReadabilitySubscores](docs/InlineResponse20019ReadabilitySubscores.md)
 - [InlineResponse20019Skimmability](docs/InlineResponse20019Skimmability.md)
 - [InlineResponse20019SkimmabilityMainscores](docs/InlineResponse20019SkimmabilityMainscores.md)
 - [InlineResponse20019SkimmabilitySubscores](docs/InlineResponse20019SkimmabilitySubscores.md)
 - [InlineResponse20019Style](docs/InlineResponse20019Style.md)
 - [InlineResponse20019StyleSubscores](docs/InlineResponse20019StyleSubscores.md)
 - [InlineResponse2002](docs/InlineResponse2002.md)
 - [InlineResponse20020](docs/InlineResponse20020.md)
 - [InlineResponse20021](docs/InlineResponse20021.md)
 - [InlineResponse20021Dates](docs/InlineResponse20021Dates.md)
 - [InlineResponse20022](docs/InlineResponse20022.md)
 - [InlineResponse20023](docs/InlineResponse20023.md)
 - [InlineResponse20024](docs/InlineResponse20024.md)
 - [InlineResponse20025](docs/InlineResponse20025.md)
 - [InlineResponse20026](docs/InlineResponse20026.md)
 - [InlineResponse20027](docs/InlineResponse20027.md)
 - [InlineResponse20027Entities](docs/InlineResponse20027Entities.md)
 - [InlineResponse20028](docs/InlineResponse20028.md)
 - [InlineResponse20028Images](docs/InlineResponse20028Images.md)
 - [InlineResponse20028License](docs/InlineResponse20028License.md)
 - [InlineResponse20029](docs/InlineResponse20029.md)
 - [InlineResponse2002News](docs/InlineResponse2002News.md)
 - [InlineResponse2003](docs/InlineResponse2003.md)
 - [InlineResponse20030](docs/InlineResponse20030.md)
 - [InlineResponse20031](docs/InlineResponse20031.md)
 - [InlineResponse20032](docs/InlineResponse20032.md)
 - [InlineResponse2004](docs/InlineResponse2004.md)
 - [InlineResponse2004Jokes](docs/InlineResponse2004Jokes.md)
 - [InlineResponse2005](docs/InlineResponse2005.md)
 - [InlineResponse2005Memes](docs/InlineResponse2005Memes.md)
 - [InlineResponse2006](docs/InlineResponse2006.md)
 - [InlineResponse2007](docs/InlineResponse2007.md)
 - [InlineResponse2007Images](docs/InlineResponse2007Images.md)
 - [InlineResponse2008](docs/InlineResponse2008.md)
 - [InlineResponse2009](docs/InlineResponse2009.md)
 - [InlineResponse200Books](docs/InlineResponse200Books.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### apiKey

- **Type**: API key

- **API key parameter name**: api-key
- **Location**: URL query string

### headerApiKey

- **Type**: API key

- **API key parameter name**: x-api-key
- **Location**: HTTP header


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author

mail@apileague.com

