# OpenapiClient::SearchDrinks200ResponseDrinksInnerInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **steps** | [**Array&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerInstructionsInner.new(
  name: null,
  steps: null
)
```

