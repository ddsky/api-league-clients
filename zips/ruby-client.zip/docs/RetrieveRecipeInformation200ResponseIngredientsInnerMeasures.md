# OpenapiClient::RetrieveRecipeInformation200ResponseIngredientsInnerMeasures

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **metric** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] |
| **us** | [**SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseIngredientsInnerMeasures.new(
  metric: null,
  us: null
)
```

