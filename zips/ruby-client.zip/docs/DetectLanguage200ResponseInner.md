# OpenapiClient::DetectLanguage200ResponseInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **language** | **String** |  | [optional] |
| **confidence** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::DetectLanguage200ResponseInner.new(
  language: null,
  confidence: null
)
```

