# OpenapiClient::SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **amount** | **Float** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.new(
  name: null,
  amount: null,
  unit: null
)
```

