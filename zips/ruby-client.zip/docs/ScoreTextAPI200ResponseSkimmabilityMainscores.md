# OpenapiClient::ScoreTextAPI200ResponseSkimmabilityMainscores

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_possible** | **Integer** |  | [optional] |
| **total** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ScoreTextAPI200ResponseSkimmabilityMainscores.new(
  total_possible: null,
  total: null
)
```

