# OpenapiClient::SearchWebAPI200ResponseResultsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** |  | [optional] |
| **summary** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchWebAPI200ResponseResultsInner.new(
  title: null,
  summary: null,
  url: null
)
```

