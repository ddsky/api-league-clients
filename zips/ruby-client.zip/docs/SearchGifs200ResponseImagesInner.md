# OpenapiClient::SearchGifs200ResponseImagesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **width** | **Integer** |  | [optional] |
| **url** | **String** |  | [optional] |
| **height** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGifs200ResponseImagesInner.new(
  width: null,
  url: null,
  height: null
)
```

