# OpenapiClient::SearchRoyaltyFreeImages200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;SearchRoyaltyFreeImages200ResponseImagesInner&gt;**](SearchRoyaltyFreeImages200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRoyaltyFreeImages200Response.new(
  images: null
)
```

