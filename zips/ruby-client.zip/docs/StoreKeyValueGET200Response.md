# OpenapiClient::StoreKeyValueGET200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **status** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::StoreKeyValueGET200Response.new(
  status: null
)
```

