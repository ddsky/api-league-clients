# OpenapiClient::InlineResponse2005Memes

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **type** | **String** |  | [optional] |
| **description** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2005Memes.new(
  type: null,
  description: null,
  url: null
)
```

