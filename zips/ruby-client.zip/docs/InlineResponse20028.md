# OpenapiClient::InlineResponse20028

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;InlineResponse20028Images&gt;**](InlineResponse20028Images.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20028.new(
  images: null
)
```

