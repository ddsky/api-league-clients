# OpenapiClient::InlineResponse20011

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **title** | **String** |  | [optional] |
| **author** | **String** |  | [optional] |
| **poem** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20011.new(
  title: null,
  author: null,
  poem: null
)
```

