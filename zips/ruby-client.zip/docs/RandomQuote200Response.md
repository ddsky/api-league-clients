# OpenapiClient::RandomQuote200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **author** | **String** |  | [optional] |
| **quote** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RandomQuote200Response.new(
  author: null,
  quote: null
)
```

