# OpenapiClient::ScoreTextAPI200ResponseReadabilityMainscores

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_possible** | **Integer** |  | [optional] |
| **total** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ScoreTextAPI200ResponseReadabilityMainscores.new(
  total_possible: null,
  total: null
)
```

