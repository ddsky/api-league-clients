# OpenapiClient::ExtractPublishDateAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **publish_date** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractPublishDateAPI200Response.new(
  publish_date: null
)
```

