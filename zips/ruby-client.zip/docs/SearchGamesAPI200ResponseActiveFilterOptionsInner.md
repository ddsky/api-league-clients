# OpenapiClient::SearchGamesAPI200ResponseActiveFilterOptionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **key** | **String** |  | [optional] |
| **connection** | **String** |  | [optional] |
| **values** | [**Array&lt;SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseActiveFilterOptionsInner.new(
  key: null,
  connection: null,
  values: null
)
```

