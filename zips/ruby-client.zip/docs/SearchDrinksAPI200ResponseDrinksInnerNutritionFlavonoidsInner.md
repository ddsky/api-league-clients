# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **amount** | **Integer** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner.new(
  name: null,
  amount: null,
  unit: null
)
```

