# OpenapiClient::InlineResponse20027

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **entities** | [**Array&lt;InlineResponse20027Entities&gt;**](InlineResponse20027Entities.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20027.new(
  entities: null
)
```

