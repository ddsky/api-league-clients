# OpenapiClient::SearchRestaurantsAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **restaurants** | [**Array&lt;SearchRestaurantsAPI200ResponseRestaurantsInner&gt;**](SearchRestaurantsAPI200ResponseRestaurantsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurantsAPI200Response.new(
  restaurants: null
)
```

