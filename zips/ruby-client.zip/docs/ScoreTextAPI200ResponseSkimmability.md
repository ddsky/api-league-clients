# OpenapiClient::ScoreTextAPI200ResponseSkimmability

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **mainscores** | [**ScoreTextAPI200ResponseSkimmabilityMainscores**](ScoreTextAPI200ResponseSkimmabilityMainscores.md) |  | [optional] |
| **subscores** | [**ScoreTextAPI200ResponseSkimmabilitySubscores**](ScoreTextAPI200ResponseSkimmabilitySubscores.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ScoreTextAPI200ResponseSkimmability.new(
  mainscores: null,
  subscores: null
)
```

