# OpenapiClient::SearchJokesAPI200ResponseJokesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **joke** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchJokesAPI200ResponseJokesInner.new(
  joke: null
)
```

