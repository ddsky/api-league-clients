# OpenapiClient::VectorSearchAPI200ResponseVectorsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **license** | **String** |  | [optional] |
| **title** | **String** |  | [optional] |
| **author** | **String** |  | [optional] |
| **image_url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::VectorSearchAPI200ResponseVectorsInner.new(
  license: null,
  title: null,
  author: null,
  image_url: null
)
```

