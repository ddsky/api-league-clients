# OpenapiClient::FindSimilarBooks200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **similar_books** | [**Array&lt;SearchBooks200ResponseBooksInnerInner&gt;**](SearchBooks200ResponseBooksInnerInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FindSimilarBooks200Response.new(
  similar_books: null
)
```

