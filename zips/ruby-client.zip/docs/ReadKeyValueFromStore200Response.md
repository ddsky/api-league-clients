# OpenapiClient::ReadKeyValueFromStore200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **value** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ReadKeyValueFromStore200Response.new(
  value: null
)
```

