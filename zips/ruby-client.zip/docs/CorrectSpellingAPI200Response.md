# OpenapiClient::CorrectSpellingAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **corrected_text** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CorrectSpellingAPI200Response.new(
  corrected_text: null
)
```

