# OpenapiClient::SearchGamesAPI200ResponseResultsInnerRating

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **count** | **Integer** |  | [optional] |
| **mean** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseResultsInnerRating.new(
  count: null,
  mean: null
)
```

