# OpenapiClient::ExtractPublishDate200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **publish_date** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractPublishDate200Response.new(
  publish_date: null
)
```

