# OpenapiClient::ExtractAuthors200ResponseAuthorsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **link** | **String** |  | [optional] |
| **name** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractAuthors200ResponseAuthorsInner.new(
  link: null,
  name: null
)
```

