# OpenapiClient::ExtractAuthors200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **authors** | [**Array&lt;ExtractAuthors200ResponseAuthorsInner&gt;**](ExtractAuthors200ResponseAuthorsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractAuthors200Response.new(
  authors: null
)
```

