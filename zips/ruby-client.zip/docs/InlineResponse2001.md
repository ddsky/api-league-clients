# OpenapiClient::InlineResponse2001

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **similar_books** | [**Array&lt;InlineResponse200Books&gt;**](InlineResponse200Books.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2001.new(
  similar_books: null
)
```

