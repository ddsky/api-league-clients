# OpenapiClient::SearchJokesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **jokes** | [**Array&lt;SearchJokesAPI200ResponseJokesInner&gt;**](SearchJokesAPI200ResponseJokesInner.md) |  | [optional] |
| **available** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchJokesAPI200Response.new(
  jokes: null,
  available: null
)
```

