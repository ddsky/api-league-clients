# OpenapiClient::RetrieveRecipeInformationAPI200ResponseInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **steps** | [**Array&lt;RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformationAPI200ResponseInstructionsInner.new(
  name: null,
  steps: null
)
```

