# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Integer** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing.new(
  amount: null,
  unit: null
)
```

