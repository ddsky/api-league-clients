# OpenapiClient::ListWordSynonymsAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **synonyms** | **Array&lt;String&gt;** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ListWordSynonymsAPI200Response.new(
  synonyms: null
)
```

