# OpenapiClient::InlineResponse20022

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **synonyms** | **Array&lt;String&gt;** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20022.new(
  synonyms: null
)
```

