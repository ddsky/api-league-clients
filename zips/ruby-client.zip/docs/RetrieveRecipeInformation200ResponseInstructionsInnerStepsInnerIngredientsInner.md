# OpenapiClient::RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **image** | **String** |  | [optional] |
| **id** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.new(
  name: null,
  image: null,
  id: null
)
```

