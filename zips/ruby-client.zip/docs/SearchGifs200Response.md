# OpenapiClient::SearchGifs200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;SearchGifs200ResponseImagesInner&gt;**](SearchGifs200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGifs200Response.new(
  images: null
)
```

