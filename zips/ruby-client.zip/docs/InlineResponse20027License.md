# OpenapiClient::InlineResponse20027License

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **link** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20027License.new(
  name: null,
  link: null
)
```

