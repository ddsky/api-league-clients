# OpenapiClient::InlineResponse20017Document

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **sentiment** | **String** |  | [optional] |
| **confidence** | **Integer** |  | [optional] |
| **average_confidence** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20017Document.new(
  sentiment: null,
  confidence: null,
  average_confidence: null
)
```

