# OpenapiClient::SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **operational** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **delivery** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **pickup** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |
| **dine_in** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours.new(
  operational: null,
  delivery: null,
  pickup: null,
  dine_in: null
)
```

