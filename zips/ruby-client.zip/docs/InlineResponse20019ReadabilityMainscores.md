# OpenapiClient::InlineResponse20019ReadabilityMainscores

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_possible** | **Integer** |  | [optional] |
| **total** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20019ReadabilityMainscores.new(
  total_possible: null,
  total: null
)
```

