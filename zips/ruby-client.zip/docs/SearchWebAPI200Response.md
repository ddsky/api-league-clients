# OpenapiClient::SearchWebAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;SearchWebAPI200ResponseResultsInner&gt;**](SearchWebAPI200ResponseResultsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchWebAPI200Response.new(
  results: null
)
```

