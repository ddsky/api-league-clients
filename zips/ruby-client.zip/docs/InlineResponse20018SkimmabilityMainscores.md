# OpenapiClient::InlineResponse20018SkimmabilityMainscores

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_possible** | **Integer** |  | [optional] |
| **total** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20018SkimmabilityMainscores.new(
  total_possible: null,
  total: null
)
```

