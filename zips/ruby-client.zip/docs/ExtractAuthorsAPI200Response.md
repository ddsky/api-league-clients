# OpenapiClient::ExtractAuthorsAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **authors** | [**Array&lt;ExtractAuthorsAPI200ResponseAuthorsInner&gt;**](ExtractAuthorsAPI200ResponseAuthorsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractAuthorsAPI200Response.new(
  authors: null
)
```

