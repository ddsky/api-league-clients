# OpenapiClient::SearchJokes200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **jokes** | [**Array&lt;SearchJokes200ResponseJokesInner&gt;**](SearchJokes200ResponseJokesInner.md) |  | [optional] |
| **available** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchJokes200Response.new(
  jokes: null,
  available: null
)
```

