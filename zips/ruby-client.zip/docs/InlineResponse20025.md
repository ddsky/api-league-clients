# OpenapiClient::InlineResponse20025

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **singular** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20025.new(
  original: null,
  singular: null
)
```

