# OpenapiClient::InlineResponse20026

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **plural** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20026.new(
  original: null,
  plural: null
)
```

