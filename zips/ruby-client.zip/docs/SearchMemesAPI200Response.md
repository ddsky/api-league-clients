# OpenapiClient::SearchMemesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **memes** | [**Array&lt;SearchMemesAPI200ResponseMemesInner&gt;**](SearchMemesAPI200ResponseMemesInner.md) |  | [optional] |
| **available** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchMemesAPI200Response.new(
  memes: null,
  available: null
)
```

