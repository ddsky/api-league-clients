# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **steps** | [**Array&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.new(
  name: null,
  steps: null
)
```

