# OpenapiClient::SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **match** | **String** |  | [optional] |
| **value** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.new(
  match: null,
  value: null
)
```

