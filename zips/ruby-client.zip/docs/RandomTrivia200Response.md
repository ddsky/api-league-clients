# OpenapiClient::RandomTrivia200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **trivia** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RandomTrivia200Response.new(
  trivia: null
)
```

