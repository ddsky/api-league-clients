# OpenapiClient::RetrieveGameById200ResponseOfficialStoresInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **url** | **String** |  | [optional] |
| **source** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveGameById200ResponseOfficialStoresInner.new(
  url: null,
  source: null
)
```

