# OpenapiClient::PartOfSpeechTagging200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **tagged_text** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PartOfSpeechTagging200Response.new(
  tagged_text: null
)
```

