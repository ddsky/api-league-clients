# OpenapiClient::FindSimilarGamesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;FindSimilarGamesAPI200ResponseResultsInner&gt;**](FindSimilarGamesAPI200ResponseResultsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FindSimilarGamesAPI200Response.new(
  results: null
)
```

