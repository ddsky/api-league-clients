# OpenapiClient::SearchGamesAPI200ResponseSortingOptionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **key** | **String** |  | [optional] |
| **sort** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseSortingOptionsInner.new(
  name: null,
  key: null,
  sort: null
)
```

