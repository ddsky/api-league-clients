# OpenapiClient::SearchGifsAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;SearchGifsAPI200ResponseImagesInner&gt;**](SearchGifsAPI200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGifsAPI200Response.new(
  images: null
)
```

