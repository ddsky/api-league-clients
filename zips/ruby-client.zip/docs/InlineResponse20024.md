# OpenapiClient::InlineResponse20024

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **stemmed** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20024.new(
  original: null,
  stemmed: null
)
```

