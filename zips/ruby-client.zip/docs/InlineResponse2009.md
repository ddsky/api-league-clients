# OpenapiClient::InlineResponse2009

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **trivia** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2009.new(
  trivia: null
)
```

