# OpenapiClient::RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **percent_of_daily_needs** | **Float** |  | [optional] |
| **amount** | **Float** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.new(
  name: null,
  percent_of_daily_needs: null,
  amount: null,
  unit: null
)
```

