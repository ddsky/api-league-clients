# OpenapiClient::InlineResponse20014

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **authors** | [**Array&lt;InlineResponse20014Authors&gt;**](InlineResponse20014Authors.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20014.new(
  authors: null
)
```

