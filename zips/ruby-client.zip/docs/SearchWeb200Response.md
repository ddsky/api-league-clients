# OpenapiClient::SearchWeb200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;SearchWeb200ResponseResultsInner&gt;**](SearchWeb200ResponseResultsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchWeb200Response.new(
  results: null
)
```

