# OpenapiClient::SearchJokes200ResponseJokesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **joke** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchJokes200ResponseJokesInner.new(
  joke: null
)
```

