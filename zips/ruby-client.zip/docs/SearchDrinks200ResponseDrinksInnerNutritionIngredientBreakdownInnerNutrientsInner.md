# OpenapiClient::SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **percent_of_daily_needs** | **Float** |  | [optional] |
| **amount** | **Integer** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.new(
  name: null,
  percent_of_daily_needs: null,
  amount: null,
  unit: null
)
```

