# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **unit_short** | **String** |  | [optional] |
| **amount** | **Integer** |  | [optional] |
| **unit_long** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresUs.new(
  unit_short: null,
  amount: null,
  unit_long: null
)
```

