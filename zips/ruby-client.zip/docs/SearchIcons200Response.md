# OpenapiClient::SearchIcons200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **icons** | [**Array&lt;SearchRoyaltyFreeImages200ResponseImagesInner&gt;**](SearchRoyaltyFreeImages200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchIcons200Response.new(
  icons: null
)
```

