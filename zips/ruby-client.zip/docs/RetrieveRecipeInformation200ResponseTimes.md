# OpenapiClient::RetrieveRecipeInformation200ResponseTimes

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_minutes** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseTimes.new(
  total_minutes: null
)
```

