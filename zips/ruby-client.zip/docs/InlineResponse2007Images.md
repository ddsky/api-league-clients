# OpenapiClient::InlineResponse2007Images

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **width** | **Integer** |  | [optional] |
| **url** | **String** |  | [optional] |
| **height** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2007Images.new(
  width: null,
  url: null,
  height: null
)
```

