# OpenapiClient::VectorSearchAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **vectors** | [**Array&lt;VectorSearchAPI200ResponseVectorsInner&gt;**](VectorSearchAPI200ResponseVectorsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::VectorSearchAPI200Response.new(
  vectors: null
)
```

