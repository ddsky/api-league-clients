# OpenapiClient::ExtractDatesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **dates** | [**Array&lt;ExtractDatesAPI200ResponseDatesInner&gt;**](ExtractDatesAPI200ResponseDatesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractDatesAPI200Response.new(
  dates: null
)
```

