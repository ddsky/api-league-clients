# OpenapiClient::TopNewsAPI200ResponseTopNewsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **news** | [**Array&lt;TopNewsAPI200ResponseTopNewsInnerNewsInner&gt;**](TopNewsAPI200ResponseTopNewsInnerNewsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::TopNewsAPI200ResponseTopNewsInner.new(
  news: null
)
```

