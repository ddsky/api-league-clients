# OpenapiClient::PluralizeWordAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **plural** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::PluralizeWordAPI200Response.new(
  original: null,
  plural: null
)
```

