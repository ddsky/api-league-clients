# OpenapiClient::StemTextAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **stemmed** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::StemTextAPI200Response.new(
  original: null,
  stemmed: null
)
```

