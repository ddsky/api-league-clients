# OpenapiClient::InlineResponse20030

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **target_amount** | **Float** |  | [optional] |
| **target_unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20030.new(
  target_amount: null,
  target_unit: null
)
```

