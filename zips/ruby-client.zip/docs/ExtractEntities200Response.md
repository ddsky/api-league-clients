# OpenapiClient::ExtractEntities200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **entities** | [**Array&lt;ExtractEntities200ResponseEntitiesInner&gt;**](ExtractEntities200ResponseEntitiesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractEntities200Response.new(
  entities: null
)
```

