# OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **sunday** | **String** |  | [optional] |
| **saturday** | **String** |  | [optional] |
| **tuesday** | **String** |  | [optional] |
| **thursday** | **String** |  | [optional] |
| **friday** | **String** |  | [optional] |
| **wednesday** | **String** |  | [optional] |
| **monday** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRestaurants200ResponseRestaurantsInnerLocalHoursOperational.new(
  sunday: null,
  saturday: null,
  tuesday: null,
  thursday: null,
  friday: null,
  wednesday: null,
  monday: null
)
```

