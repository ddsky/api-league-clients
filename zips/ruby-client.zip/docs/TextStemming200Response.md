# OpenapiClient::TextStemming200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **stemmed** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::TextStemming200Response.new(
  original: null,
  stemmed: null
)
```

