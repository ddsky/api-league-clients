# OpenapiClient::InlineResponse20023

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **tagged_text** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20023.new(
  tagged_text: null
)
```

