# OpenapiClient::SearchRoyaltyFreeImagesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;SearchRoyaltyFreeImagesAPI200ResponseImagesInner&gt;**](SearchRoyaltyFreeImagesAPI200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRoyaltyFreeImagesAPI200Response.new(
  images: null
)
```

