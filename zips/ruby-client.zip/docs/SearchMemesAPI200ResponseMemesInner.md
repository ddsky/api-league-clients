# OpenapiClient::SearchMemesAPI200ResponseMemesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **type** | **String** |  | [optional] |
| **description** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchMemesAPI200ResponseMemesInner.new(
  type: null,
  description: null,
  url: null
)
```

