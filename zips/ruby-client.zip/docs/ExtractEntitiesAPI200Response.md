# OpenapiClient::ExtractEntitiesAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **entities** | [**Array&lt;ExtractEntitiesAPI200ResponseEntitiesInner&gt;**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractEntitiesAPI200Response.new(
  entities: null
)
```

