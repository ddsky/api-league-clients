# OpenapiClient::SearchIconsAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **icons** | [**Array&lt;SearchRoyaltyFreeImagesAPI200ResponseImagesInner&gt;**](SearchRoyaltyFreeImagesAPI200ResponseImagesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchIconsAPI200Response.new(
  icons: null
)
```

