# OpenapiClient::SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **number** | **Integer** |  | [optional] |
| **ingredients** | [**Array&lt;SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] |
| **equipment** | **Array&lt;String&gt;** |  | [optional] |
| **step** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner.new(
  number: null,
  ingredients: null,
  equipment: null,
  step: null
)
```

