# OpenapiClient::SearchGamesAPI200ResponseResultsInnerPlatformsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **value** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseResultsInnerPlatformsInner.new(
  name: null,
  value: null
)
```

