# OpenapiClient::SearchRoyaltyFreeImages200ResponseImagesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **width** | **Integer** |  | [optional] |
| **license** | [**SearchRoyaltyFreeImages200ResponseImagesInnerLicense**](SearchRoyaltyFreeImages200ResponseImagesInnerLicense.md) |  | [optional] |
| **thumbnail** | **String** |  | [optional] |
| **id** | **String** |  | [optional] |
| **url** | **String** |  | [optional] |
| **height** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchRoyaltyFreeImages200ResponseImagesInner.new(
  width: null,
  license: null,
  thumbnail: null,
  id: null,
  url: null,
  height: null
)
```

