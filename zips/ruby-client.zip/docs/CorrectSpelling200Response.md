# OpenapiClient::CorrectSpelling200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **corrected_text** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::CorrectSpelling200Response.new(
  corrected_text: null
)
```

