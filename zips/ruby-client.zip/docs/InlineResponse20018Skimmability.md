# OpenapiClient::InlineResponse20018Skimmability

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **mainscores** | [**InlineResponse20018SkimmabilityMainscores**](InlineResponse20018SkimmabilityMainscores.md) |  | [optional] |
| **subscores** | [**InlineResponse20018SkimmabilitySubscores**](InlineResponse20018SkimmabilitySubscores.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20018Skimmability.new(
  mainscores: null,
  subscores: null
)
```

