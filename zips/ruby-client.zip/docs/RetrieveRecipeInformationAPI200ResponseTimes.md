# OpenapiClient::RetrieveRecipeInformationAPI200ResponseTimes

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **total_minutes** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformationAPI200ResponseTimes.new(
  total_minutes: null
)
```

