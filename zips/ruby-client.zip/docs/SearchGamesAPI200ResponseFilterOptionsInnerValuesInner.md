# OpenapiClient::SearchGamesAPI200ResponseFilterOptionsInnerValuesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **count** | **Integer** |  | [optional] |
| **key** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.new(
  name: null,
  count: null,
  key: null
)
```

