# OpenapiClient::SearchMemes200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **memes** | [**Array&lt;SearchMemes200ResponseMemesInner&gt;**](SearchMemes200ResponseMemesInner.md) |  | [optional] |
| **available** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchMemes200Response.new(
  memes: null,
  available: null
)
```

