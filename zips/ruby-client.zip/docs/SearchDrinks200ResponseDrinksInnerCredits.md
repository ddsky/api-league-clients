# OpenapiClient::SearchDrinks200ResponseDrinksInnerCredits

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** |  | [optional] |
| **source_name** | **String** |  | [optional] |
| **source_url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerCredits.new(
  text: null,
  source_name: null,
  source_url: null
)
```

