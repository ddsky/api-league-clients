# OpenapiClient::InlineResponse20010

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **author** | **String** |  | [optional] |
| **quote** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20010.new(
  author: null,
  quote: null
)
```

