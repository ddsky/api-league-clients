# OpenapiClient::ScoreReadability200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **readability** | [**ScoreText200ResponseReadability**](ScoreText200ResponseReadability.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ScoreReadability200Response.new(
  readability: null
)
```

