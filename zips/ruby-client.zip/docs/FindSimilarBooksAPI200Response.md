# OpenapiClient::FindSimilarBooksAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **similar_books** | [**Array&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;**](SearchBooksAPI200ResponseBooksInnerInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::FindSimilarBooksAPI200Response.new(
  similar_books: null
)
```

