# OpenapiClient::InlineResponse20016

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **corrected_text** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20016.new(
  corrected_text: null
)
```

