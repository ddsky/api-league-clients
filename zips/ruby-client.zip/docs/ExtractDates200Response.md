# OpenapiClient::ExtractDates200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **dates** | [**Array&lt;ExtractDates200ResponseDatesInner&gt;**](ExtractDates200ResponseDatesInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::ExtractDates200Response.new(
  dates: null
)
```

