# OpenapiClient::InlineResponse20027Entities

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **start_position** | **Integer** |  | [optional] |
| **image** | **String** |  | [optional] |
| **type** | **String** |  | [optional] |
| **value** | **String** |  | [optional] |
| **end_position** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20027Entities.new(
  start_position: null,
  image: null,
  type: null,
  value: null,
  end_position: null
)
```

