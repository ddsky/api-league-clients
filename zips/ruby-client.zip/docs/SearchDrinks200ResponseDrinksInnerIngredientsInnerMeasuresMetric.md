# OpenapiClient::SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **unit_short** | **String** |  | [optional] |
| **amount** | **Float** |  | [optional] |
| **unit_long** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric.new(
  unit_short: null,
  amount: null,
  unit_long: null
)
```

