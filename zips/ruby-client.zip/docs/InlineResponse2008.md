# OpenapiClient::InlineResponse2008

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **word** | **String** |  | [optional] |
| **rating** | **Float** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2008.new(
  word: null,
  rating: null
)
```

