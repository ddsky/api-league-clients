# OpenapiClient::InlineResponse20021

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **dates** | [**Array&lt;InlineResponse20021Dates&gt;**](InlineResponse20021Dates.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20021.new(
  dates: null
)
```

