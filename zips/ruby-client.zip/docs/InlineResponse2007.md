# OpenapiClient::InlineResponse2007

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **images** | [**Array&lt;InlineResponse2007Images&gt;**](InlineResponse2007Images.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2007.new(
  images: null
)
```

