# OpenapiClient::InlineResponse20015

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **results** | [**Array&lt;InlineResponse20015Results&gt;**](InlineResponse20015Results.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20015.new(
  results: null
)
```

