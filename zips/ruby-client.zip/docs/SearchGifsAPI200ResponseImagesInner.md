# OpenapiClient::SearchGifsAPI200ResponseImagesInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **width** | **Integer** |  | [optional] |
| **url** | **String** |  | [optional] |
| **height** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchGifsAPI200ResponseImagesInner.new(
  width: null,
  url: null,
  height: null
)
```

