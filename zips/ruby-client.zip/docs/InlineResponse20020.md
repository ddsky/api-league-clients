# OpenapiClient::InlineResponse20020

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse20020.new(
  readability: null
)
```

