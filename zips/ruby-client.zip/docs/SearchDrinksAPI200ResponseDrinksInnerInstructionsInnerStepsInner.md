# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **number** | **Integer** |  | [optional] |
| **ingredients** | [**Array&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] |
| **equipment** | **Array&lt;String&gt;** |  | [optional] |
| **step** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.new(
  number: null,
  ingredients: null,
  equipment: null,
  step: null
)
```

