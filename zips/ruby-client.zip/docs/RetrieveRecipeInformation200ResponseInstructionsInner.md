# OpenapiClient::RetrieveRecipeInformation200ResponseInstructionsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **steps** | [**Array&lt;RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner&gt;**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseInstructionsInner.new(
  name: null,
  steps: null
)
```

