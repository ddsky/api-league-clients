# OpenapiClient::SingularizeWord200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **original** | **String** |  | [optional] |
| **singular** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SingularizeWord200Response.new(
  original: null,
  singular: null
)
```

