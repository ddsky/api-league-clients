# OpenapiClient::RetrieveRecipeInformation200ResponseNutritionWeightPerServing

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **amount** | **Integer** |  | [optional] |
| **unit** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RetrieveRecipeInformation200ResponseNutritionWeightPerServing.new(
  amount: null,
  unit: null
)
```

