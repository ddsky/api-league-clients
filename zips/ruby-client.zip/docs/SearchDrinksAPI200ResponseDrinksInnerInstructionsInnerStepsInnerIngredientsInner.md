# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **image** | **String** |  | [optional] |
| **id** | **Integer** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.new(
  name: null,
  image: null,
  id: null
)
```

