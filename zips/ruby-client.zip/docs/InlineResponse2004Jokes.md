# OpenapiClient::InlineResponse2004Jokes

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **joke** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::InlineResponse2004Jokes.new(
  joke: null
)
```

