# OpenapiClient::SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **name** | **String** |  | [optional] |
| **amount** | **Integer** |  | [optional] |
| **unit** | **String** |  | [optional] |
| **id** | **Integer** |  | [optional] |
| **nutrients** | [**Array&lt;SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner.new(
  name: null,
  amount: null,
  unit: null,
  id: null,
  nutrients: null
)
```

