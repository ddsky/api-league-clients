# OpenapiClient::RandomTriviaAPI200Response

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **trivia** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::RandomTriviaAPI200Response.new(
  trivia: null
)
```

