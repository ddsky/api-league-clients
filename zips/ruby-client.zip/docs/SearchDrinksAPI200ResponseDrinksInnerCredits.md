# OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerCredits

## Properties

| Name | Type | Description | Notes |
| ---- | ---- | ----------- | ----- |
| **text** | **String** |  | [optional] |
| **source_name** | **String** |  | [optional] |
| **source_url** | **String** |  | [optional] |

## Example

```ruby
require 'openapi_client'

instance = OpenapiClient::SearchDrinksAPI200ResponseDrinksInnerCredits.new(
  text: null,
  source_name: null,
  source_url: null
)
```

