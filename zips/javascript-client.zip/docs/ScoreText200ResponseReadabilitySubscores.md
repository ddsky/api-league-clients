# ApiLeague.ScoreText200ResponseReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **Number** |  | [optional] 
**forcast** | **Number** |  | [optional] 
**flesch** | **Number** |  | [optional] 
**smog** | **Number** |  | [optional] 
**ari** | **Number** |  | [optional] 
**lix** | **Number** |  | [optional] 
**colemanLiau** | **Number** |  | [optional] 
**kincaid** | **Number** |  | [optional] 
**fog** | **Number** |  | [optional] 


