# ApiLeague.RetrieveRecipeInformation200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**steps** | [**[RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner.md) |  | [optional] 


