# ApileagueJs.SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**percentOfDailyNeeds** | **Number** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 


