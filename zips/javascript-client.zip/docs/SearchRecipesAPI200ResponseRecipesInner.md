# ApileagueJs.SearchRecipesAPI200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **[String]** |  | [optional] 
**nutrition** | [**SearchRecipesAPI200ResponseRecipesInnerNutrition**](SearchRecipesAPI200ResponseRecipesInnerNutrition.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 


