# ApileagueJs.SearchDrinksAPI200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **[String]** |  | [optional] 
**instructions** | [**[SearchDrinksAPI200ResponseDrinksInnerInstructionsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.md) |  | [optional] 
**images** | **[String]** |  | [optional] 
**nutrition** | [**SearchDrinksAPI200ResponseDrinksInnerNutrition**](SearchDrinksAPI200ResponseDrinksInnerNutrition.md) |  | [optional] 
**glassType** | **String** |  | [optional] 
**credits** | [**SearchDrinksAPI200ResponseDrinksInnerCredits**](SearchDrinksAPI200ResponseDrinksInnerCredits.md) |  | [optional] 
**pricePerServing** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
**ingredients** | [**[SearchDrinksAPI200ResponseDrinksInnerIngredientsInner]**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInner.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**cuisines** | **[String]** |  | [optional] 


