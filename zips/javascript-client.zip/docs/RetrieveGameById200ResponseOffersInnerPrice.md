# ApileagueJs.RetrieveGameById200ResponseOffersInnerPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **String** |  | [optional] 
**discountPercent** | **Number** |  | [optional] 
**value** | **Number** |  | [optional] 
**initial** | **Number** |  | [optional] 


