# ApiLeague.InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberOfWords** | **Number** |  | [optional] 
**numberOfSentences** | **Number** |  | [optional] 
**readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  | [optional] 
**skimmability** | [**InlineResponse20019Skimmability**](InlineResponse20019Skimmability.md) |  | [optional] 
**interestingness** | [**InlineResponse20019Interestingness**](InlineResponse20019Interestingness.md) |  | [optional] 
**style** | [**InlineResponse20019Style**](InlineResponse20019Style.md) |  | [optional] 
**totalScore** | **Number** |  | [optional] 


