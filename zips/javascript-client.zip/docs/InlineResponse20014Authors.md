# ApiLeague.InlineResponse20014Authors

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **String** |  | [optional] 
**name** | **String** |  | [optional] 


