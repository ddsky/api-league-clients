# ApileagueJs.RetrieveRecipeInformation200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | **Number** |  | [optional] 
**spiciness** | **Number** |  | [optional] 
**saltiness** | **Number** |  | [optional] 
**bitterness** | **Number** |  | [optional] 
**savoriness** | **Number** |  | [optional] 
**sweetness** | **Number** |  | [optional] 
**sourness** | **Number** |  | [optional] 


