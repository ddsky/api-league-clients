# ApiLeague.InlineResponse20014

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | [**[InlineResponse20014Authors]**](InlineResponse20014Authors.md) |  | [optional] 


