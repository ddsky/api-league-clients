# ApiLeague.CorrectSpelling200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**correctedText** | **String** |  | [optional] 


