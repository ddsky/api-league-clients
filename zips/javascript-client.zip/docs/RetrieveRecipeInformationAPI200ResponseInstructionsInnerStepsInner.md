# ApileagueJs.RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | [optional] 
**ingredients** | [**[SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**[SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**step** | **String** |  | [optional] 


