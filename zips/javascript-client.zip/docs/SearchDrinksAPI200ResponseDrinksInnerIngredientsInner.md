# ApileagueJs.SearchDrinksAPI200ResponseDrinksInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | [optional] 
**nameClean** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 
**measures** | [**SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasures.md) |  | [optional] 
**original** | **String** |  | [optional] 
**meta** | **[String]** |  | [optional] 
**originalName** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**aisle** | **String** |  | [optional] 
**consistency** | **String** |  | [optional] 


