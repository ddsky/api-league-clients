# ApileagueJs.RetrieveRecipeInformation200ResponseNutritionWeightPerServing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 


