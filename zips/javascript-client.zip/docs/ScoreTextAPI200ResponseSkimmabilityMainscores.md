# ApileagueJs.ScoreTextAPI200ResponseSkimmabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 


