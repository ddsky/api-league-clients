# ApileagueJs.SearchGamesAPI200ResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** |  | [optional] 
**connection** | **String** |  | [optional] 
**values** | [**[SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner]**](SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.md) |  | [optional] 


