# ApileagueJs.FindSimilarGamesAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | [optional] 
**shortDescription** | **String** |  | [optional] 
**microTrailer** | **String** |  | [optional] 
**year** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**genre** | **String** |  | [optional] 
**link** | **String** |  | [optional] 
**rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**adultOnly** | **Boolean** |  | [optional] 
**screenshots** | **[String]** |  | [optional] 
**gameplay** | **String** |  | [optional] 


