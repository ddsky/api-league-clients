# ApiLeague.InlineResponse20010

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | **String** |  | [optional] 
**quote** | **String** |  | [optional] 


