# ApiLeague.ExtractDates200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**[ExtractDates200ResponseDatesInner]**](ExtractDates200ResponseDatesInner.md) |  | [optional] 


