# ApileagueJs.SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**delivery** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**pickup** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 
**dineIn** | [**SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional] 


