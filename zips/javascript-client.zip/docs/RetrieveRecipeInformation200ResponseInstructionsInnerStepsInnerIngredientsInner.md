# ApiLeague.RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 


