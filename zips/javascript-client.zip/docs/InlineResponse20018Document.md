# ApiLeague.InlineResponse20018Document

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | **String** |  | [optional] 
**confidence** | **Number** |  | [optional] 
**averageConfidence** | **Number** |  | [optional] 


