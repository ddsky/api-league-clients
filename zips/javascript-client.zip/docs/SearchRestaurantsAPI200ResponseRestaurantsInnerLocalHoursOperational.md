# ApileagueJs.SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **String** |  | [optional] 
**saturday** | **String** |  | [optional] 
**tuesday** | **String** |  | [optional] 
**thursday** | **String** |  | [optional] 
**friday** | **String** |  | [optional] 
**wednesday** | **String** |  | [optional] 
**monday** | **String** |  | [optional] 


