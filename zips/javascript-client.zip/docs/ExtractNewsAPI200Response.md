# ApileagueJs.ExtractNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**images** | [**[ExtractNewsAPI200ResponseImagesInner]**](ExtractNewsAPI200ResponseImagesInner.md) |  | [optional] 
**videos** | [**[ExtractNewsAPI200ResponseVideosInner]**](ExtractNewsAPI200ResponseVideosInner.md) |  | [optional] 
**publishDate** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 
**language** | **String** |  | [optional] 


