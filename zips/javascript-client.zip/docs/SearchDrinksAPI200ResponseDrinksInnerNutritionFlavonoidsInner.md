# ApileagueJs.SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 


