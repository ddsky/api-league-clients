# ApileagueJs.RetrieveGameById200ResponseOfficialStoresInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** |  | [optional] 
**source** | **String** |  | [optional] 


