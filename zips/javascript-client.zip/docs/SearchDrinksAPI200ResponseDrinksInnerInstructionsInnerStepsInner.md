# ApileagueJs.SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | [optional] 
**ingredients** | [**[SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | **[String]** |  | [optional] 
**step** | **String** |  | [optional] 


