# ApileagueJs.DetectSentimentAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**DetectSentimentAPI200ResponseDocument**](DetectSentimentAPI200ResponseDocument.md) |  | [optional] 
**sentences** | [**[DetectSentimentAPI200ResponseSentencesInner]**](DetectSentimentAPI200ResponseSentencesInner.md) |  | [optional] 


