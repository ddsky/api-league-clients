# ApiLeague.SearchRestaurants200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**latitude** | **Number** |  | [optional] 
**lon** | **Number** |  | [optional] 
**streetAddr2** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**streetAddr** | **String** |  | [optional] 
**lat** | **Number** |  | [optional] 
**longitude** | **Number** |  | [optional] 


