# ApileagueJs.RandomMemeAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**width** | **Number** |  | [optional] 
**height** | **Number** |  | [optional] 
**ratio** | **Number** |  | [optional] 


