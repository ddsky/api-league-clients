# ApiLeague.InlineResponse20027

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**[InlineResponse20027Entities]**](InlineResponse20027Entities.md) |  | [optional] 


