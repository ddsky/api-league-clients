# ApileagueJs.SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unitShort** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unitLong** | **String** |  | [optional] 


