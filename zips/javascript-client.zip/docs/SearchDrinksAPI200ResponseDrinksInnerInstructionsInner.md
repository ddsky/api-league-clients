# ApileagueJs.SearchDrinksAPI200ResponseDrinksInnerInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**steps** | [**[SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] 


