# ApileagueJs.FindSimilarGamesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[FindSimilarGamesAPI200ResponseResultsInner]**](FindSimilarGamesAPI200ResponseResultsInner.md) |  | [optional] 


