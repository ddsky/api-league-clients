# ApileagueJs.ScoreText200ResponseInterestingnessSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titleRatingScore** | **[Number]** |  | [optional] 
**quoteScore** | **[Number]** |  | [optional] 
**lengthScore** | **[Number]** |  | [optional] 
**linkScore** | **[Number]** |  | [optional] 
**googleHitsScore** | **[Number]** |  | [optional] 


