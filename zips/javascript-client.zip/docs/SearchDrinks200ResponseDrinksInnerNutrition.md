# ApileagueJs.SearchDrinks200ResponseDrinksInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weightPerServing** | [**SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional] 
**caloricBreakdown** | [**SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional] 
**flavonoids** | [**[SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner]**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional] 
**ingredientBreakdown** | [**[SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner]**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  | [optional] 
**properties** | [**[SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner]**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional] 
**nutrients** | [**[SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner]**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional] 


