# ApileagueJs.RetrievePageRank200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pageRank** | **Number** |  | [optional] 
**position** | **Number** |  | [optional] 
**percentile** | **Number** |  | [optional] 


