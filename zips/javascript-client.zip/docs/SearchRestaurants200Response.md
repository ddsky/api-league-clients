# ApileagueJs.SearchRestaurants200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**[SearchRestaurants200ResponseRestaurantsInner]**](SearchRestaurants200ResponseRestaurantsInner.md) |  | [optional] 


