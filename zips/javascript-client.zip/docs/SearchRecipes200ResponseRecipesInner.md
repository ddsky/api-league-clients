# ApileagueJs.SearchRecipes200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **[String]** |  | [optional] 
**nutrition** | [**SearchRecipes200ResponseRecipesInnerNutrition**](SearchRecipes200ResponseRecipesInnerNutrition.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 


