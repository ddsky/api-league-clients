# ApiLeague.InlineResponse20028License

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**link** | **String** |  | [optional] 


