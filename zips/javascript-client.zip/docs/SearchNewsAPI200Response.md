# ApileagueJs.SearchNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**available** | **Number** |  | [optional] 
**news** | [**[SearchNewsAPI200ResponseNewsInner]**](SearchNewsAPI200ResponseNewsInner.md) |  | [optional] 


