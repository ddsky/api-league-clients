# ApiLeague.InlineResponse2007

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**[InlineResponse2007Images]**](InlineResponse2007Images.md) |  | [optional] 


