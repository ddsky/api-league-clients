# ApiLeague.InlineResponse2005

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**[InlineResponse2005Memes]**](InlineResponse2005Memes.md) |  | [optional] 
**available** | **Number** |  | [optional] 


