# ApiLeague.InlineResponse20015

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[InlineResponse20015Results]**](InlineResponse20015Results.md) |  | [optional] 


