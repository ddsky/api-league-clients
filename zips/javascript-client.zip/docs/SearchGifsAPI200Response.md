# ApileagueJs.SearchGifsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**[SearchGifsAPI200ResponseImagesInner]**](SearchGifsAPI200ResponseImagesInner.md) |  | [optional] 


