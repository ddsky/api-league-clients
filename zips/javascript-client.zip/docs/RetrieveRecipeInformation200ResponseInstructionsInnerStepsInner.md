# ApiLeague.RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | [optional] 
**ingredients** | [**[RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**[RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**step** | **String** |  | [optional] 


