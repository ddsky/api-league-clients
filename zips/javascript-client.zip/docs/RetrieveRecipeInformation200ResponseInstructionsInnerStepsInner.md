# ApileagueJs.RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **Number** |  | [optional] 
**ingredients** | [**[SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner]**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**equipment** | [**[SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner]**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional] 
**step** | **String** |  | [optional] 


