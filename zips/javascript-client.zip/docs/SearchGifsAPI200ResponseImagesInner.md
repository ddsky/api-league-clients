# ApileagueJs.SearchGifsAPI200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Number** |  | [optional] 
**url** | **String** |  | [optional] 
**height** | **Number** |  | [optional] 


