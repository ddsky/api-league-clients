# ApileagueJs.SearchGamesAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | [optional] 
**shortDescription** | **String** |  | [optional] 
**year** | **Number** |  | [optional] 
**link** | **String** |  | [optional] 
**rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  | [optional] 
**adultOnly** | **Boolean** |  | [optional] 
**screenshots** | **[String]** |  | [optional] 
**platforms** | [**[SearchGamesAPI200ResponseResultsInnerPlatformsInner]**](SearchGamesAPI200ResponseResultsInnerPlatformsInner.md) |  | [optional] 
**microTrailer** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**genre** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**gameplay** | **String** |  | [optional] 


