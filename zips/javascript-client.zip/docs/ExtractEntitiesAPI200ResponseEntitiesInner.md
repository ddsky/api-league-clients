# ApileagueJs.ExtractEntitiesAPI200ResponseEntitiesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Number** |  | [optional] 
**image** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**value** | **String** |  | [optional] 
**endPosition** | **Number** |  | [optional] 


