# ApiLeague.SearchRoyaltyFreeImages200ResponseImagesInnerLicense

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**link** | **String** |  | [optional] 


