# ApiLeague.InlineResponse20021

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**[InlineResponse20021Dates]**](InlineResponse20021Dates.md) |  | [optional] 


