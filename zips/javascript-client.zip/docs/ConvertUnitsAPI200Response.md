# ApileagueJs.ConvertUnitsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**targetAmount** | **Number** |  | [optional] 
**targetUnit** | **String** |  | [optional] 


