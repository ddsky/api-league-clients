# ApiLeague.RetrieveRecipeInformation200ResponseScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metaScore** | **Number** |  | [optional] 
**weightWatcherSmartPoints** | **Number** |  | [optional] 
**healthScore** | **Number** |  | [optional] 


