# ApileagueJs.RetrieveGameById200ResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Number** |  | [optional] 
**countCritics** | **Number** |  | [optional] 
**meanPlayers** | **Number** |  | [optional] 
**meanCritics** | **Number** |  | [optional] 
**mean** | **Number** |  | [optional] 
**countPlayers** | **Number** |  | [optional] 


