# ApiLeague.InlineResponse20018SkimmabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 


