# ApiLeague.SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**sentiment** | **Number** |  | [optional] 
**sourceCountry** | **String** |  | [optional] 
**language** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**text** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**publishDate** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 


