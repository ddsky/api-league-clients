# ApiLeague.SearchWeb200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[SearchWeb200ResponseResultsInner]**](SearchWeb200ResponseResultsInner.md) |  | [optional] 


