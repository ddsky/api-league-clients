# ApileagueJs.SearchJokesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**[SearchJokesAPI200ResponseJokesInner]**](SearchJokesAPI200ResponseJokesInner.md) |  | [optional] 
**available** | **Number** |  | [optional] 


