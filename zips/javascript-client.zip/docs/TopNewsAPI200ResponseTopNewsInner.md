# ApileagueJs.TopNewsAPI200ResponseTopNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**[TopNewsAPI200ResponseTopNewsInnerNewsInner]**](TopNewsAPI200ResponseTopNewsInnerNewsInner.md) |  | [optional] 


