# ApileagueJs.TopNews200ResponseTopNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**[TopNews200ResponseTopNewsInnerNewsInner]**](TopNews200ResponseTopNewsInnerNewsInner.md) |  | [optional] 


