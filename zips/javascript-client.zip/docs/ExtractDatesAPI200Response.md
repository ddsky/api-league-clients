# ApileagueJs.ExtractDatesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**[ExtractDatesAPI200ResponseDatesInner]**](ExtractDatesAPI200ResponseDatesInner.md) |  | [optional] 


