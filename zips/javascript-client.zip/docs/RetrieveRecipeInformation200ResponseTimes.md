# ApileagueJs.RetrieveRecipeInformation200ResponseTimes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalMinutes** | **Number** |  | [optional] 


