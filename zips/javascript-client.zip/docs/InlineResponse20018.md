# ApiLeague.InlineResponse20018

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**InlineResponse20018Document**](InlineResponse20018Document.md) |  | [optional] 
**sentences** | [**[InlineResponse20018Sentences]**](InlineResponse20018Sentences.md) |  | [optional] 


