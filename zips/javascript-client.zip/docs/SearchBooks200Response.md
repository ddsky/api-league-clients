# ApileagueJs.SearchBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalResults** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**books** | **[[SearchBooks200ResponseBooksInnerInner]]** |  | [optional] 


