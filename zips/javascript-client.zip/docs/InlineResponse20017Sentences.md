# ApiLeague.InlineResponse20017Sentences

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **Number** |  | [optional] 
**sentiment** | **String** |  | [optional] 
**offset** | **Number** |  | [optional] 
**confidence** | **Number** |  | [optional] 


