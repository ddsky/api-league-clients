# ApileagueJs.SearchJokes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**[SearchJokes200ResponseJokesInner]**](SearchJokes200ResponseJokesInner.md) |  | [optional] 
**available** | **Number** |  | [optional] 


