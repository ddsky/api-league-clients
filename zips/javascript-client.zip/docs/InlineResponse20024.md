# ApiLeague.InlineResponse20024

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  | [optional] 
**stemmed** | **String** |  | [optional] 


