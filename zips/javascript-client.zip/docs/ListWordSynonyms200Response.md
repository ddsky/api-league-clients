# ApileagueJs.ListWordSynonyms200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synonyms** | **[String]** |  | [optional] 


