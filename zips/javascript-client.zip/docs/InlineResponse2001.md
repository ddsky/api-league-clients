# ApiLeague.InlineResponse2001

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**[InlineResponse200Books]**](InlineResponse200Books.md) |  | [optional] 


