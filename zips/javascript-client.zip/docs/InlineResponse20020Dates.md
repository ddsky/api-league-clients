# ApiLeague.InlineResponse20020Dates

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Number** |  | [optional] 
**date** | **String** |  | [optional] 
**normalizedDate** | [**Null**](Null.md) |  | [optional] 
**tag** | **String** |  | [optional] 
**endPosition** | **Number** |  | [optional] 


