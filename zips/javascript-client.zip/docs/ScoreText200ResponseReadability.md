# ApileagueJs.ScoreText200ResponseReadability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**ScoreText200ResponseReadabilityMainscores**](ScoreText200ResponseReadabilityMainscores.md) |  | [optional] 
**subscores** | [**ScoreText200ResponseReadabilitySubscores**](ScoreText200ResponseReadabilitySubscores.md) |  | [optional] 


