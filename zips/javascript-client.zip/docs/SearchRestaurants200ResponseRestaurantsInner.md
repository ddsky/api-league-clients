# ApiLeague.SearchRestaurants200ResponseRestaurantsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offersThirdPartyDelivery** | **Boolean** |  | [optional] 
**address** | [**SearchRestaurants200ResponseRestaurantsInnerAddress**](SearchRestaurants200ResponseRestaurantsInnerAddress.md) |  | [optional] 
**supportsUpcCodes** | **Boolean** |  | [optional] 
**isOpen** | **Boolean** |  | [optional] 
**description** | **String** |  | [optional] 
**weightedRatingValue** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**offersFirstPartyDelivery** | **Boolean** |  | [optional] 
**aggregatedRatingCount** | **Number** |  | [optional] 
**pickupEnabled** | **Boolean** |  | [optional] 
**cuisines** | **[String]** |  | [optional] 
**miles** | **Number** |  | [optional] 
**dollarSigns** | **Number** |  | [optional] 
**deliveryEnabled** | **Boolean** |  | [optional] 
**name** | **String** |  | [optional] 
**phoneNumber** | **Number** |  | [optional] 
**id** | **String** |  | [optional] 
**localHours** | [**SearchRestaurants200ResponseRestaurantsInnerLocalHours**](SearchRestaurants200ResponseRestaurantsInnerLocalHours.md) |  | [optional] 


