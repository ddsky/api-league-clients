# ApileagueJs.SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**recipes** | [**[SearchRecipes200ResponseRecipesInner]**](SearchRecipes200ResponseRecipesInner.md) |  | [optional] 
**totalResults** | **Number** |  | [optional] 


