# ApileagueJs.ArtSearchAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**artworks** | [**[SearchBooksAPI200ResponseBooksInnerInner]**](SearchBooksAPI200ResponseBooksInnerInner.md) |  | [optional] 


