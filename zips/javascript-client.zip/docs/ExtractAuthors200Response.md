# ApiLeague.ExtractAuthors200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | [**[ExtractAuthors200ResponseAuthorsInner]**](ExtractAuthors200ResponseAuthorsInner.md) |  | [optional] 


