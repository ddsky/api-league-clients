# ApileagueJs.ExtractNewsAPI200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **String** |  | [optional] 
**duration** | **Number** |  | [optional] 
**thumbnail** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


