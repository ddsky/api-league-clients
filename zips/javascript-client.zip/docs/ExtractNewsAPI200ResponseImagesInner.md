# ApileagueJs.ExtractNewsAPI200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**height** | **Number** |  | [optional] 


