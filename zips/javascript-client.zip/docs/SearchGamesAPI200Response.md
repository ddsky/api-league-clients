# ApileagueJs.SearchGamesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sorting** | **Object** |  | [optional] 
**activeFilterOptions** | [**[SearchGamesAPI200ResponseActiveFilterOptionsInner]**](SearchGamesAPI200ResponseActiveFilterOptionsInner.md) |  | [optional] 
**query** | **String** |  | [optional] 
**totalResults** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**results** | [**[SearchGamesAPI200ResponseResultsInner]**](SearchGamesAPI200ResponseResultsInner.md) |  | [optional] 
**filterOptions** | [**[SearchGamesAPI200ResponseFilterOptionsInner]**](SearchGamesAPI200ResponseFilterOptionsInner.md) |  | [optional] 
**sortingOptions** | [**[SearchGamesAPI200ResponseSortingOptionsInner]**](SearchGamesAPI200ResponseSortingOptionsInner.md) |  | [optional] 


