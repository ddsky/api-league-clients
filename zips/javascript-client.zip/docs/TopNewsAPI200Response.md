# ApileagueJs.TopNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**topNews** | [**[TopNewsAPI200ResponseTopNewsInner]**](TopNewsAPI200ResponseTopNewsInner.md) |  | [optional] 
**language** | **String** |  | [optional] 
**country** | **String** |  | [optional] 


