# ApileagueJs.SearchRoyaltyFreeImagesAPI200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Number** |  | [optional] 
**license** | [**SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense**](SearchRoyaltyFreeImagesAPI200ResponseImagesInnerLicense.md) |  | [optional] 
**thumbnail** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**height** | **Number** |  | [optional] 


