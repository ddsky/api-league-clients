# ApileagueJs.SearchDrinks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**drinks** | [**[SearchDrinks200ResponseDrinksInner]**](SearchDrinks200ResponseDrinksInner.md) |  | [optional] 
**totalResults** | **Number** |  | [optional] 


