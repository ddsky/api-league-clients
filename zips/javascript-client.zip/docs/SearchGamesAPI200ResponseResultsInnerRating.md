# ApileagueJs.SearchGamesAPI200ResponseResultsInnerRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Number** |  | [optional] 
**mean** | **Number** |  | [optional] 


