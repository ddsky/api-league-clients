# ApileagueJs.RetrieveRecipeInformationAPI200ResponseInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**steps** | [**[RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner]**](RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner.md) |  | [optional] 


