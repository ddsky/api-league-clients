# ApileagueJs.SearchDrinks200ResponseDrinksInnerInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**steps** | [**[SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner]**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional] 


