# ApileagueJs.SearchBooks200ResponseBooksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 


