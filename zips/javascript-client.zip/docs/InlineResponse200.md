# ApiLeague.InlineResponse200

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**books** | [**[InlineResponse200Books]**](InlineResponse200Books.md) |  | [optional] 


