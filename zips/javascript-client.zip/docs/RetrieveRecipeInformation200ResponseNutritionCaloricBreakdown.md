# ApileagueJs.RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentFat** | **Number** |  | [optional] 
**percentCarbs** | **Number** |  | [optional] 
**percentProtein** | **Number** |  | [optional] 


