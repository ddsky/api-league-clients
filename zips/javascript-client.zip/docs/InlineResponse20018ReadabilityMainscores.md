# ApiLeague.InlineResponse20018ReadabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 


