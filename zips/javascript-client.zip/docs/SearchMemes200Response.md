# ApiLeague.SearchMemes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**[SearchMemes200ResponseMemesInner]**](SearchMemes200ResponseMemesInner.md) |  | [optional] 
**available** | **Number** |  | [optional] 


