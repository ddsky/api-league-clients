# ApileagueJs.ComputeNutrition200ResponseIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**nutrients** | [**[ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner]**](ComputeNutrition200ResponseIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 


