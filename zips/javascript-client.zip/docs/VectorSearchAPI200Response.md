# ApileagueJs.VectorSearchAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vectors** | [**[VectorSearchAPI200ResponseVectorsInner]**](VectorSearchAPI200ResponseVectorsInner.md) |  | [optional] 


