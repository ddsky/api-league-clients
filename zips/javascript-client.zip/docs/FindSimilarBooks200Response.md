# ApileagueJs.FindSimilarBooks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**[SearchBooks200ResponseBooksInnerInner]**](SearchBooks200ResponseBooksInnerInner.md) |  | [optional] 


