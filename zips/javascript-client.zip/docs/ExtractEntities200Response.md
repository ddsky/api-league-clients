# ApiLeague.ExtractEntities200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**[ExtractEntities200ResponseEntitiesInner]**](ExtractEntities200ResponseEntitiesInner.md) |  | [optional] 


