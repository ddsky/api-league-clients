# ApiLeague.InlineResponse20017

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** |  | [optional] 
**confidence** | **Number** |  | [optional] 


