# ApileagueJs.SearchGamesAPI200ResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**filterType** | **String** |  | [optional] 
**key** | **String** |  | [optional] 
**values** | [**[SearchGamesAPI200ResponseFilterOptionsInnerValuesInner]**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  | [optional] 
**filterConnection** | **String** |  | [optional] 


