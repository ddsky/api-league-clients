# ApileagueJs.SearchMemesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**[SearchMemesAPI200ResponseMemesInner]**](SearchMemesAPI200ResponseMemesInner.md) |  | [optional] 
**available** | **Number** |  | [optional] 


