# ApiLeague.InlineResponse2004

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**[InlineResponse2004Jokes]**](InlineResponse2004Jokes.md) |  | [optional] 
**available** | **Number** |  | [optional] 


