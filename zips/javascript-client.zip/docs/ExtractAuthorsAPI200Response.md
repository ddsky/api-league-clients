# ApileagueJs.ExtractAuthorsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authors** | [**[ExtractAuthorsAPI200ResponseAuthorsInner]**](ExtractAuthorsAPI200ResponseAuthorsInner.md) |  | [optional] 


