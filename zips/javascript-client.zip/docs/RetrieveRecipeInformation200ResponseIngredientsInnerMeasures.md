# ApiLeague.RetrieveRecipeInformation200ResponseIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 
**us** | [**RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional] 


