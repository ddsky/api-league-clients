# ApileagueJs.SearchRestaurantsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**[SearchRestaurantsAPI200ResponseRestaurantsInner]**](SearchRestaurantsAPI200ResponseRestaurantsInner.md) |  | [optional] 


