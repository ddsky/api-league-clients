# ApiLeague.SearchGifs200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**[SearchGifs200ResponseImagesInner]**](SearchGifs200ResponseImagesInner.md) |  | [optional] 


