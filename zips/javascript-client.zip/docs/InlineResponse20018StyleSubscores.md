# ApiLeague.InlineResponse20018StyleSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abbreviationScore** | **[Number]** |  | [optional] 
**styleScore** | **[Number]** |  | [optional] 
**spellingScore** | **[Number]** |  | [optional] 


