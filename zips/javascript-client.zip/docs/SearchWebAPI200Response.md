# ApileagueJs.SearchWebAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**[SearchWebAPI200ResponseResultsInner]**](SearchWebAPI200ResponseResultsInner.md) |  | [optional] 


