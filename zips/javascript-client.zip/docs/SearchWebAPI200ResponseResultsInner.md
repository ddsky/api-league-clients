# ApileagueJs.SearchWebAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**summary** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


