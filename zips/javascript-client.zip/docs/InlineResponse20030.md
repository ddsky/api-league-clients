# ApiLeague.InlineResponse20030

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**targetAmount** | **Number** |  | [optional] 
**targetUnit** | **String** |  | [optional] 


