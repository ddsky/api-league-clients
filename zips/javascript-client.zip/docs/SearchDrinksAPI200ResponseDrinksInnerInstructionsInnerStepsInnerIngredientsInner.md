# ApileagueJs.SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**image** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 


