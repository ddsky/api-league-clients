# ApiLeague.ScoreText200ResponseReadabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 


