# ApileagueJs.ExtractEntitiesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**[ExtractEntitiesAPI200ResponseEntitiesInner]**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  | [optional] 


