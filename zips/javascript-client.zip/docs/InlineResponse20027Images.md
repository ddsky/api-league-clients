# ApiLeague.InlineResponse20027Images

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Number** |  | [optional] 
**license** | [**InlineResponse20027License**](InlineResponse20027License.md) |  | [optional] 
**thumbnail** | **String** |  | [optional] 
**id** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**height** | **Number** |  | [optional] 


