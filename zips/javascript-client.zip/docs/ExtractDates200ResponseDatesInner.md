# ApileagueJs.ExtractDates200ResponseDatesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Number** |  | [optional] 
**date** | **String** |  | [optional] 
**normalizedDate** | **Number** |  | [optional] 
**tag** | **String** |  | [optional] 
**endPosition** | **Number** |  | [optional] 


