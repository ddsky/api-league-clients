# ApileagueJs.SearchDrinks200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **[String]** |  | [optional] 
**instructions** | [**[SearchDrinks200ResponseDrinksInnerInstructionsInner]**](SearchDrinks200ResponseDrinksInnerInstructionsInner.md) |  | [optional] 
**images** | **[String]** |  | [optional] 
**nutrition** | [**SearchDrinks200ResponseDrinksInnerNutrition**](SearchDrinks200ResponseDrinksInnerNutrition.md) |  | [optional] 
**glassType** | **String** |  | [optional] 
**credits** | [**SearchDrinks200ResponseDrinksInnerCredits**](SearchDrinks200ResponseDrinksInnerCredits.md) |  | [optional] 
**pricePerServing** | **Number** |  | [optional] 
**description** | **String** |  | [optional] 
**ingredients** | [**[SearchDrinks200ResponseDrinksInnerIngredientsInner]**](SearchDrinks200ResponseDrinksInnerIngredientsInner.md) |  | [optional] 
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**cuisines** | **[String]** |  | [optional] 


