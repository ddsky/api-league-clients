# ApileagueJs.FindSimilarBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarBooks** | [**[SearchBooksAPI200ResponseBooksInnerInner]**](SearchBooksAPI200ResponseBooksInnerInner.md) |  | [optional] 


