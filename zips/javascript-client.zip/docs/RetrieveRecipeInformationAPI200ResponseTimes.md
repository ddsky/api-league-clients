# ApileagueJs.RetrieveRecipeInformationAPI200ResponseTimes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalMinutes** | **Number** |  | [optional] 


