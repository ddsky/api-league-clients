# ApileagueJs.ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**url** | **String** |  | [optional] 
**images** | [**[ExtractNews200ResponseImagesInner]**](ExtractNews200ResponseImagesInner.md) |  | [optional] 
**videos** | [**[ExtractNews200ResponseVideosInner]**](ExtractNews200ResponseVideosInner.md) |  | [optional] 
**publishDate** | **String** |  | [optional] 
**authors** | **[String]** |  | [optional] 
**language** | **String** |  | [optional] 


