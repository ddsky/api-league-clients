# ApileagueJs.DetectGenderByNameAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**probabilityMale** | **Number** |  | [optional] 
**probabilityFemale** | **Number** |  | [optional] 
**popularity** | **Number** |  | [optional] 


