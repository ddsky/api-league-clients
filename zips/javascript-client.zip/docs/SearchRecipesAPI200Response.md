# ApileagueJs.SearchRecipesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**recipes** | [**[SearchRecipesAPI200ResponseRecipesInner]**](SearchRecipesAPI200ResponseRecipesInner.md) |  | [optional] 
**totalResults** | **Number** |  | [optional] 


