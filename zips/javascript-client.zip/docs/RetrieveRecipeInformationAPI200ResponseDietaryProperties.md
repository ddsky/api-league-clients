# ApileagueJs.RetrieveRecipeInformationAPI200ResponseDietaryProperties

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lowFodmap** | **Boolean** |  | [optional] 
**vegetarian** | **Boolean** |  | [optional] 
**vegan** | **Boolean** |  | [optional] 
**glutenFree** | **Boolean** |  | [optional] 
**dairyFree** | **Boolean** |  | [optional] 
**gaps** | **String** |  | [optional] 
**diets** | **[String]** |  | [optional] 


