# ApileagueJs.ScoreTextAPI200ResponseSkimmabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bulletPointRatioScore** | **[Number]** |  | [optional] 
**imageScore** | **[Number]** |  | [optional] 
**highlightedWordRatioScore** | **[Number]** |  | [optional] 
**videoScore** | **[Number]** |  | [optional] 
**paragraphScore** | **[Number]** |  | [optional] 
**paragraphHeadlineRatioScore** | **[Number]** |  | [optional] 


