# ApiLeague.InlineResponse20028

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**[InlineResponse20028Images]**](InlineResponse20028Images.md) |  | [optional] 


