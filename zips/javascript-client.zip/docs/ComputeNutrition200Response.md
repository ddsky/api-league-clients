# ApiLeague.ComputeNutrition200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner]**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 
**properties** | [**[RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner]**](RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  | [optional] 
**flavonoids** | [**[SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner]**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional] 
**ingredientBreakdown** | [**[ComputeNutrition200ResponseIngredientBreakdownInner]**](ComputeNutrition200ResponseIngredientBreakdownInner.md) |  | [optional] 
**caloricBreakdown** | [**RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown**](RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  | [optional] 
**weightPerServing** | [**RetrieveRecipeInformation200ResponseNutritionWeightPerServing**](RetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  | [optional] 


