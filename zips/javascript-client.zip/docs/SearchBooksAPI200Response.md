# ApileagueJs.SearchBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalResults** | **Number** |  | [optional] 
**number** | **Number** |  | [optional] 
**offset** | **Number** |  | [optional] 
**books** | **[[SearchBooksAPI200ResponseBooksInnerInner]]** |  | [optional] 


