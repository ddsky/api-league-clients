# ApileagueJs.SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**nutrients** | [**[SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner]**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional] 


