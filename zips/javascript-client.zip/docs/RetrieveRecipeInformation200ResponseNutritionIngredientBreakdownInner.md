# ApileagueJs.RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**unit** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**nutrients** | [**[SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner]**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional] 


