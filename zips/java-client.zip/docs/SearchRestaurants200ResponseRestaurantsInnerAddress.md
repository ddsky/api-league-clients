

# SearchRestaurants200ResponseRestaurantsInnerAddress


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**zipcode** | **String** |  |  [optional] |
|**country** | **String** |  |  [optional] |
|**city** | **String** |  |  [optional] |
|**latitude** | **BigDecimal** |  |  [optional] |
|**lon** | **BigDecimal** |  |  [optional] |
|**streetAddr2** | **String** |  |  [optional] |
|**state** | **String** |  |  [optional] |
|**streetAddr** | **String** |  |  [optional] |
|**lat** | **BigDecimal** |  |  [optional] |
|**longitude** | **BigDecimal** |  |  [optional] |



