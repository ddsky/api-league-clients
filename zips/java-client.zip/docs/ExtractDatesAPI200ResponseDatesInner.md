

# ExtractDatesAPI200ResponseDatesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**startPosition** | **Integer** |  |  [optional] |
|**date** | **String** |  |  [optional] |
|**normalizedDate** | **BigDecimal** |  |  [optional] |
|**tag** | **String** |  |  [optional] |
|**endPosition** | **Integer** |  |  [optional] |



