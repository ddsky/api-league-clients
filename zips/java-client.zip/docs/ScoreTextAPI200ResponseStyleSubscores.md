

# ScoreTextAPI200ResponseStyleSubscores


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**abbreviationScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**styleScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**spellingScore** | **List&lt;Integer&gt;** |  |  [optional] |



