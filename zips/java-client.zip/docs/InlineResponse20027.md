

# InlineResponse20027


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**List&lt;InlineResponse20027Entities&gt;**](InlineResponse20027Entities.md) |  |  [optional]



