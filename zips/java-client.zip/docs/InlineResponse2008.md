

# InlineResponse2008


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**word** | **String** |  |  [optional]
**rating** | **BigDecimal** |  |  [optional]



