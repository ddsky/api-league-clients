

# InlineResponse20030


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**targetAmount** | **BigDecimal** |  |  [optional]
**targetUnit** | **String** |  |  [optional]



