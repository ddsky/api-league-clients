

# InlineResponse20020


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | [**InlineResponse20019Readability**](InlineResponse20019Readability.md) |  |  [optional]



