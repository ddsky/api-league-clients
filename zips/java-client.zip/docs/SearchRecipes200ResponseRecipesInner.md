

# SearchRecipes200ResponseRecipesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**images** | **List&lt;String&gt;** |  |  [optional] |
|**nutrition** | [**SearchRecipes200ResponseRecipesInnerNutrition**](SearchRecipes200ResponseRecipesInnerNutrition.md) |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**title** | **String** |  |  [optional] |



