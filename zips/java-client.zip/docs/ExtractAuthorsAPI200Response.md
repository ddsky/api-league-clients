

# ExtractAuthorsAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**authors** | [**List&lt;ExtractAuthorsAPI200ResponseAuthorsInner&gt;**](ExtractAuthorsAPI200ResponseAuthorsInner.md) |  |  [optional] |



