

# ScoreText200ResponseSkimmability


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**mainscores** | [**ScoreText200ResponseSkimmabilityMainscores**](ScoreText200ResponseSkimmabilityMainscores.md) |  |  [optional] |
|**subscores** | [**ScoreText200ResponseSkimmabilitySubscores**](ScoreText200ResponseSkimmabilitySubscores.md) |  |  [optional] |



