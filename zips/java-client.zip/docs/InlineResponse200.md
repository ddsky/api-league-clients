

# InlineResponse200


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Integer** |  |  [optional]
**number** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**books** | [**List&lt;InlineResponse200Books&gt;**](InlineResponse200Books.md) |  |  [optional]



