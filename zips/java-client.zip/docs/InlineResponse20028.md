

# InlineResponse20028


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**List&lt;InlineResponse20028Images&gt;**](InlineResponse20028Images.md) |  |  [optional]



