

# TagPartOfSpeech200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**taggedText** | **String** |  |  [optional] |



