

# RetrieveRecipeInformationAPI200ResponseScores


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**metaScore** | **BigDecimal** |  |  [optional] |
|**weightWatcherSmartPoints** | **Integer** |  |  [optional] |
|**healthScore** | **Integer** |  |  [optional] |



