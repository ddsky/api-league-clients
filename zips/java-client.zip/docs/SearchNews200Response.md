

# SearchNews200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**available** | **Integer** |  |  [optional] |
|**news** | [**List&lt;SearchNews200ResponseNewsInner&gt;**](SearchNews200ResponseNewsInner.md) |  |  [optional] |



