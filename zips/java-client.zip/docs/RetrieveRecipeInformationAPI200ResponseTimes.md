

# RetrieveRecipeInformationAPI200ResponseTimes


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**totalMinutes** | **Integer** |  |  [optional] |



