

# VectorSearchAPI200ResponseVectorsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**license** | **String** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**author** | **String** |  |  [optional] |
|**imageUrl** | **String** |  |  [optional] |



