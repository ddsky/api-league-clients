

# ConvertUnits200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**targetAmount** | **BigDecimal** |  |  [optional] |
|**targetUnit** | **String** |  |  [optional] |



