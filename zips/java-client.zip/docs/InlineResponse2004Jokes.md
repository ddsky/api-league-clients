

# InlineResponse2004Jokes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joke** | **String** |  |  [optional]



