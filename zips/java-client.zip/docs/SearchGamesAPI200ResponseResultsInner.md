

# SearchGamesAPI200ResponseResultsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**image** | **String** |  |  [optional] |
|**shortDescription** | **String** |  |  [optional] |
|**year** | **Integer** |  |  [optional] |
|**link** | **String** |  |  [optional] |
|**rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  |  [optional] |
|**adultOnly** | **Boolean** |  |  [optional] |
|**screenshots** | **List&lt;String&gt;** |  |  [optional] |
|**platforms** | [**List&lt;SearchGamesAPI200ResponseResultsInnerPlatformsInner&gt;**](SearchGamesAPI200ResponseResultsInnerPlatformsInner.md) |  |  [optional] |
|**microTrailer** | **String** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**genre** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**gameplay** | **String** |  |  [optional] |



