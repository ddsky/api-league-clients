

# RandomRiddle200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**riddle** | **String** |  |  [optional] |
|**answer** | **String** |  |  [optional] |
|**difficulty** | **String** |  |  [optional] |



