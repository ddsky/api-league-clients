

# RetrieveRecipeInformationAPI200ResponseInstructionsInnerStepsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**number** | **Integer** |  |  [optional] |
|**ingredients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
|**equipment** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  |  [optional] |
|**step** | **String** |  |  [optional] |



