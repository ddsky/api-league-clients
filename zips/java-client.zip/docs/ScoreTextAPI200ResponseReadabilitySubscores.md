

# ScoreTextAPI200ResponseReadabilitySubscores


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**readingTimeSeconds** | **Integer** |  |  [optional] |
|**forcast** | **BigDecimal** |  |  [optional] |
|**flesch** | **BigDecimal** |  |  [optional] |
|**smog** | **BigDecimal** |  |  [optional] |
|**ari** | **BigDecimal** |  |  [optional] |
|**lix** | **BigDecimal** |  |  [optional] |
|**colemanLiau** | **BigDecimal** |  |  [optional] |
|**kincaid** | **BigDecimal** |  |  [optional] |
|**fog** | **BigDecimal** |  |  [optional] |



