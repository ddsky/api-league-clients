

# FindSimilarGamesAPI200ResponseResultsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**image** | **String** |  |  [optional] |
|**shortDescription** | **String** |  |  [optional] |
|**microTrailer** | **String** |  |  [optional] |
|**year** | **Integer** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**genre** | **String** |  |  [optional] |
|**link** | **String** |  |  [optional] |
|**rating** | [**SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**adultOnly** | **Boolean** |  |  [optional] |
|**screenshots** | **List&lt;String&gt;** |  |  [optional] |
|**gameplay** | **String** |  |  [optional] |



