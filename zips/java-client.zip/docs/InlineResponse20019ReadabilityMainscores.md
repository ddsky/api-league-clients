

# InlineResponse20019ReadabilityMainscores


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Integer** |  |  [optional]
**total** | **Integer** |  |  [optional]



