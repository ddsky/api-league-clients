

# RetrieveRecipeInformationAPI200ResponseTaste


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**fattiness** | **BigDecimal** |  |  [optional] |
|**spiciness** | **Integer** |  |  [optional] |
|**saltiness** | **Integer** |  |  [optional] |
|**bitterness** | **BigDecimal** |  |  [optional] |
|**savoriness** | **BigDecimal** |  |  [optional] |
|**sweetness** | **BigDecimal** |  |  [optional] |
|**sourness** | **BigDecimal** |  |  [optional] |



