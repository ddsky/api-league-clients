

# RetrieveGameById200ResponsePlaytime


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percentiles** | **List&lt;Integer&gt;** |  |  [optional] |
|**min** | **Integer** |  |  [optional] |
|**median** | **Integer** |  |  [optional] |
|**max** | **Integer** |  |  [optional] |
|**mean** | **BigDecimal** |  |  [optional] |
|**mentions** | **Integer** |  |  [optional] |



