

# ScoreTextAPI200ResponseStyle


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**mainscores** | [**ScoreTextAPI200ResponseReadabilityMainscores**](ScoreTextAPI200ResponseReadabilityMainscores.md) |  |  [optional] |
|**subscores** | [**ScoreTextAPI200ResponseStyleSubscores**](ScoreTextAPI200ResponseStyleSubscores.md) |  |  [optional] |



