

# TopNewsAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**topNews** | [**List&lt;TopNewsAPI200ResponseTopNewsInner&gt;**](TopNewsAPI200ResponseTopNewsInner.md) |  |  [optional] |
|**language** | **String** |  |  [optional] |
|**country** | **String** |  |  [optional] |



