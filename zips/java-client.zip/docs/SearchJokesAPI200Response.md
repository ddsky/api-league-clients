

# SearchJokesAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**jokes** | [**List&lt;SearchJokesAPI200ResponseJokesInner&gt;**](SearchJokesAPI200ResponseJokesInner.md) |  |  [optional] |
|**available** | **Integer** |  |  [optional] |



