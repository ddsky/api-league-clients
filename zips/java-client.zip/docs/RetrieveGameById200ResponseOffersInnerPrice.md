

# RetrieveGameById200ResponseOffersInnerPrice


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**currency** | **String** |  |  [optional] |
|**discountPercent** | **Integer** |  |  [optional] |
|**value** | **BigDecimal** |  |  [optional] |
|**initial** | **BigDecimal** |  |  [optional] |



