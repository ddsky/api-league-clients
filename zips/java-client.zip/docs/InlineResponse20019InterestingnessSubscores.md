

# InlineResponse20019InterestingnessSubscores


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titleRatingScore** | **List&lt;Integer&gt;** |  |  [optional]
**quoteScore** | **List&lt;Integer&gt;** |  |  [optional]
**lengthScore** | **List&lt;Integer&gt;** |  |  [optional]
**linkScore** | **List&lt;Integer&gt;** |  |  [optional]
**googleHitsScore** | **List&lt;Integer&gt;** |  |  [optional]



