

# SearchGifsAPI200ResponseImagesInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**width** | **Integer** |  |  [optional] |
|**url** | **String** |  |  [optional] |
|**height** | **Integer** |  |  [optional] |



