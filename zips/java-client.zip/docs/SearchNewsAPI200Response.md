

# SearchNewsAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**available** | **Integer** |  |  [optional] |
|**news** | [**List&lt;SearchNewsAPI200ResponseNewsInner&gt;**](SearchNewsAPI200ResponseNewsInner.md) |  |  [optional] |



