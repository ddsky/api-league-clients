

# InlineResponse20018ReadabilitySubscores


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readingTimeSeconds** | **Integer** |  |  [optional]
**forcast** | **Integer** |  |  [optional]
**flesch** | **BigDecimal** |  |  [optional]
**smog** | **BigDecimal** |  |  [optional]
**ari** | **BigDecimal** |  |  [optional]
**lix** | **Integer** |  |  [optional]
**colemanLiau** | **BigDecimal** |  |  [optional]
**kincaid** | **BigDecimal** |  |  [optional]
**fog** | **BigDecimal** |  |  [optional]



