

# InlineResponse20019Skimmability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**InlineResponse20019SkimmabilityMainscores**](InlineResponse20019SkimmabilityMainscores.md) |  |  [optional]
**subscores** | [**InlineResponse20019SkimmabilitySubscores**](InlineResponse20019SkimmabilitySubscores.md) |  |  [optional]



