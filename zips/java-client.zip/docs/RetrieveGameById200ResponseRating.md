

# RetrieveGameById200ResponseRating


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**count** | **Integer** |  |  [optional] |
|**countCritics** | **Integer** |  |  [optional] |
|**meanPlayers** | **BigDecimal** |  |  [optional] |
|**meanCritics** | **BigDecimal** |  |  [optional] |
|**mean** | **BigDecimal** |  |  [optional] |
|**countPlayers** | **Integer** |  |  [optional] |



