

# ExtractAuthors200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**authors** | [**List&lt;ExtractAuthors200ResponseAuthorsInner&gt;**](ExtractAuthors200ResponseAuthorsInner.md) |  |  [optional] |



