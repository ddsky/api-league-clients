

# InlineResponse2004


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**List&lt;InlineResponse2004Jokes&gt;**](InlineResponse2004Jokes.md) |  |  [optional]
**available** | **Integer** |  |  [optional]



