

# SearchRecipes200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**recipes** | [**List&lt;SearchRecipes200ResponseRecipesInner&gt;**](SearchRecipes200ResponseRecipesInner.md) |  |  [optional] |
|**totalResults** | **Integer** |  |  [optional] |



