

# SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresMetric


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**unitShort** | **String** |  |  [optional] |
|**amount** | **BigDecimal** |  |  [optional] |
|**unitLong** | **String** |  |  [optional] |



