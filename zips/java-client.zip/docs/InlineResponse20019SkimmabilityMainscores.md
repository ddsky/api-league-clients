

# InlineResponse20019SkimmabilityMainscores


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalPossible** | **Integer** |  |  [optional]
**total** | **BigDecimal** |  |  [optional]



