

# TopNews200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**topNews** | [**List&lt;TopNews200ResponseTopNewsInner&gt;**](TopNews200ResponseTopNewsInner.md) |  |  [optional] |
|**language** | **String** |  |  [optional] |
|**country** | **String** |  |  [optional] |



