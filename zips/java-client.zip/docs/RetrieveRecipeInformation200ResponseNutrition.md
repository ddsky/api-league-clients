

# RetrieveRecipeInformation200ResponseNutrition


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**weightPerServing** | [**SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  |  [optional] |
|**caloricBreakdown** | [**SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  |  [optional] |
|**flavonoids** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional] |
|**ingredientBreakdown** | [**List&lt;RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner&gt;**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner.md) |  |  [optional] |
|**properties** | [**List&lt;SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  |  [optional] |
|**nutrients** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional] |



