

# RetrieveRecipeInformation200ResponseNutrition


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**weightPerServing** | [**RetrieveRecipeInformation200ResponseNutritionWeightPerServing**](RetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  |  [optional] |
|**caloricBreakdown** | [**RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown**](RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  |  [optional] |
|**flavonoids** | [**List&lt;RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner&gt;**](RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  |  [optional] |
|**ingredientBreakdown** | [**List&lt;RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner&gt;**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner.md) |  |  [optional] |
|**properties** | [**List&lt;SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner&gt;**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  |  [optional] |
|**nutrients** | [**List&lt;RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional] |



