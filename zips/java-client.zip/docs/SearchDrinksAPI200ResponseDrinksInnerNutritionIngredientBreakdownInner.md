

# SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**amount** | **Integer** |  |  [optional] |
|**unit** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**nutrients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional] |



