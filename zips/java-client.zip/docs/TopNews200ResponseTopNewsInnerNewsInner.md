

# TopNews200ResponseTopNewsInnerNewsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**summary** | **String** |  |  [optional] |
|**image** | **String** |  |  [optional] |
|**author** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**text** | **String** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**publishDate** | **String** |  |  [optional] |
|**url** | **String** |  |  [optional] |
|**authors** | **List&lt;String&gt;** |  |  [optional] |



