

# RandomMeme200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**description** | **String** |  |  [optional] |
|**url** | **String** |  |  [optional] |
|**type** | **String** |  |  [optional] |
|**width** | **Integer** |  |  [optional] |
|**height** | **Integer** |  |  [optional] |
|**ratio** | **BigDecimal** |  |  [optional] |



