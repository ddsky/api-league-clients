

# InlineResponse20022


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**synonyms** | **List&lt;String&gt;** |  |  [optional]



