

# RetrieveRecipeInformationAPI200ResponseCredits


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**license** | **String** |  |  [optional] |
|**text** | **String** |  |  [optional] |
|**sourceName** | **String** |  |  [optional] |
|**sourceUrl** | **String** |  |  [optional] |



