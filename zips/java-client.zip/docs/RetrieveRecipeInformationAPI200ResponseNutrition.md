

# RetrieveRecipeInformationAPI200ResponseNutrition


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**weightPerServing** | [**SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing.md) |  |  [optional] |
|**caloricBreakdown** | [**SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  |  [optional] |
|**flavonoids** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  |  [optional] |
|**ingredientBreakdown** | [**List&lt;RetrieveRecipeInformationAPI200ResponseNutritionIngredientBreakdownInner&gt;**](RetrieveRecipeInformationAPI200ResponseNutritionIngredientBreakdownInner.md) |  |  [optional] |
|**properties** | [**List&lt;SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner&gt;**](SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner.md) |  |  [optional] |
|**nutrients** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional] |



