

# PluralizeWordAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**original** | **String** |  |  [optional] |
|**plural** | **String** |  |  [optional] |



