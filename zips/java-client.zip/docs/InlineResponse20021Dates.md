

# InlineResponse20021Dates


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startPosition** | **Integer** |  |  [optional]
**date** | **String** |  |  [optional]
**normalizedDate** | **BigDecimal** |  |  [optional]
**tag** | **String** |  |  [optional]
**endPosition** | **Integer** |  |  [optional]



