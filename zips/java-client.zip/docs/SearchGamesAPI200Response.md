

# SearchGamesAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**sorting** | **Object** |  |  [optional] |
|**activeFilterOptions** | [**List&lt;SearchGamesAPI200ResponseActiveFilterOptionsInner&gt;**](SearchGamesAPI200ResponseActiveFilterOptionsInner.md) |  |  [optional] |
|**query** | **String** |  |  [optional] |
|**totalResults** | **Integer** |  |  [optional] |
|**limit** | **Integer** |  |  [optional] |
|**offset** | **Integer** |  |  [optional] |
|**results** | [**List&lt;SearchGamesAPI200ResponseResultsInner&gt;**](SearchGamesAPI200ResponseResultsInner.md) |  |  [optional] |
|**filterOptions** | [**List&lt;SearchGamesAPI200ResponseFilterOptionsInner&gt;**](SearchGamesAPI200ResponseFilterOptionsInner.md) |  |  [optional] |
|**sortingOptions** | [**List&lt;SearchGamesAPI200ResponseSortingOptionsInner&gt;**](SearchGamesAPI200ResponseSortingOptionsInner.md) |  |  [optional] |



