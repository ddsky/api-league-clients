

# ScoreText200ResponseSkimmabilitySubscores


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**bulletPointRatioScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**imageScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**highlightedWordRatioScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**videoScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**paragraphScore** | **List&lt;Integer&gt;** |  |  [optional] |
|**paragraphHeadlineRatioScore** | **List&lt;Integer&gt;** |  |  [optional] |



