

# DetectLanguage200ResponseInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**language** | **String** |  |  [optional] |
|**confidence** | **BigDecimal** |  |  [optional] |



