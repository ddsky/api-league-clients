

# InlineResponse20023


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taggedText** | **String** |  |  [optional]



