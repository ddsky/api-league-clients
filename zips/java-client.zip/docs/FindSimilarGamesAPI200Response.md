

# FindSimilarGamesAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**results** | [**List&lt;FindSimilarGamesAPI200ResponseResultsInner&gt;**](FindSimilarGamesAPI200ResponseResultsInner.md) |  |  [optional] |



