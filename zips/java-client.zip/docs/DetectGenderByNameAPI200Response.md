

# DetectGenderByNameAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**probabilityMale** | **BigDecimal** |  |  [optional] |
|**probabilityFemale** | **BigDecimal** |  |  [optional] |
|**popularity** | **BigDecimal** |  |  [optional] |



