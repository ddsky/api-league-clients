

# InlineResponse20018


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**InlineResponse20018Document**](InlineResponse20018Document.md) |  |  [optional]
**sentences** | [**List&lt;InlineResponse20018Sentences&gt;**](InlineResponse20018Sentences.md) |  |  [optional]



