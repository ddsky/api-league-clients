

# RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**amount** | **BigDecimal** |  |  [optional] |
|**unit** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**nutrients** | [**List&lt;SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner&gt;**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  |  [optional] |



