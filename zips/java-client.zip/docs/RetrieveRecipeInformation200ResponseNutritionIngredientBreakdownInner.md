

# RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**amount** | **BigDecimal** |  |  [optional] |
|**unit** | **String** |  |  [optional] |
|**id** | **Integer** |  |  [optional] |
|**nutrients** | [**List&lt;RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner&gt;**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  |  [optional] |



