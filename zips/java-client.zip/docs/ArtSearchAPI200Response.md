

# ArtSearchAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**available** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**offset** | **Integer** |  |  [optional] |
|**artworks** | [**List&lt;SearchBooksAPI200ResponseBooksInnerInner&gt;**](SearchBooksAPI200ResponseBooksInnerInner.md) |  |  [optional] |



