

# SearchMemes200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**memes** | [**List&lt;SearchMemes200ResponseMemesInner&gt;**](SearchMemes200ResponseMemesInner.md) |  |  [optional] |
|**available** | **Integer** |  |  [optional] |



