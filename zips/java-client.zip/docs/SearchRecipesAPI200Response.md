

# SearchRecipesAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**recipes** | [**List&lt;SearchRecipesAPI200ResponseRecipesInner&gt;**](SearchRecipesAPI200ResponseRecipesInner.md) |  |  [optional] |
|**totalResults** | **Integer** |  |  [optional] |



