

# SearchDrinksAPI200ResponseDrinksInnerInstructionsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**steps** | [**List&lt;SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner&gt;**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  |  [optional] |



