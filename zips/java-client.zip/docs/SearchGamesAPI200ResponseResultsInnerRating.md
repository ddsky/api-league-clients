

# SearchGamesAPI200ResponseResultsInnerRating


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**count** | **Integer** |  |  [optional] |
|**mean** | **BigDecimal** |  |  [optional] |



