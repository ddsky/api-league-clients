

# SearchDrinks200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**offset** | **Integer** |  |  [optional] |
|**number** | **Integer** |  |  [optional] |
|**drinks** | [**List&lt;SearchDrinks200ResponseDrinksInner&gt;**](SearchDrinks200ResponseDrinksInner.md) |  |  [optional] |
|**totalResults** | **Integer** |  |  [optional] |



