

# InlineResponse2005


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**List&lt;InlineResponse2005Memes&gt;**](InlineResponse2005Memes.md) |  |  [optional]
**available** | **Integer** |  |  [optional]



