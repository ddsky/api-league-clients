

# SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**amount** | **BigDecimal** |  |  [optional] |
|**unit** | **String** |  |  [optional] |



