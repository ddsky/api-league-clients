

# RetrieveArtworkById200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**id** | **Integer** |  |  [optional] |
|**title** | **String** |  |  [optional] |
|**image** | **String** |  |  [optional] |
|**startDate** | **Integer** |  |  [optional] |
|**endDate** | **Integer** |  |  [optional] |
|**description** | **String** |  |  [optional] |



