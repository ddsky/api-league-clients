

# SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percentFat** | **BigDecimal** |  |  [optional] |
|**percentCarbs** | **BigDecimal** |  |  [optional] |
|**percentProtein** | **BigDecimal** |  |  [optional] |



