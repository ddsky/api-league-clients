

# GenerateNonsenseWord200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**word** | **String** |  |  [optional] |
|**rating** | **BigDecimal** |  |  [optional] |



