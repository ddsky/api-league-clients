

# RetrievePageRankAPI200Response


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**pageRank** | **BigDecimal** |  |  [optional] |
|**position** | **Integer** |  |  [optional] |
|**percentile** | **BigDecimal** |  |  [optional] |



