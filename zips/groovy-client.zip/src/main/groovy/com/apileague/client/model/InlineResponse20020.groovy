package com.apileague.client.model;

import groovy.transform.Canonical
import com.apileague.client.model.InlineResponse20019Readability;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Canonical
class InlineResponse20020 {
    
    InlineResponse20019Readability readability
}
