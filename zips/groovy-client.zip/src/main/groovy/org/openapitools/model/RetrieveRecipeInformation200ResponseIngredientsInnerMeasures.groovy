package org.openapitools.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.model.RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric;

@Canonical
class RetrieveRecipeInformation200ResponseIngredientsInnerMeasures {
    
    RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric metric
    
    RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric us
}
