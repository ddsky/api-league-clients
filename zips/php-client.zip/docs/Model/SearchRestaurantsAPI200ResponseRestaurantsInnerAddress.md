# # SearchRestaurantsAPI200ResponseRestaurantsInnerAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zipcode** | **string** |  | [optional]
**country** | **string** |  | [optional]
**city** | **string** |  | [optional]
**latitude** | **float** |  | [optional]
**lon** | **float** |  | [optional]
**street_addr_2** | **string** |  | [optional]
**state** | **string** |  | [optional]
**street_addr** | **string** |  | [optional]
**lat** | **float** |  | [optional]
**longitude** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
