# # SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional]
**percent_of_daily_needs** | **float** |  | [optional]
**amount** | **float** |  | [optional]
**unit** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
