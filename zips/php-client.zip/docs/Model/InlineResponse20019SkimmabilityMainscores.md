# # InlineResponse20019SkimmabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | **int** |  | [optional]
**total** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
