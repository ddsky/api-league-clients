# # InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_words** | **int** |  | [optional]
**number_of_sentences** | **int** |  | [optional]
**readability** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019Readability**](InlineResponse20019Readability.md) |  | [optional]
**skimmability** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019Skimmability**](InlineResponse20019Skimmability.md) |  | [optional]
**interestingness** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019Interestingness**](InlineResponse20019Interestingness.md) |  | [optional]
**style** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019Style**](InlineResponse20019Style.md) |  | [optional]
**total_score** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
