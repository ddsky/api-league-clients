# # VectorSearchAPI200ResponseVectorsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**license** | **string** |  | [optional]
**title** | **string** |  | [optional]
**author** | **string** |  | [optional]
**image_url** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
