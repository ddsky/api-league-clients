# # SearchNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional]
**number** | **int** |  | [optional]
**available** | **int** |  | [optional]
**news** | [**\OpenAPI\Client\Model\SearchNews200ResponseNewsInner[]**](SearchNews200ResponseNewsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
