# # InlineResponse2004

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**\com.apileague.client\com.apileague.client.model\InlineResponse2004Jokes[]**](InlineResponse2004Jokes.md) |  | [optional]
**available** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
