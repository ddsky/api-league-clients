# # InlineResponse20027

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20027Entities[]**](InlineResponse20027Entities.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
