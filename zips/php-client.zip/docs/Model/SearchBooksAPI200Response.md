# # SearchBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_results** | **int** |  | [optional]
**number** | **int** |  | [optional]
**offset** | **int** |  | [optional]
**books** | **\OpenAPI\Client\Model\SearchBooksAPI200ResponseBooksInnerInner[][]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
