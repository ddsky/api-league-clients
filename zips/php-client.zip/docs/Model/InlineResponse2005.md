# # InlineResponse2005

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**\com.apileague.client\com.apileague.client.model\InlineResponse2005Memes[]**](InlineResponse2005Memes.md) |  | [optional]
**available** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
