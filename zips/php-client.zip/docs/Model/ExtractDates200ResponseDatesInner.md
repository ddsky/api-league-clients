# # ExtractDates200ResponseDatesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | **int** |  | [optional]
**date** | **string** |  | [optional]
**normalized_date** | **float** |  | [optional]
**tag** | **string** |  | [optional]
**end_position** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
