# # SearchJokes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**\OpenAPI\Client\Model\SearchJokes200ResponseJokesInner[]**](SearchJokes200ResponseJokesInner.md) |  | [optional]
**available** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
