# # InlineResponse20028

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20028Images[]**](InlineResponse20028Images.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
