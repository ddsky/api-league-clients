# # SearchDrinksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional]
**number** | **int** |  | [optional]
**drinks** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInner[]**](SearchDrinksAPI200ResponseDrinksInner.md) |  | [optional]
**total_results** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
