# # ScoreTextAPI200ResponseSkimmabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bullet_point_ratio_score** | **int[]** |  | [optional]
**image_score** | **int[]** |  | [optional]
**highlighted_word_ratio_score** | **int[]** |  | [optional]
**video_score** | **int[]** |  | [optional]
**paragraph_score** | **int[]** |  | [optional]
**paragraph_headline_ratio_score** | **int[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
