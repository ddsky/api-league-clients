# # ExtractContentFromAWebPageAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional]
**main_text** | **string** |  | [optional]
**main_html** | **string** |  | [optional]
**images** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
