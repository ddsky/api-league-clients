# # DetectSentimentAPI200ResponseDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sentiment** | **string** |  | [optional]
**confidence** | **int** |  | [optional]
**average_confidence** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
