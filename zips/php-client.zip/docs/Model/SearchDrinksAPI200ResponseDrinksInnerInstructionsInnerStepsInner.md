# # SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional]
**ingredients** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner[]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional]
**equipment** | **string[]** |  | [optional]
**step** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
