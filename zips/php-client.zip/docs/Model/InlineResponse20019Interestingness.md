# # InlineResponse20019Interestingness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019SkimmabilityMainscores**](InlineResponse20019SkimmabilityMainscores.md) |  | [optional]
**subscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019InterestingnessSubscores**](InlineResponse20019InterestingnessSubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
