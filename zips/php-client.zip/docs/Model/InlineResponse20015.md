# # InlineResponse20015

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20015Results[]**](InlineResponse20015Results.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
