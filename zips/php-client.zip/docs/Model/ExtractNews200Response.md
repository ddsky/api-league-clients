# # ExtractNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional]
**text** | **string** |  | [optional]
**url** | **string** |  | [optional]
**image** | **string** |  | [optional]
**publish_date** | **string** |  | [optional]
**author** | **string** |  | [optional]
**language** | **string** |  | [optional]
**source_country** | **string** |  | [optional]
**sentiment** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
