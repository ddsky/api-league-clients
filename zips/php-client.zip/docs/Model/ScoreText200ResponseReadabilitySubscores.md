# # ScoreText200ResponseReadabilitySubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reading_time_seconds** | **int** |  | [optional]
**forcast** | **float** |  | [optional]
**flesch** | **float** |  | [optional]
**smog** | **float** |  | [optional]
**ari** | **float** |  | [optional]
**lix** | **float** |  | [optional]
**coleman_liau** | **float** |  | [optional]
**kincaid** | **float** |  | [optional]
**fog** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
