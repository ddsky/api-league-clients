# # ScoreTextAPI200ResponseReadabilityMainscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_possible** | **int** |  | [optional]
**total** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
