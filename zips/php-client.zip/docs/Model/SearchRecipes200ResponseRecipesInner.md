# # SearchRecipes200ResponseRecipesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | **string[]** |  | [optional]
**nutrition** | [**\OpenAPI\Client\Model\SearchRecipes200ResponseRecipesInnerNutrition**](SearchRecipes200ResponseRecipesInnerNutrition.md) |  | [optional]
**id** | **int** |  | [optional]
**title** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
