# # SearchDrinks200ResponseDrinksInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight_per_serving** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner[]**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional]
**nutrients** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
