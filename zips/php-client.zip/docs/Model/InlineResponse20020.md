# # InlineResponse20020

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019Readability**](InlineResponse20019Readability.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
