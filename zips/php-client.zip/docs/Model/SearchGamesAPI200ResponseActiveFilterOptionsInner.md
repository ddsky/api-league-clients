# # SearchGamesAPI200ResponseActiveFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **string** |  | [optional]
**connection** | **string** |  | [optional]
**values** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner[]**](SearchGamesAPI200ResponseActiveFilterOptionsInnerValuesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
