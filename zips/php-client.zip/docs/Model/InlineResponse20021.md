# # InlineResponse20021

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20021Dates[]**](InlineResponse20021Dates.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
