# # RetrieveRecipeInformationAPI200ResponseTaste

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fattiness** | **float** |  | [optional]
**spiciness** | **int** |  | [optional]
**saltiness** | **int** |  | [optional]
**bitterness** | **float** |  | [optional]
**savoriness** | **float** |  | [optional]
**sweetness** | **float** |  | [optional]
**sourness** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
