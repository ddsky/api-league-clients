# # SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percent_fat** | **float** |  | [optional]
**percent_carbs** | **float** |  | [optional]
**percent_protein** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
