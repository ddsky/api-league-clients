# # RetrieveRecipeInformationAPI200ResponseDietaryProperties

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**low_fodmap** | **bool** |  | [optional]
**vegetarian** | **bool** |  | [optional]
**vegan** | **bool** |  | [optional]
**gluten_free** | **bool** |  | [optional]
**dairy_free** | **bool** |  | [optional]
**gaps** | **string** |  | [optional]
**diets** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
