# # SearchMemesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memes** | [**\OpenAPI\Client\Model\SearchMemesAPI200ResponseMemesInner[]**](SearchMemesAPI200ResponseMemesInner.md) |  | [optional]
**available** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
