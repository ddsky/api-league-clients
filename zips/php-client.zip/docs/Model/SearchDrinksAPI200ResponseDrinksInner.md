# # SearchDrinksAPI200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **string[]** |  | [optional]
**instructions** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerInstructionsInner[]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInner.md) |  | [optional]
**images** | **string[]** |  | [optional]
**nutrition** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutrition**](SearchDrinksAPI200ResponseDrinksInnerNutrition.md) |  | [optional]
**glass_type** | **string** |  | [optional]
**credits** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerCredits**](SearchDrinksAPI200ResponseDrinksInnerCredits.md) |  | [optional]
**price_per_serving** | **float** |  | [optional]
**description** | **string** |  | [optional]
**ingredients** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerIngredientsInner[]**](SearchDrinksAPI200ResponseDrinksInnerIngredientsInner.md) |  | [optional]
**id** | **int** |  | [optional]
**title** | **string** |  | [optional]
**cuisines** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
