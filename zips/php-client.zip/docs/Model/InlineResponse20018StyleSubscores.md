# # InlineResponse20018StyleSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**abbreviation_score** | **int[]** |  | [optional]
**style_score** | **int[]** |  | [optional]
**spelling_score** | **int[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
