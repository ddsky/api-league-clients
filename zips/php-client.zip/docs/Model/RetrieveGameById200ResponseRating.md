# # RetrieveGameById200ResponseRating

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional]
**count_critics** | **int** |  | [optional]
**mean_players** | **float** |  | [optional]
**mean_critics** | **float** |  | [optional]
**mean** | **float** |  | [optional]
**count_players** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
