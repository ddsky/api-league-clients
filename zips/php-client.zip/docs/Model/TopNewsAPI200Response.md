# # TopNewsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**top_news** | [**\OpenAPI\Client\Model\TopNewsAPI200ResponseTopNewsInner[]**](TopNewsAPI200ResponseTopNewsInner.md) |  | [optional]
**language** | **string** |  | [optional]
**country** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
