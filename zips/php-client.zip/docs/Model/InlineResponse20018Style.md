# # InlineResponse20018Style

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018ReadabilityMainscores**](InlineResponse20018ReadabilityMainscores.md) |  | [optional]
**subscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018StyleSubscores**](InlineResponse20018StyleSubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
