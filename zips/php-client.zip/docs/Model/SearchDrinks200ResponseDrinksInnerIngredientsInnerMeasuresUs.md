# # SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasuresUs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | **string** |  | [optional]
**amount** | **int** |  | [optional]
**unit_long** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
