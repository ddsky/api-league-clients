# # RandomMemeAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** |  | [optional]
**url** | **string** |  | [optional]
**type** | **string** |  | [optional]
**width** | **int** |  | [optional]
**height** | **int** |  | [optional]
**ratio** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
