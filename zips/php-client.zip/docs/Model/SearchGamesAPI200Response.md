# # SearchGamesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sorting** | **object** |  | [optional]
**active_filter_options** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseActiveFilterOptionsInner[]**](SearchGamesAPI200ResponseActiveFilterOptionsInner.md) |  | [optional]
**query** | **string** |  | [optional]
**total_results** | **int** |  | [optional]
**limit** | **int** |  | [optional]
**offset** | **int** |  | [optional]
**results** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseResultsInner[]**](SearchGamesAPI200ResponseResultsInner.md) |  | [optional]
**filter_options** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseFilterOptionsInner[]**](SearchGamesAPI200ResponseFilterOptionsInner.md) |  | [optional]
**sorting_options** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseSortingOptionsInner[]**](SearchGamesAPI200ResponseSortingOptionsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
