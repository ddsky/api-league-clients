# # SearchRecipesAPI200ResponseRecipesInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner[]**](SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
