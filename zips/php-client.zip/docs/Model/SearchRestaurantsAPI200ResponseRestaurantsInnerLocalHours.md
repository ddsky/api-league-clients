# # SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHours

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operational** | [**\OpenAPI\Client\Model\SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**delivery** | [**\OpenAPI\Client\Model\SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**pickup** | [**\OpenAPI\Client\Model\SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]
**dine_in** | [**\OpenAPI\Client\Model\SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational**](SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
