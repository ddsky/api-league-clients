# # SearchJokesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jokes** | [**\OpenAPI\Client\Model\SearchJokesAPI200ResponseJokesInner[]**](SearchJokesAPI200ResponseJokesInner.md) |  | [optional]
**available** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
