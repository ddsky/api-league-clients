# # SearchGamesAPI200ResponseFilterOptionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional]
**filter_type** | **string** |  | [optional]
**key** | **string** |  | [optional]
**values** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseFilterOptionsInnerValuesInner[]**](SearchGamesAPI200ResponseFilterOptionsInnerValuesInner.md) |  | [optional]
**filter_connection** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
