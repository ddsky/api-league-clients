# # ComputeNutritionAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner[]**](SearchRecipesAPI200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\ComputeNutritionAPI200ResponseIngredientBreakdownInner[]**](ComputeNutritionAPI200ResponseIngredientBreakdownInner.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional]
**weight_per_serving** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
