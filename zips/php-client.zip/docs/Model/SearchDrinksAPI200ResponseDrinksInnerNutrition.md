# # SearchDrinksAPI200ResponseDrinksInnerNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionPropertiesInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionPropertiesInner.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionPropertiesInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionPropertiesInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner[]**](SearchDrinksAPI200ResponseDrinksInnerNutritionIngredientBreakdownInner.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinksAPI200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional]
**weight_per_serving** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinksAPI200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
