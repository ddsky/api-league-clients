# # ArtSearchAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **int** |  | [optional]
**number** | **int** |  | [optional]
**offset** | **int** |  | [optional]
**artworks** | [**\OpenAPI\Client\Model\SearchBooksAPI200ResponseBooksInnerInner[]**](SearchBooksAPI200ResponseBooksInnerInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
