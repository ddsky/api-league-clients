# # InlineResponse20018Skimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018SkimmabilityMainscores**](InlineResponse20018SkimmabilityMainscores.md) |  | [optional]
**subscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018SkimmabilitySubscores**](InlineResponse20018SkimmabilitySubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
