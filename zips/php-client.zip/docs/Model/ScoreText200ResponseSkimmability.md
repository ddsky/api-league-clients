# # ScoreText200ResponseSkimmability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\OpenAPI\Client\Model\ScoreText200ResponseSkimmabilityMainscores**](ScoreText200ResponseSkimmabilityMainscores.md) |  | [optional]
**subscores** | [**\OpenAPI\Client\Model\ScoreText200ResponseSkimmabilitySubscores**](ScoreText200ResponseSkimmabilitySubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
