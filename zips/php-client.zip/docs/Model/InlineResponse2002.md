# # InlineResponse2002

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional]
**number** | **int** |  | [optional]
**available** | **int** |  | [optional]
**news** | [**\com.apileague.client\com.apileague.client.model\InlineResponse2002News[]**](InlineResponse2002News.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
