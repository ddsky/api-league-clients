# # RetrieveGameById200ResponsePlaytime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentiles** | **int[]** |  | [optional]
**min** | **int** |  | [optional]
**median** | **int** |  | [optional]
**max** | **int** |  | [optional]
**mean** | **float** |  | [optional]
**mentions** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
