# # ScoreTextAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_words** | **int** |  | [optional]
**number_of_sentences** | **int** |  | [optional]
**readability** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseReadability**](ScoreTextAPI200ResponseReadability.md) |  | [optional]
**skimmability** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseSkimmability**](ScoreTextAPI200ResponseSkimmability.md) |  | [optional]
**interestingness** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseInterestingness**](ScoreTextAPI200ResponseInterestingness.md) |  | [optional]
**style** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseStyle**](ScoreTextAPI200ResponseStyle.md) |  | [optional]
**total_score** | **float** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
