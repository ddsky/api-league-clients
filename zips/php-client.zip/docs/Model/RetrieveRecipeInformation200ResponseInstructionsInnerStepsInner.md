# # RetrieveRecipeInformation200ResponseInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional]
**ingredients** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner[]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional]
**equipment** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner[]**](RetrieveRecipeInformation200ResponseInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional]
**step** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
