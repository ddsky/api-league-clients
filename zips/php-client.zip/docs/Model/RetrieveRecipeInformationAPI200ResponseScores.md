# # RetrieveRecipeInformationAPI200ResponseScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta_score** | **float** |  | [optional]
**weight_watcher_smart_points** | **int** |  | [optional]
**health_score** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
