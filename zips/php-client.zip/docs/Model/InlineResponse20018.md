# # InlineResponse20018

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018Document**](InlineResponse20018Document.md) |  | [optional]
**sentences** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20018Sentences[]**](InlineResponse20018Sentences.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
