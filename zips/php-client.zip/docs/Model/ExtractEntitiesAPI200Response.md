# # ExtractEntitiesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entities** | [**\OpenAPI\Client\Model\ExtractEntitiesAPI200ResponseEntitiesInner[]**](ExtractEntitiesAPI200ResponseEntitiesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
