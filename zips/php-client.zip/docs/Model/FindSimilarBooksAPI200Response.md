# # FindSimilarBooksAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similar_books** | [**\OpenAPI\Client\Model\SearchBooksAPI200ResponseBooksInnerInner[]**](SearchBooksAPI200ResponseBooksInnerInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
