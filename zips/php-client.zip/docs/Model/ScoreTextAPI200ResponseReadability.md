# # ScoreTextAPI200ResponseReadability

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseReadabilityMainscores**](ScoreTextAPI200ResponseReadabilityMainscores.md) |  | [optional]
**subscores** | [**\OpenAPI\Client\Model\ScoreTextAPI200ResponseReadabilitySubscores**](ScoreTextAPI200ResponseReadabilitySubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
