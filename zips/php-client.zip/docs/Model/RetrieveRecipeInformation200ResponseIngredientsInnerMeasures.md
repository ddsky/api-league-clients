# # RetrieveRecipeInformation200ResponseIngredientsInnerMeasures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional]
**us** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric**](RetrieveRecipeInformation200ResponseIngredientsInnerMeasuresMetric.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
