# # SearchRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional]
**number** | **int** |  | [optional]
**recipes** | [**\OpenAPI\Client\Model\SearchRecipes200ResponseRecipesInner[]**](SearchRecipes200ResponseRecipesInner.md) |  | [optional]
**total_results** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
