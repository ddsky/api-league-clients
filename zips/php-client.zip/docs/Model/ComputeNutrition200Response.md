# # ComputeNutrition200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner[]**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner[]**](RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner[]**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\ComputeNutrition200ResponseIngredientBreakdownInner[]**](ComputeNutrition200ResponseIngredientBreakdownInner.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown**](RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  | [optional]
**weight_per_serving** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionWeightPerServing**](RetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
