# # ComputeNutrition200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionNutrientsInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionFlavonoidsInner.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner[]**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\ComputeNutrition200ResponseIngredientBreakdownInner[]**](ComputeNutrition200ResponseIngredientBreakdownInner.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown**](SearchDrinks200ResponseDrinksInnerNutritionCaloricBreakdown.md) |  | [optional]
**weight_per_serving** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing**](SearchDrinks200ResponseDrinksInnerNutritionWeightPerServing.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
