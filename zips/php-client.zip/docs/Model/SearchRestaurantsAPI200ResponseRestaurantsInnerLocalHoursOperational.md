# # SearchRestaurantsAPI200ResponseRestaurantsInnerLocalHoursOperational

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sunday** | **string** |  | [optional]
**saturday** | **string** |  | [optional]
**tuesday** | **string** |  | [optional]
**thursday** | **string** |  | [optional]
**friday** | **string** |  | [optional]
**wednesday** | **string** |  | [optional]
**monday** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
