# # TopNews200ResponseTopNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**news** | [**\OpenAPI\Client\Model\TopNews200ResponseTopNewsInnerNewsInner[]**](TopNews200ResponseTopNewsInnerNewsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
