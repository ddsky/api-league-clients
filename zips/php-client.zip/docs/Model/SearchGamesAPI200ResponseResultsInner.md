# # SearchGamesAPI200ResponseResultsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **string** |  | [optional]
**short_description** | **string** |  | [optional]
**year** | **int** |  | [optional]
**link** | **string** |  | [optional]
**rating** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseResultsInnerRating**](SearchGamesAPI200ResponseResultsInnerRating.md) |  | [optional]
**adult_only** | **bool** |  | [optional]
**screenshots** | **string[]** |  | [optional]
**platforms** | [**\OpenAPI\Client\Model\SearchGamesAPI200ResponseResultsInnerPlatformsInner[]**](SearchGamesAPI200ResponseResultsInnerPlatformsInner.md) |  | [optional]
**micro_trailer** | **string** |  | [optional]
**name** | **string** |  | [optional]
**genre** | **string** |  | [optional]
**id** | **int** |  | [optional]
**gameplay** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
