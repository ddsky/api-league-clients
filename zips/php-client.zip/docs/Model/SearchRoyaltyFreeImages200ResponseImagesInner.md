# # SearchRoyaltyFreeImages200ResponseImagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional]
**license** | [**\OpenAPI\Client\Model\SearchRoyaltyFreeImages200ResponseImagesInnerLicense**](SearchRoyaltyFreeImages200ResponseImagesInnerLicense.md) |  | [optional]
**thumbnail** | **string** |  | [optional]
**id** | **string** |  | [optional]
**url** | **string** |  | [optional]
**height** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
