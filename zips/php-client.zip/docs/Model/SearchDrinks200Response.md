# # SearchDrinks200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional]
**number** | **int** |  | [optional]
**drinks** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInner[]**](SearchDrinks200ResponseDrinksInner.md) |  | [optional]
**total_results** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
