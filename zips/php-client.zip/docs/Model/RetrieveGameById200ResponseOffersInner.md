# # RetrieveGameById200ResponseOffersInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**store_name** | **string** |  | [optional]
**title** | **string** |  | [optional]
**price** | [**\OpenAPI\Client\Model\RetrieveGameById200ResponseOffersInnerPrice**](RetrieveGameById200ResponseOffersInnerPrice.md) |  | [optional]
**platform** | **string** |  | [optional]
**url** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
