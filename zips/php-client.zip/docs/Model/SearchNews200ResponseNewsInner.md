# # SearchNews200ResponseNewsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **string** |  | [optional]
**image** | **string** |  | [optional]
**sentiment** | **float** |  | [optional]
**source_country** | **string** |  | [optional]
**language** | **string** |  | [optional]
**id** | **int** |  | [optional]
**text** | **string** |  | [optional]
**video** | **string** |  | [optional]
**title** | **string** |  | [optional]
**publish_date** | **string** |  | [optional]
**url** | **string** |  | [optional]
**authors** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
