# # SearchGifsAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**images** | [**\OpenAPI\Client\Model\SearchGifsAPI200ResponseImagesInner[]**](SearchGifsAPI200ResponseImagesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
