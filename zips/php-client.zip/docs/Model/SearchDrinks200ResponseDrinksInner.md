# # SearchDrinks200ResponseDrinksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flavors** | **string[]** |  | [optional]
**instructions** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerInstructionsInner[]**](SearchDrinks200ResponseDrinksInnerInstructionsInner.md) |  | [optional]
**images** | **string[]** |  | [optional]
**nutrition** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutrition**](SearchDrinks200ResponseDrinksInnerNutrition.md) |  | [optional]
**glass_type** | **string** |  | [optional]
**credits** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerCredits**](SearchDrinks200ResponseDrinksInnerCredits.md) |  | [optional]
**price_per_serving** | **float** |  | [optional]
**description** | **string** |  | [optional]
**ingredients** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerIngredientsInner[]**](SearchDrinks200ResponseDrinksInnerIngredientsInner.md) |  | [optional]
**id** | **int** |  | [optional]
**title** | **string** |  | [optional]
**cuisines** | **string[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
