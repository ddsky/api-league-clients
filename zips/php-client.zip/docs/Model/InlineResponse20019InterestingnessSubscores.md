# # InlineResponse20019InterestingnessSubscores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title_rating_score** | **int[]** |  | [optional]
**quote_score** | **int[]** |  | [optional]
**length_score** | **int[]** |  | [optional]
**link_score** | **int[]** |  | [optional]
**google_hits_score** | **int[]** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
