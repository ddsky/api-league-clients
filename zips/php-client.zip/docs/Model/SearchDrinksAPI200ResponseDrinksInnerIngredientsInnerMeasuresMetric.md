# # SearchDrinksAPI200ResponseDrinksInnerIngredientsInnerMeasuresMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit_short** | **string** |  | [optional]
**amount** | **float** |  | [optional]
**unit_long** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
