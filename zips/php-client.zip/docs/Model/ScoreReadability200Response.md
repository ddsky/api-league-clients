# # ScoreReadability200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**readability** | [**\OpenAPI\Client\Model\ScoreText200ResponseReadability**](ScoreText200ResponseReadability.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
