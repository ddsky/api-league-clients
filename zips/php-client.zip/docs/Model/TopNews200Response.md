# # TopNews200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**top_news** | [**\OpenAPI\Client\Model\TopNews200ResponseTopNewsInner[]**](TopNews200ResponseTopNewsInner.md) |  | [optional]
**language** | **string** |  | [optional]
**country** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
