# # VerifyEmailAddressAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** |  | [optional]
**domain** | **string** |  | [optional]
**first_name** | **string** |  | [optional]
**middle_name** | **string** |  | [optional]
**last_name** | **string** |  | [optional]
**full_name** | **string** |  | [optional]
**username** | **string** |  | [optional]
**image** | **string** |  | [optional]
**result** | **string** |  | [optional]
**disposable** | **bool** |  | [optional]
**accept_all** | **bool** |  | [optional]
**free_provider** | **bool** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
