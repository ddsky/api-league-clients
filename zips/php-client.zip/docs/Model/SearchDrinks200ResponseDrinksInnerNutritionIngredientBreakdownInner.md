# # SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional]
**amount** | **int** |  | [optional]
**unit** | **string** |  | [optional]
**id** | **int** |  | [optional]
**nutrients** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner[]**](SearchDrinks200ResponseDrinksInnerNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
