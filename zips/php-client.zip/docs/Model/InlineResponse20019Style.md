# # InlineResponse20019Style

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mainscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019ReadabilityMainscores**](InlineResponse20019ReadabilityMainscores.md) |  | [optional]
**subscores** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20019StyleSubscores**](InlineResponse20019StyleSubscores.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
