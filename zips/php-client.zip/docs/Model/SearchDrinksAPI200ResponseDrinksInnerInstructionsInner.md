# # SearchDrinksAPI200ResponseDrinksInnerInstructionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional]
**steps** | [**\OpenAPI\Client\Model\SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner[]**](SearchDrinksAPI200ResponseDrinksInnerInstructionsInnerStepsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
