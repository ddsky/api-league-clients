# # ExtractNewsAPI200ResponseVideosInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**summary** | **string** |  | [optional]
**duration** | **int** |  | [optional]
**thumbnail** | **string** |  | [optional]
**title** | **string** |  | [optional]
**url** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
