# # ExtractDatesAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dates** | [**\OpenAPI\Client\Model\ExtractDatesAPI200ResponseDatesInner[]**](ExtractDatesAPI200ResponseDatesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
