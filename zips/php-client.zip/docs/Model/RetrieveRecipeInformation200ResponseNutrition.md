# # RetrieveRecipeInformation200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight_per_serving** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionWeightPerServing**](RetrieveRecipeInformation200ResponseNutritionWeightPerServing.md) |  | [optional]
**caloric_breakdown** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown**](RetrieveRecipeInformation200ResponseNutritionCaloricBreakdown.md) |  | [optional]
**flavonoids** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner[]**](RetrieveRecipeInformation200ResponseNutritionFlavonoidsInner.md) |  | [optional]
**ingredient_breakdown** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner[]**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInner.md) |  | [optional]
**properties** | [**\OpenAPI\Client\Model\SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner[]**](SearchRecipes200ResponseRecipesInnerNutritionNutrientsInner.md) |  | [optional]
**nutrients** | [**\OpenAPI\Client\Model\RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner[]**](RetrieveRecipeInformation200ResponseNutritionIngredientBreakdownInnerNutrientsInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
