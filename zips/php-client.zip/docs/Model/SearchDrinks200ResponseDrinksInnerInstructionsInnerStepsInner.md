# # SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional]
**ingredients** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner[]**](SearchDrinks200ResponseDrinksInnerInstructionsInnerStepsInnerIngredientsInner.md) |  | [optional]
**equipment** | **string[]** |  | [optional]
**step** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
