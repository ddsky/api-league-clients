# # InlineResponse20027Images

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **int** |  | [optional]
**license** | [**\com.apileague.client\com.apileague.client.model\InlineResponse20027License**](InlineResponse20027License.md) |  | [optional]
**thumbnail** | **string** |  | [optional]
**id** | **string** |  | [optional]
**url** | **string** |  | [optional]
**height** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
