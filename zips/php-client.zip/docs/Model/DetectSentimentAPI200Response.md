# # DetectSentimentAPI200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**document** | [**\OpenAPI\Client\Model\DetectSentimentAPI200ResponseDocument**](DetectSentimentAPI200ResponseDocument.md) |  | [optional]
**sentences** | [**\OpenAPI\Client\Model\DetectSentimentAPI200ResponseSentencesInner[]**](DetectSentimentAPI200ResponseSentencesInner.md) |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
