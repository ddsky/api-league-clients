# # InlineResponse20026Entities

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_position** | **int** |  | [optional]
**image** | **string** |  | [optional]
**type** | **string** |  | [optional]
**value** | **string** |  | [optional]
**end_position** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
