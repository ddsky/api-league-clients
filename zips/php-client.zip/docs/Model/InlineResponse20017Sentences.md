# # InlineResponse20017Sentences

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **int** |  | [optional]
**sentiment** | **string** |  | [optional]
**offset** | **int** |  | [optional]
**confidence** | **int** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
