# # SearchDrinks200ResponseDrinksInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **string** |  | [optional]
**name_clean** | **string** |  | [optional]
**amount** | **int** |  | [optional]
**unit** | **string** |  | [optional]
**measures** | [**\OpenAPI\Client\Model\SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures**](SearchDrinks200ResponseDrinksInnerIngredientsInnerMeasures.md) |  | [optional]
**original** | **string** |  | [optional]
**meta** | **string[]** |  | [optional]
**original_name** | **string** |  | [optional]
**name** | **string** |  | [optional]
**id** | **int** |  | [optional]
**aisle** | **string** |  | [optional]
**consistency** | **string** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
